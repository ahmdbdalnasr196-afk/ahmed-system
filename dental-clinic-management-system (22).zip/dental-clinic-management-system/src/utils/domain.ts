import type { AppointmentStatus, Gender, NotificationType, WeekDay, AppNotification } from "@/types";

export const STATUS_LABELS: Record<AppointmentStatus, string> = {
  pending: "قيد الانتظار", confirmed: "مؤكد", completed: "مكتمل", cancelled: "ملغي", no_show: "لم يحضر",
};
export const STATUS_BADGE: Record<AppointmentStatus, string> = {
  pending: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  confirmed: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300",
  completed: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300",
  cancelled: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300",
  no_show: "bg-slate-200 text-slate-600 dark:bg-slate-700/60 dark:text-slate-300",
};
export const STATUS_DOT: Record<AppointmentStatus, string> = {
  pending: "bg-amber-500", confirmed: "bg-blue-500", completed: "bg-emerald-500", cancelled: "bg-rose-500", no_show: "bg-slate-400",
};
export const STATUS_HEX: Record<AppointmentStatus, string> = {
  pending: "#f59e0b", confirmed: "#3b82f6", completed: "#10b981", cancelled: "#f43f5e", no_show: "#94a3b8",
};

export const DAY_OPTIONS: { value: WeekDay; label: string; short: string }[] = [
  { value: "saturday", label: "السبت", short: "سبت" },
  { value: "sunday", label: "الأحد", short: "أحد" },
  { value: "monday", label: "الإثنين", short: "إثن" },
  { value: "tuesday", label: "الثلاثاء", short: "ثلا" },
  { value: "wednesday", label: "الأربعاء", short: "أرب" },
  { value: "thursday", label: "الخميس", short: "خمي" },
  { value: "friday", label: "الجمعة", short: "جمع" },
];
export const DAY_LABELS: Record<WeekDay, string> = Object.fromEntries(DAY_OPTIONS.map((d) => [d.value, d.label])) as Record<WeekDay, string>;

export const GENDER_LABELS: Record<Gender, string> = { male: "ذكر", female: "أنثى" };

export const NOTIFICATION_HEX: Record<NotificationType, string> = {
  success: "#10b981", warning: "#f59e0b", error: "#f43f5e", info: "#3b82f6",
};
export const NOTIFICATION_BG: Record<NotificationType, string> = {
  success: "bg-emerald-500", warning: "bg-amber-500", error: "bg-rose-500", info: "bg-blue-500",
};
export const NOTIFICATION_EMOJI: Record<NotificationType, string> = {
  success: "🟢", warning: "🟡", error: "🔴", info: "🔵",
};

export function notificationEmoji(n: Pick<AppNotification, "category" | "relatedType" | "type">): string {
  const cat = n.category ?? n.relatedType;
  switch (cat) {
    case "appointment": return "📅";
    case "visit": return "🦷";
    case "patient": return "👤";
    case "doctor": return "👨‍⚕️";
    case "service": return "🦷";
    case "settings": return "⚙️";
    case "reminder": return "⏰";
    case "warning": return "⚠️";
    case "success": return "✅";
    case "error": return "❌";
    default:
      return (({ success: "✅", warning: "⚠️", error: "❌", info: "ℹ️" } as Record<NotificationType, string>)[n.type] ?? "🔔");
  }
}

export function serviceEmoji(name: string): string {
  const n = name.toLowerCase();
  if (n.includes("تبييض") || n.includes("whiten")) return "✨";
  if (n.includes("تنظيف") || n.includes("clean")) return "🪥";
  if (n.includes("حشو") || n.includes("fill")) return "🦷";
  if (n.includes("خلع") || n.includes("extract")) return "🔧";
  if (n.includes("تقويم") || n.includes("ortho")) return "😁";
  if (n.includes("جذر") || n.includes("root") || n.includes("canal")) return "🧬";
  if (n.includes("تركيب") || n.includes("زراع") || n.includes("crown") || n.includes("implant")) return "👑";
  if (n.includes("كشف") || n.includes("check")) return "🔍";
  if (n.includes("أطفال") || n.includes("child")) return "🧒";
  return "🦷";
}

const AVATAR_GRADIENTS = [
  "from-blue-500 to-indigo-600", "from-emerald-500 to-teal-600", "from-violet-500 to-purple-600",
  "from-rose-500 to-pink-600", "from-amber-500 to-orange-600", "from-cyan-500 to-sky-600",
  "from-fuchsia-500 to-rose-600", "from-lime-500 to-emerald-600",
];

export function avatarGradient(seed: string): string {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return AVATAR_GRADIENTS[h % AVATAR_GRADIENTS.length];
}

export function initials(name: string): string {
  const parts = name.replace(/^(د\.|د |دكتور|أ\.|أ |ال)/gi, "").trim().split(/\s+/);
  const first = parts[0] || name;
  const second = parts[1] || "";
  return ((first[0] || "") + (second[0] || "")).toUpperCase();
}
