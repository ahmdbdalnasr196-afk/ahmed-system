import type { WeekDay } from "@/types";

export function normalizeArabic(input: string): string {
  if (!input) return "";
  return input
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
    .replace(/\u0622/g, "\u0627")
    .replace(/\u0623/g, "\u0627")
    .replace(/\u0625/g, "\u0627")
    .replace(/\u0629/g, "\u0647")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0640/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

export function uid(prefix = ""): string {
  const rnd = globalThis.crypto?.randomUUID?.() ?? `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
  return prefix ? `${prefix}_${rnd}` : rnd;
}

export function pad(n: number): string { return String(n).padStart(2, "0"); }
export function nowIso(): string { return new Date().toISOString(); }

export function toDateKey(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function todayKey(): string { return toDateKey(new Date()); }
export function daysAgoKey(n: number): string {
  const d = new Date(); d.setDate(d.getDate() - n); return toDateKey(d);
}

export function parseDateKey(key: string): Date {
  const [y, m, d] = key.split("T")[0].split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function formatDate(key?: string | null): string {
  if (!key) return "—";
  const d = key.includes("T") ? new Date(key) : parseDateKey(key);
  if (isNaN(d.getTime())) return "—";
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

export function formatDateTime(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} • ${to12h(`${pad(d.getHours())}:${pad(d.getMinutes())}`)}`;
}

const DAY_KEYS: WeekDay[] = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
export function weekdayOf(key: string): WeekDay {
  return DAY_KEYS[parseDateKey(key).getDay()];
}

export const ARABIC_MONTHS = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
export const ARABIC_MONTHS_SHORT = ARABIC_MONTHS.map((m) => m.slice(0, 3));
export const WEEKDAY_SHORT = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
export function weekdayShort(d: Date): string { return WEEKDAY_SHORT[d.getDay()]; }

// Time — internal storage is 24h "HH:mm", display is 12h AM/PM
export function timeToMinutes(hhmm: string): number {
  const [h, m] = (hhmm || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
export function minutesToTime(mins: number): string {
  const m = ((mins % 1440) + 1440) % 1440;
  return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
}
export function addMinutes(hhmm: string, mins: number): string {
  return minutesToTime(timeToMinutes(hhmm) + mins);
}

// Centralized 12-hour formatter — handles all edge cases (12:00 AM/PM, midnight, noon)
export function to12h(hhmm?: string | null): string {
  if (!hhmm) return "—";
  const [h, m] = hhmm.split(":").map(Number);
  if (isNaN(h)) return "—";
  const period = h >= 12 ? "PM" : "AM";
  let hour = h % 12;
  if (hour === 0) hour = 12;
  return `${hour}:${pad(m || 0)} ${period}`;
}

export function rangesOverlap(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}

export function formatCurrency(n: number): string {
  const v = Math.round(n || 0);
  return `${v.toLocaleString("en-US")} ج.م`;
}
export function formatNumber(n: number): string {
  return Math.round(n || 0).toLocaleString("en-US");
}

function pluralAr(n: number, one: string, few: string, many: string): string {
  if (n === 1) return one;
  if (n === 2) return many;
  if (n >= 3 && n <= 10) return few;
  return many;
}

export function relativeTime(iso?: string | null): string {
  if (!iso) return "—";
  const t = new Date(iso).getTime();
  if (isNaN(t)) return "—";
  const diff = Date.now() - t;
  const sec = Math.floor(diff / 1000);
  if (sec < 45) return "منذ لحظات";
  const min = Math.floor(sec / 60);
  if (min < 60) return `منذ ${min} ${pluralAr(min, "دقيقة", "دقائق", "دقيقة")}`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `منذ ${hr} ${pluralAr(hr, "ساعة", "ساعات", "ساعة")}`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `منذ ${day} ${pluralAr(day, "يوم", "أيام", "يوماً")}`;
  const mon = Math.floor(day / 30);
  return `منذ ${mon} ${pluralAr(mon, "شهر", "أشهر", "شهراً")}`;
}
