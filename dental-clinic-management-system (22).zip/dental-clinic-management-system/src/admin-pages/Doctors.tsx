"use client";

import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, Pencil, Plus, RefreshCw, Trash2, Filter } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import type { Doctor, WeekDay } from "@/types";
import {
  Avatar,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Pagination,
  SearchInput,
  Select,
  Skeleton,
  Textarea,
} from "@/components/ui";
import { TimePicker } from "@/components/TimePicker";
import { ImageUpload } from "@/components/ImageUpload";
import { DAY_OPTIONS } from "@/utils/domain";
import { to12h } from "@/utils/format";

const NAME_RE = /^[\u0600-\u06FFa-zA-Z\s.]+$/;

export default function Doctors() {
  const { data, createDoctor, updateDoctor, deleteDoctor } = useApp();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [specialty, setSpecialty] = useState("all");
  const [day, setDay] = useState<"all" | WeekDay>("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Doctor | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const stats = useMemo(() => {
    const patients = new Map<string, Set<string>>();
    const appts = new Map<string, number>();
    data.visits.filter((v) => !v.isDeleted).forEach((v) => {
      const s = patients.get(v.doctorId) ?? new Set<string>();
      s.add(v.patientId);
      patients.set(v.doctorId, s);
    });
    data.appointments.filter((a) => !a.isDeleted).forEach((a) =>
      appts.set(a.doctorId, (appts.get(a.doctorId) ?? 0) + 1)
    );
    return {
      patients: (id: string) => patients.get(id)?.size ?? 0,
      appts: (id: string) => appts.get(id) ?? 0,
    };
  }, [data.visits, data.appointments]);

  const specialties = useMemo(
    () => [...new Set(data.doctors.filter((d) => !d.isDeleted).map((d) => d.specialty))],
    [data.doctors]
  );

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.doctors.filter((d) => {
      if (d.isDeleted || !d.isActive) return false;
      if (q && !(d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q) || (d.phone ?? "").includes(q)))
        return false;
      if (specialty !== "all" && d.specialty !== specialty) return false;
      if (day !== "all" && !d.workingDays.includes(day)) return false;
      return true;
    });
  }, [data.doctors, query, specialty, day]);

  useEffect(() => setPage(1), [query, specialty, day, pageSize]);

  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader
        title="👨‍⚕️ الأطباء"
        subtitle={`${data.doctors.filter((d) => !d.isDeleted && d.isActive).length} طبيب نشط`}
        actions={
          <>
            <Button variant="secondary" loading={refreshing} onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 600); }}>
              <RefreshCw className="h-4 w-4" /> تحديث
            </Button>
            <Button onClick={() => { setEditing(null); setModalOpen(true); }}>
              <Plus className="h-4 w-4" /> إضافة طبيب
            </Button>
          </>
        }
      />

      <Card className="mb-4 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <SearchInput value={query} onChange={setQuery} placeholder="بحث بالاسم أو التخصص أو الهاتف..." className="flex-1" />
          <div className="flex flex-wrap items-center gap-2">
            <Filter className="h-4 w-4 text-slate-400" />
            <Select value={specialty} onChange={(e) => setSpecialty(e.target.value)} className="w-auto">
              <option value="all">كل التخصصات</option>
              {specialties.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </Select>
            <Select value={day} onChange={(e) => setDay(e.target.value as any)} className="w-auto">
              <option value="all">كل الأيام</option>
              {DAY_OPTIONS.map((d) => (
                <option key={d.value} value={d.value}>{d.label}</option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <div className="space-y-3 p-5">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
          </div>
        ) : rows.length === 0 ? (
          <EmptyState
            emoji="👨‍⚕️"
            title="لا يوجد أطباء حتى الآن"
            description="ابدأ بإضافة أول طبيب."
            action={<Button onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> إضافة طبيب</Button>}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-right text-xs font-bold text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                  <th className="px-5 py-3">الطبيب</th>
                  <th className="px-5 py-3">التخصص</th>
                  <th className="px-5 py-3">ساعات العمل</th>
                  <th className="px-5 py-3">المرضى</th>
                  <th className="px-5 py-3">الحجوزات</th>
                  <th className="px-5 py-3 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {pageRows.map((d) => (
                  <tr key={d.id} className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                    <td className="px-5 py-3">
                      <button onClick={() => navigate(`/doctors/${d.id}`)} className="flex items-center gap-3 text-right">
                        <Avatar name={d.name} size="sm" src={d.image} />
                        <div>
                          <p className="font-semibold text-slate-700 dark:text-slate-200">{d.name}</p>
                          <p className="text-xs text-slate-400" dir="ltr">{d.phone || "—"}</p>
                        </div>
                      </button>
                    </td>
                    <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{d.specialty}</td>
                    <td className="px-5 py-3 text-xs text-slate-500 dark:text-slate-400">
                      {to12h(d.workingFrom)} - {to12h(d.workingTo)}
                    </td>
                    <td className="px-5 py-3">
                      <span className="rounded-lg bg-violet-50 px-2 py-1 text-xs font-bold text-violet-600 dark:bg-violet-500/15 dark:text-violet-300">
                        {stats.patients(d.id)}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <span className="rounded-lg bg-blue-50 px-2 py-1 text-xs font-bold text-blue-600 dark:bg-blue-500/15 dark:text-blue-300">
                        {stats.appts(d.id)}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <IconBtn title="عرض" onClick={() => navigate(`/doctors/${d.id}`)}><Eye className="h-4 w-4" /></IconBtn>
                        <IconBtn title="تعديل" onClick={() => { setEditing(d); setModalOpen(true); }}><Pencil className="h-4 w-4" /></IconBtn>
                        <IconBtn title="حذف" danger onClick={() => setDeleteId(d.id)}><Trash2 className="h-4 w-4" /></IconBtn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {!loading && rows.length > 0 && (
          <Pagination page={page} pageCount={pageCount} total={rows.length} pageSize={pageSize} onPage={setPage} onPageSize={setPageSize} />
        )}
      </Card>

      <DoctorModal
        open={modalOpen}
        doctor={editing}
        onClose={() => setModalOpen(false)}
        onSubmit={async (values) => {
          if (editing) await updateDoctor(editing.id, values);
          else await createDoctor(values);
        }}
      />

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        danger
        message="هل أنت متأكد من حذف هذا الطبيب؟ سيصبح غير نشط مع الاحتفاظ بالسجلات."
        onConfirm={async () => { if (deleteId) await deleteDoctor(deleteId); setDeleteId(null); }}
      />
    </div>
  );
}

function IconBtn({ children, onClick, title, danger }: { children: React.ReactNode; onClick: () => void; title: string; danger?: boolean }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded-lg p-2 transition-colors ${
        danger ? "text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/15" : "text-slate-400 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-brand-500/15"
      }`}
    >
      {children}
    </button>
  );
}

function DoctorModal({ open, doctor, onClose, onSubmit }: { open: boolean; doctor: Doctor | null; onClose: () => void; onSubmit: (values: any) => Promise<void> }) {
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [phone, setPhone] = useState("");
  const [image, setImage] = useState("");
  const [workingDays, setWorkingDays] = useState<WeekDay[]>([]);
  const [workingFrom, setWorkingFrom] = useState("10:00");
  const [workingTo, setWorkingTo] = useState("18:00");
  const [description, setDescription] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(doctor?.name ?? "");
      setSpecialty(doctor?.specialty ?? "");
      setPhone(doctor?.phone ?? "");
      setImage(doctor?.image ?? "");
      setWorkingDays(doctor?.workingDays ?? []);
      setWorkingFrom(doctor?.workingFrom ?? "10:00");
      setWorkingTo(doctor?.workingTo ?? "18:00");
      setDescription(doctor?.description ?? "");
      setErrors({});
      setFormError(null);
    }
  }, [open, doctor]);

  const toggleDay = (d: WeekDay) =>
    setWorkingDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));

  const validate = () => {
    const e: Record<string, string> = {};
    if (name.trim().length < 3) e.name = "اسم الطبيب يجب أن يكون 3 أحرف على الأقل";
    else if (name.trim().length > 100) e.name = "الاسم طويل جداً";
    else if (!NAME_RE.test(name.trim())) e.name = "اسم غير صالح";
    if (!specialty.trim()) e.specialty = "التخصص مطلوب";
    if (phone && !/^0[0-9]{9,11}$/.test(phone.trim())) e.phone = "رقم هاتف غير صحيح";
    if (!workingDays.length) e.workingDays = "اختر يوم عمل واحد على الأقل";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    setFormError(null);
    try {
      await onSubmit({ name: name.trim(), specialty: specialty.trim(), phone: phone.trim(), image, workingDays, workingFrom, workingTo, description: description.trim() });
      onClose();
    } catch {
      setFormError("تعذر حفظ البيانات. حاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={doctor ? "تعديل بيانات الطبيب" : "إضافة طبيب جديد"} size="lg">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label="صورة الطبيب">
            <ImageUpload value={image} onChange={setImage} fallbackName={name || "طبيب"} />
          </Field>
        </div>
        <Field label="اسم الطبيب" required error={errors.name}>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="د. كريم عبد الله" />
        </Field>
        <Field label="التخصص" required error={errors.specialty}>
          <Input value={specialty} onChange={(e) => setSpecialty(e.target.value)} placeholder="تقويم الأسنان" />
        </Field>
        <Field label="رقم الهاتف" error={errors.phone}>
          <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="01001234567" dir="ltr" />
        </Field>
        <div className="sm:col-span-2">
          {/* Working hours — clean 2-column grid that never overlaps */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="بداية العمل" hint="نظام 12 ساعة">
              <TimePicker value={workingFrom} onChange={setWorkingFrom} />
            </Field>
            <Field label="نهاية العمل" hint="نظام 12 ساعة">
              <TimePicker value={workingTo} onChange={setWorkingTo} />
            </Field>
          </div>
        </div>
        <div className="sm:col-span-2">
          <Field label="أيام العمل" required error={errors.workingDays}>
            <div className="flex flex-wrap gap-2">
              {DAY_OPTIONS.map((d) => (
                <button
                  key={d.value}
                  type="button"
                  onClick={() => toggleDay(d.value)}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                    workingDays.includes(d.value)
                      ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                      : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-slate-700"
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="نبذة مختصرة">
            <Textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="خبرات وشهادات الطبيب..." />
          </Field>
        </div>
      </div>
      {formError && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 dark:bg-rose-500/10">{formError}</p>}
      <div className="mt-5 flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose} disabled={submitting}>إلغاء</Button>
        <Button className="flex-1" loading={submitting} onClick={submit}>{submitting ? "جاري الحفظ..." : "حفظ"}</Button>
      </div>
    </Modal>
  );
}
