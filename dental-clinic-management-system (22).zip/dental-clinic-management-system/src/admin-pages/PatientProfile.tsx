"use client";

import { ArrowRight, CalendarClock, Clock, DollarSign, Wallet } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { api } from "@/lib/api";
import { useApp } from "@/contexts/AppContext";
import { useAsync } from "@/hooks";
import { Avatar, Card, CardHeader, EmptyState, Skeleton } from "@/components/ui";
import { formatDate, formatCurrency } from "@/utils/format";
import { GENDER_LABELS, serviceEmoji } from "@/utils/domain";

export default function PatientProfile() {
  const { id = "" } = useParams();
  const { data } = useApp();
  const { data: patient, loading } = useAsync(() => api.getPatient(id), [id, data]);

  const doctorName = (did: string) => data.doctors.find((d) => d.id === did)?.name ?? "—";
  const serviceName = (sid: string) => data.services.find((s) => s.id === sid)?.name ?? "—";

  if (loading || !patient) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const stats = [
    { label: "عدد الزيارات", value: patient.visitsCount, icon: CalendarClock, tint: "bg-blue-500" },
    { label: "إجمالي المدفوعات", value: formatCurrency(patient.totalPaid), icon: DollarSign, tint: "bg-emerald-500" },
    { label: "المتبقي", value: formatCurrency(patient.remainingBalance), icon: Wallet, tint: "bg-amber-500" },
    { label: "آخر زيارة", value: formatDate(patient.lastVisit), icon: Clock, tint: "bg-violet-500" },
  ];

  return (
    <div className="space-y-6">
      <Link to="/patients" className="inline-flex items-center gap-1 text-sm font-semibold text-slate-500 hover:text-brand-600">
        <ArrowRight className="h-4 w-4" /> العودة للمرضى
      </Link>

      <Card className="overflow-hidden">
        <div className="bg-gradient-to-l from-brand-600 to-brand-500 p-6">
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center">
            <Avatar name={patient.name} size="xl" className="ring-4 ring-white/30" />
            <div className="text-center sm:text-right">
              <h1 className="text-2xl font-extrabold text-white">{patient.name}</h1>
              <p className="mt-1 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-sm text-white/90 sm:justify-start" dir="ltr">
                <span>{patient.phone}</span>
                <span>•</span>
                <span>{patient.age} سنة</span>
                <span>•</span>
                <span>{GENDER_LABELS[patient.gender]}</span>
              </p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 p-5 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="rounded-xl border border-slate-100 p-4 dark:border-slate-800">
              <div className={`mb-2 inline-flex h-9 w-9 items-center justify-center rounded-lg text-white ${s.tint}`}>
                <s.icon className="h-4 w-4" />
              </div>
              <p className="text-lg font-extrabold text-slate-800 dark:text-white">{s.value}</p>
              <p className="text-xs text-slate-400">{s.label}</p>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader title="المعلومات الشخصية" icon="📋" />
          <div className="divide-y divide-slate-100 p-5 text-sm dark:divide-slate-800">
            <InfoRow label="العنوان" value={patient.address || "—"} />
            <InfoRow label="تاريخ إنشاء الملف" value={formatDate(patient.createdAt)} />
            <InfoRow label="المواعيد القادمة" value={`${patient.upcomingAppointments} موعد`} />
            <div className="pt-3">
              <p className="mb-1 text-xs font-semibold text-slate-400">ملاحظات</p>
              <p className="text-slate-600 dark:text-slate-300">{patient.notes || "لا توجد ملاحظات"}</p>
            </div>
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader title="السجل الطبي والزيارات" icon="🩺" subtitle={`${patient.visitsCount} زيارة`} />
          <div className="p-5">
            {patient.visits.length === 0 ? (
              <EmptyState emoji="🩺" title="لا توجد زيارات حتى الآن" description="سيظهر هنا سجل زيارات المريض." />
            ) : (
              <ol className="relative space-y-4 border-r-2 border-slate-100 pr-6 dark:border-slate-800">
                {patient.visits.map((v) => (
                  <li key={v.id} className="relative animate-slide-up">
                    <span className="absolute -right-[31px] top-1.5 flex h-4 w-4 items-center justify-center rounded-full border-2 border-white bg-brand-500 dark:border-slate-900" />
                    <div className="rounded-xl border border-slate-100 p-4 dark:border-slate-800">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{serviceEmoji(serviceName(v.serviceId))}</span>
                          <div>
                            <p className="font-bold text-slate-800 dark:text-white">{serviceName(v.serviceId)}</p>
                            <p className="text-xs text-slate-400">{doctorName(v.doctorId)} • {formatDate(v.visitDate)}</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(v.paidAmount)}</p>
                          {v.remainingAmount > 0 && (
                            <p className="text-xs text-amber-600 dark:text-amber-400">متبقي {formatCurrency(v.remainingAmount)}</p>
                          )}
                        </div>
                      </div>
                      {(v.diagnosis || v.treatmentPlan || v.notes) && (
                        <div className="mt-3 space-y-1 border-t border-slate-50 pt-3 text-xs dark:border-slate-800">
                          {v.diagnosis && <p className="text-slate-500 dark:text-slate-400"><b className="text-slate-600 dark:text-slate-300">التشخيص:</b> {v.diagnosis}</p>}
                          {v.treatmentPlan && <p className="text-slate-500 dark:text-slate-400"><b className="text-slate-600 dark:text-slate-300">خطة العلاج:</b> {v.treatmentPlan}</p>}
                          {v.notes && <p className="text-slate-500 dark:text-slate-400"><b className="text-slate-600 dark:text-slate-300">ملاحظات:</b> {v.notes}</p>}
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-3">
      <span className="text-slate-400">{label}</span>
      <span className="font-semibold text-slate-700 dark:text-slate-200">{value}</span>
    </div>
  );
}
