"use client";

import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, Pencil, Plus, RefreshCw, Trash2, Filter } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import type { Gender, Patient } from "@/types";
import {
  Avatar,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Pagination,
  SearchInput,
  Select,
  Skeleton,
  Textarea,
} from "@/components/ui";
import { GENDER_LABELS } from "@/utils/domain";
import { formatCurrency, formatDate } from "@/utils/format";

interface RowSummary {
  visitsCount: number;
  lastVisit: string | null;
  totalPaid: number;
}

export default function Patients() {
  const { data, createPatient, updatePatient, deletePatient } = useApp();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [gender, setGender] = useState<"all" | Gender>("all");
  const [visitsFilter, setVisitsFilter] = useState<"all" | "has" | "none">("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Patient | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const summaries = useMemo(() => {
    const map = new Map<string, RowSummary>();
    data.visits
      .filter((v) => !v.isDeleted)
      .forEach((v) => {
        const cur = map.get(v.patientId) ?? { visitsCount: 0, lastVisit: null, totalPaid: 0 };
        cur.visitsCount += 1;
        cur.totalPaid += v.paidAmount;
        if (!cur.lastVisit || v.visitDate > cur.lastVisit) cur.lastVisit = v.visitDate;
        map.set(v.patientId, cur);
      });
    return map;
  }, [data.visits]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.patients.filter((p) => {
      if (p.isDeleted) return false;
      if (q && !(p.name.toLowerCase().includes(q) || p.phone.includes(q))) return false;
      if (gender !== "all" && p.gender !== gender) return false;
      const vc = summaries.get(p.id)?.visitsCount ?? 0;
      if (visitsFilter === "has" && vc === 0) return false;
      if (visitsFilter === "none" && vc > 0) return false;
      return true;
    });
  }, [data.patients, query, gender, visitsFilter, summaries]);

  useEffect(() => {
    setPage(1);
  }, [query, gender, visitsFilter, pageSize]);

  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 600);
  };

  return (
    <div>
      <PageHeader
        title="👥 المرضى"
        subtitle={`${data.patients.filter((p) => !p.isDeleted).length} مريض مسجل`}
        actions={
          <>
            <Button variant="secondary" size="md" loading={refreshing} onClick={refresh}>
              <RefreshCw className="h-4 w-4" /> تحديث
            </Button>
            <Button
              onClick={() => {
                setEditing(null);
                setModalOpen(true);
              }}
            >
              <Plus className="h-4 w-4" /> إضافة مريض
            </Button>
          </>
        }
      />

      <Card className="mb-4 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <SearchInput value={query} onChange={setQuery} placeholder="بحث بالاسم أو رقم الهاتف..." className="flex-1" />
          <div className="flex flex-wrap items-center gap-2">
            <Filter className="h-4 w-4 text-slate-400" />
            <Select value={gender} onChange={(e) => setGender(e.target.value as any)} className="w-auto">
              <option value="all">كل الأجناس</option>
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
            </Select>
            <Select value={visitsFilter} onChange={(e) => setVisitsFilter(e.target.value as any)} className="w-auto">
              <option value="all">كل المرضى</option>
              <option value="has">لديه زيارات</option>
              <option value="none">بدون زيارات</option>
            </Select>
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <div className="space-y-3 p-5">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <EmptyState
            emoji="👥"
            title="لا يوجد مرضى حتى الآن"
            description="ابدأ بإضافة أول مريض."
            action={
              <Button onClick={() => setModalOpen(true)}>
                <Plus className="h-4 w-4" /> إضافة مريض
              </Button>
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-right text-xs font-bold text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                  <th className="px-5 py-3">الاسم</th>
                  <th className="px-5 py-3">الهاتف</th>
                  <th className="px-5 py-3">العمر</th>
                  <th className="px-5 py-3">الجنس</th>
                  <th className="px-5 py-3">الزيارات</th>
                  <th className="px-5 py-3">آخر زيارة</th>
                  <th className="px-5 py-3">المدفوعات</th>
                  <th className="px-5 py-3 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {pageRows.map((p) => {
                  const s = summaries.get(p.id);
                  return (
                    <tr key={p.id} className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                      <td className="px-5 py-3">
                        <button onClick={() => navigate(`/patients/${p.id}`)} className="flex items-center gap-3 text-right">
                          <Avatar name={p.name} size="sm" />
                          <span className="font-semibold text-slate-700 dark:text-slate-200">{p.name}</span>
                        </button>
                      </td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400" dir="ltr">{p.phone}</td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{p.age}</td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{GENDER_LABELS[p.gender]}</td>
                      <td className="px-5 py-3">
                        <span className="rounded-lg bg-blue-50 px-2 py-1 text-xs font-bold text-blue-600 dark:bg-blue-500/15 dark:text-blue-300">
                          {s?.visitsCount ?? 0}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{formatDate(s?.lastVisit)}</td>
                      <td className="px-5 py-3 font-semibold text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(s?.totalPaid ?? 0)}
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <IconBtn title="عرض" onClick={() => navigate(`/patients/${p.id}`)}>
                            <Eye className="h-4 w-4" />
                          </IconBtn>
                          <IconBtn title="تعديل" onClick={() => { setEditing(p); setModalOpen(true); }}>
                            <Pencil className="h-4 w-4" />
                          </IconBtn>
                          <IconBtn title="حذف" danger onClick={() => setDeleteId(p.id)}>
                            <Trash2 className="h-4 w-4" />
                          </IconBtn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {!loading && rows.length > 0 && (
          <Pagination
            page={page}
            pageCount={pageCount}
            total={rows.length}
            pageSize={pageSize}
            onPage={setPage}
            onPageSize={setPageSize}
          />
        )}
      </Card>

      <PatientModal
        open={modalOpen}
        patient={editing}
        onClose={() => setModalOpen(false)}
        onSubmit={async (values) => {
          if (editing) await updatePatient(editing.id, values);
          else await createPatient(values);
        }}
      />

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        loading={false}
        danger
        message="هل أنت متأكد من حذف هذا المريض؟ سيتم الإخفاء فقط مع الاحتفاظ بالسجلات."
        onConfirm={async () => {
          if (deleteId) await deletePatient(deleteId);
          setDeleteId(null);
        }}
      />
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  title,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  danger?: boolean;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded-lg p-2 transition-colors ${
        danger
          ? "text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/15"
          : "text-slate-400 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-brand-500/15"
      }`}
    >
      {children}
    </button>
  );
}

const NAME_RE = /^[\u0600-\u06FFa-zA-Z\s]+$/;

function PatientModal({
  open,
  patient,
  onClose,
  onSubmit,
}: {
  open: boolean;
  patient: Patient | null;
  onClose: () => void;
  onSubmit: (values: any) => Promise<void>;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<Gender>("male");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(patient?.name ?? "");
      setPhone(patient?.phone ?? "");
      setAge(patient?.age ? String(patient.age) : "");
      setGender(patient?.gender ?? "male");
      setAddress(patient?.address ?? "");
      setNotes(patient?.notes ?? "");
      setErrors({});
      setFormError(null);
    }
  }, [open, patient]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (name.trim().length < 3) e.name = "الاسم يجب أن يكون 3 أحرف على الأقل";
    else if (name.trim().length > 100) e.name = "الاسم طويل جداً";
    else if (!NAME_RE.test(name.trim())) e.name = "الاسم يجب أن يحتوي أحرف عربية أو إنجليزية فقط";
    if (!/^01[0-9]{9}$/.test(phone.trim())) e.phone = "رقم هاتف غير صحيح (مثال: 01012345678)";
    const ageN = Number(age);
    if (!age || isNaN(ageN)) e.age = "العمر مطلوب";
    else if (ageN < 1 || ageN > 120) e.age = "العمر يجب أن يكون بين 1 و 120";
    else if (!Number.isInteger(ageN)) e.age = "العمر يجب أن يكون رقماً صحيحاً";
    if (address.length > 250) e.address = "العنوان طويل جداً (حد أقصى 250 حرف)";
    if (notes.length > 1000) e.notes = "الملاحظات طويلة جداً (حد أقصى 1000 حرف)";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    setFormError(null);
    try {
      await onSubmit({
        name: name.trim(),
        phone: phone.trim(),
        age: Number(age),
        gender,
        address: address.trim(),
        notes: notes.trim(),
      });
      onClose();
    } catch {
      setFormError("تعذر حفظ البيانات. تحقق من البيانات وحاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={patient ? "تعديل بيانات المريض" : "إضافة مريض جديد"} subtitle="الحقول المطلوبة مميزة بعلامة *">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label="الاسم بالكامل" required error={errors.name}>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: أحمد محمد علي" />
          </Field>
        </div>
        <Field label="رقم الهاتف" required error={errors.phone}>
          <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="01012345678" dir="ltr" />
        </Field>
        <Field label="العمر" required error={errors.age}>
          <Input type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="25" />
        </Field>
        <Field label="الجنس" required>
          <Select value={gender} onChange={(e) => setGender(e.target.value as Gender)}>
            <option value="male">ذكر</option>
            <option value="female">أنثى</option>
          </Select>
        </Field>
        <Field label="العنوان" error={errors.address}>
          <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="العنوان (اختياري)" />
        </Field>
        <div className="sm:col-span-2">
          <Field label="ملاحظات" error={errors.notes}>
            <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات إضافية (اختياري)" />
          </Field>
        </div>
      </div>
      {formError && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 dark:bg-rose-500/10">{formError}</p>}
      <div className="mt-5 flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose} disabled={submitting}>
          إلغاء
        </Button>
        <Button className="flex-1" loading={submitting} onClick={submit}>
          {submitting ? "جاري الحفظ..." : "حفظ"}
        </Button>
      </div>
    </Modal>
  );
}
