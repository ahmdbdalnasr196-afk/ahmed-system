"use client";

import { useEffect, useMemo, useState } from "react";
import { Eye, Pencil, Plus, RefreshCw, Trash2 } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import type { Visit, PatientSearchResult } from "@/types";
import {
  Avatar,
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Pagination,
  SearchInput,
  Select,
  Skeleton,
  Textarea,
} from "@/components/ui";
import { formatCurrency, formatDate, todayKey } from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";
import { PatientSelector, type PatientSelectorValue } from "@/components/PatientPicker";

function payStatus(v: Visit) {
  if (v.remainingAmount <= 0) return { label: "مدفوع", cls: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300" };
  if (v.paidAmount <= 0) return { label: "غير مدفوع", cls: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300" };
  return { label: "جزئي", cls: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" };
}

export default function Visits() {
  const { data, createVisit, updateVisit, deleteVisit } = useApp();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("all");
  const [serviceFilter, setServiceFilter] = useState("all");
  const [payFilter, setPayFilter] = useState<"all" | "paid" | "partial" | "unpaid">("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Visit | null>(null);
  const [viewing, setViewing] = useState<Visit | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const patientName = (id: string) => data.patients.find((p) => p.id === id)?.name ?? "—";
  const doctorName = (id: string) => data.doctors.find((d) => d.id === id)?.name ?? "—";
  const serviceName = (id: string) => data.services.find((s) => s.id === id)?.name ?? "—";

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...data.visits]
      .filter((v) => !v.isDeleted)
      .filter((v) => {
        if (q && !(patientName(v.patientId).toLowerCase().includes(q) || doctorName(v.doctorId).toLowerCase().includes(q) || serviceName(v.serviceId).toLowerCase().includes(q)))
          return false;
        if (from && v.visitDate < from) return false;
        if (to && v.visitDate > to) return false;
        if (doctorFilter !== "all" && v.doctorId !== doctorFilter) return false;
        if (serviceFilter !== "all" && v.serviceId !== serviceFilter) return false;
        if (payFilter === "paid" && v.remainingAmount > 0) return false;
        if (payFilter === "unpaid" && v.paidAmount > 0) return false;
        if (payFilter === "partial" && !(v.paidAmount > 0 && v.remainingAmount > 0)) return false;
        return true;
      })
      .sort((a, b) => (a.visitDate < b.visitDate ? 1 : -1));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.visits, data.patients, data.doctors, data.services, query, from, to, doctorFilter, serviceFilter, payFilter]);

  useEffect(() => setPage(1), [query, from, to, doctorFilter, serviceFilter, payFilter, pageSize]);
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  const totalRevenue = useMemo(() => data.visits.filter((v) => !v.isDeleted).reduce((s, v) => s + v.paidAmount, 0), [data.visits]);

  return (
    <div>
      <PageHeader
        title="🩺 الزيارات"
        subtitle={`${data.visits.filter((v) => !v.isDeleted).length} زيارة • إجمالي ${formatCurrency(totalRevenue)}`}
        actions={
          <>
            <Button variant="secondary" loading={refreshing} onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 600); }}>
              <RefreshCw className="h-4 w-4" /> تحديث
            </Button>
            <Button onClick={() => { setEditing(null); setModalOpen(true); }}>
              <Plus className="h-4 w-4" /> تسجيل زيارة
            </Button>
          </>
        }
      />

      <Card className="mb-4 p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-4">
          <SearchInput value={query} onChange={setQuery} placeholder="بحث..." />
          <div className="flex gap-2">
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} title="من تاريخ" />
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} title="إلى تاريخ" />
          </div>
          <Select value={doctorFilter} onChange={(e) => setDoctorFilter(e.target.value)}>
            <option value="all">كل الأطباء</option>
            {data.doctors.filter((d) => !d.isDeleted && d.isActive).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
          <Select value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)}>
            <option value="all">كل الخدمات</option>
            {data.services.filter((s) => !s.isDeleted && s.isActive).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
          <Select value={payFilter} onChange={(e) => setPayFilter(e.target.value as any)}>
            <option value="all">كل حالات الدفع</option>
            <option value="paid">مدفوع</option>
            <option value="partial">جزئي</option>
            <option value="unpaid">غير مدفوع</option>
          </Select>
        </div>
      </Card>

      <Card className="overflow-hidden">
        {loading ? (
          <div className="space-y-3 p-5">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : rows.length === 0 ? (
          <EmptyState emoji="🩺" title="لا توجد زيارات حتى الآن" description="سجّل أول زيارة." action={<Button onClick={() => { setEditing(null); setModalOpen(true); }}><Plus className="h-4 w-4" /> تسجيل زيارة</Button>} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-right text-xs font-bold text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                  <th className="px-4 py-3">المريض</th>
                  <th className="px-4 py-3">الطبيب</th>
                  <th className="px-4 py-3">الخدمة</th>
                  <th className="px-4 py-3">التاريخ</th>
                  <th className="px-4 py-3">المبلغ</th>
                  <th className="px-4 py-3">المدفوع</th>
                  <th className="px-4 py-3">المتبقي</th>
                  <th className="px-4 py-3">الحالة</th>
                  <th className="px-4 py-3 text-left">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {pageRows.map((v) => {
                  const ps = payStatus(v);
                  return (
                    <tr key={v.id} className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                      <td className="px-4 py-3">
                        <button onClick={() => setViewing(v)} className="flex items-center gap-2 text-right">
                          <Avatar name={patientName(v.patientId)} size="sm" />
                          <span className="font-semibold text-slate-700 dark:text-slate-200">{patientName(v.patientId)}</span>
                        </button>
                      </td>
                      <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{doctorName(v.doctorId)}</td>
                      <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{serviceName(v.serviceId)}</td>
                      <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{formatDate(v.visitDate)}</td>
                      <td className="px-4 py-3 font-semibold text-slate-600 dark:text-slate-300">{formatCurrency(v.servicePrice)}</td>
                      <td className="px-4 py-3 font-semibold text-emerald-600 dark:text-emerald-400">{formatCurrency(v.paidAmount)}</td>
                      <td className="px-4 py-3 font-semibold text-amber-600 dark:text-amber-400">{formatCurrency(v.remainingAmount)}</td>
                      <td className="px-4 py-3"><Badge className={ps.cls}>{ps.label}</Badge></td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <IconBtn title="عرض" onClick={() => setViewing(v)}><Eye className="h-4 w-4" /></IconBtn>
                          <IconBtn title="تعديل" onClick={() => { setEditing(v); setModalOpen(true); }}><Pencil className="h-4 w-4" /></IconBtn>
                          <IconBtn title="حذف" danger onClick={() => setDeleteId(v.id)}><Trash2 className="h-4 w-4" /></IconBtn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {!loading && rows.length > 0 && (
          <Pagination page={page} pageCount={pageCount} total={rows.length} pageSize={pageSize} onPage={setPage} onPageSize={setPageSize} />
        )}
      </Card>

      <VisitModal
        open={modalOpen}
        editing={editing}
        doctors={data.doctors.filter((d) => !d.isDeleted && d.isActive)}
        services={data.services.filter((s) => !s.isDeleted && s.isActive)}
        existingPatient={null}
        onClose={() => setModalOpen(false)}
        onCreate={async (v) => { await createVisit(v); }}
        onUpdate={async (id, v) => { await updateVisit(id, v); }}
      />

      <VisitDetail visit={viewing} patientName={viewing ? patientName(viewing.patientId) : ""} doctorName={viewing ? doctorName(viewing.doctorId) : ""} serviceName={viewing ? serviceName(viewing.serviceId) : ""} onClose={() => setViewing(null)} />

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        danger
        message="هل أنت متأكد من حذف هذه الزيارة؟"
        onConfirm={async () => { if (deleteId) await deleteVisit(deleteId); setDeleteId(null); }}
      />
    </div>
  );
}

function IconBtn({ children, onClick, title, danger }: { children: React.ReactNode; onClick: () => void; title: string; danger?: boolean }) {
  return (
    <button title={title} onClick={onClick} className={`rounded-lg p-2 transition-colors ${danger ? "text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/15" : "text-slate-400 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-brand-500/15"}`}>
      {children}
    </button>
  );
}

function VisitModal({
  open,
  editing,
  doctors,
  services,
  existingPatient,
  onClose,
  onCreate,
  onUpdate,
}: {
  open: boolean;
  editing: Visit | null;
  doctors: { id: string; name: string }[];
  services: { id: string; name: string; price: number }[];
  existingPatient: PatientSearchResult | null;
  onClose: () => void;
  onCreate: (v: any) => Promise<void>;
  onUpdate: (id: string, v: any) => Promise<void>;
}) {
  const isEdit = !!editing;
  const [patient, setPatient] = useState<PatientSelectorValue>({ name: "", phone: "", manual: false });
  const [doctorId, setDoctorId] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [visitDate, setVisitDate] = useState(todayKey());
  const [price, setPrice] = useState("");
  const [paid, setPaid] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [treatmentPlan, setTreatmentPlan] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setPatient(
        existingPatient
          ? { patientId: existingPatient.id, name: existingPatient.name, phone: existingPatient.phone, manual: false }
          : { name: "", phone: "", manual: false }
      );
      setDoctorId(editing?.doctorId ?? doctors[0]?.id ?? "");
      setServiceId(editing?.serviceId ?? services[0]?.id ?? "");
      setVisitDate(editing?.visitDate ?? todayKey());
      setPrice(editing ? String(editing.servicePrice) : String(services[0]?.price ?? ""));
      setPaid(editing ? String(editing.paidAmount) : "");
      setDiagnosis(editing?.diagnosis ?? "");
      setTreatmentPlan(editing?.treatmentPlan ?? "");
      setNotes(editing?.notes ?? "");
      setFormError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  // Auto-fill price when service changes (create mode)
  useEffect(() => {
    if (!isEdit) {
      const s = services.find((x) => x.id === serviceId);
      if (s) setPrice(String(s.price));
    }
  }, [serviceId, services, isEdit]);

  const remaining = Math.max((Number(price) || 0) - (Number(paid) || 0), 0);

  const submit = async () => {
    if (!isEdit && !patient.name.trim()) return setFormError("اسم المريض مطلوب");
    if (!isEdit && !patient.manual && !patient.patientId && !/^01[0-9]{9}$/.test(patient.phone.trim()))
      return setFormError("رقم هاتف غير صحيح");
    if (!doctorId || !serviceId) return setFormError("اختر الطبيب والخدمة");
    if (!price) return setFormError("السعر مطلوب");
    setSubmitting(true);
    setFormError(null);
    try {
      const doctor = doctors.find((d) => d.id === doctorId)!;
      const service = services.find((s) => s.id === serviceId)!;
      if (isEdit && editing) {
        await onUpdate(editing.id, { serviceId, servicePrice: Number(price), paidAmount: Number(paid) || 0, diagnosis, treatmentPlan, notes });
      } else {
        await onCreate({
          patientId: patient.patientId,
          patientName: patient.name.trim(),
          phone: patient.phone.trim(),
          doctorName: doctor.name,
          serviceName: service.name,
          visitDate,
          price: Number(price),
          paid: Number(paid) || 0,
          diagnosis,
          treatmentPlan,
          notes,
        });
      }
      onClose();
    } catch (e: any) {
      setFormError(e?.message || "تعذر حفظ الزيارة");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? "تعديل الزيارة" : "تسجيل زيارة جديدة"} size="lg">
      <div className="space-y-4">
        {!isEdit && (
          <PatientSelector value={patient} onChange={setPatient} initialPatient={null} error={formError && !patient.name ? formError : undefined} />
        )}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="👨‍⚕️ الطبيب" required>
          <Select value={doctorId} onChange={(e) => setDoctorId(e.target.value)} disabled={isEdit}>
            {doctors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
        </Field>
        <Field label="الخدمة" required>
          <Select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
            {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </Field>
        <Field label="تاريخ الزيارة" required>
          <Input type="date" value={visitDate} onChange={(e) => setVisitDate(e.target.value)} disabled={isEdit} />
        </Field>
        <Field label="سعر الخدمة (ج.م)" required hint="يُملأ تلقائياً من الخدمة الحالية">
          <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} />
        </Field>
        <Field label="المبلغ المدفوع (ج.م)">
          <Input type="number" value={paid} onChange={(e) => setPaid(e.target.value)} placeholder="0" />
        </Field>
        <div className="flex items-end">
          <div className="w-full rounded-xl bg-amber-50 px-4 py-2.5 dark:bg-amber-500/10">
            <p className="text-xs text-amber-600 dark:text-amber-400">المتبقي</p>
            <p className="text-lg font-extrabold text-amber-700 dark:text-amber-300">{formatCurrency(remaining)}</p>
          </div>
        </div>
        <div className="sm:col-span-2">
          <Field label="التشخيص">
            <Input value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} placeholder="التشخيص الطبي" />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="خطة العلاج">
            <Input value={treatmentPlan} onChange={(e) => setTreatmentPlan(e.target.value)} placeholder="خطة العلاج المقترحة" />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="ملاحظات">
            <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات إضافية" />
          </Field>
        </div>
      </div>
      {formError && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 dark:bg-rose-500/10">{formError}</p>}
      <div className="flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose} disabled={submitting}>إلغاء</Button>
        <Button className="flex-1" loading={submitting} onClick={submit}>{submitting ? "جاري الحفظ..." : "حفظ الزيارة"}</Button>
      </div>
      </div>
    </Modal>
  );
}

function VisitDetail({ visit, patientName, doctorName, serviceName, onClose }: { visit: Visit | null; patientName: string; doctorName: string; serviceName: string; onClose: () => void }) {
  if (!visit) return null;
  const ps = payStatus(visit);
  return (
    <Modal open={!!visit} onClose={onClose} title="تفاصيل الزيارة">
      <div className="flex items-center gap-3">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-2xl text-white">
          {serviceEmoji(serviceName)}
        </div>
        <div>
          <h3 className="text-lg font-extrabold text-slate-800 dark:text-white">{serviceName}</h3>
          <Badge className={ps.cls}>{ps.label}</Badge>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
        <DetailRow label="المريض" value={patientName} />
        <DetailRow label="الطبيب" value={doctorName} />
        <DetailRow label="التاريخ" value={formatDate(visit.visitDate)} />
        <DetailRow label="المبلغ" value={formatCurrency(visit.servicePrice)} />
        <DetailRow label="المدفوع" value={formatCurrency(visit.paidAmount)} />
        <DetailRow label="المتبقي" value={formatCurrency(visit.remainingAmount)} />
      </div>
      {(visit.diagnosis || visit.treatmentPlan || visit.notes) && (
        <div className="mt-3 space-y-1 rounded-xl bg-slate-50 p-3 text-sm dark:bg-slate-800/50">
          {visit.diagnosis && <p className="text-slate-600 dark:text-slate-300"><b>التشخيص:</b> {visit.diagnosis}</p>}
          {visit.treatmentPlan && <p className="text-slate-600 dark:text-slate-300"><b>خطة العلاج:</b> {visit.treatmentPlan}</p>}
          {visit.notes && <p className="text-slate-600 dark:text-slate-300"><b>ملاحظات:</b> {visit.notes}</p>}
        </div>
      )}
      <Button className="mt-5 w-full" onClick={onClose}>إغلاق</Button>
    </Modal>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-100 px-3 py-2 dark:border-slate-800">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="font-semibold text-slate-700 dark:text-slate-200">{value}</p>
    </div>
  );
}
