"use client";

// =============================================================================
// Analytics — business intelligence surface for the clinic owner.
//
// Fetches all reports for the selected period in parallel and renders six
// charts: revenue area, appointments line, patient growth bar, completed vs
// cancelled donut, doctor performance bar, service popularity bar.
// =============================================================================

import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "@/lib/api";
import { Card, CardHeader, Segmented, Skeleton, EmptyState } from "@/components/ui";
import { cn } from "@/utils/cn";
import { formatCurrency, formatNumber } from "@/utils/format";
import { STATUS_HEX } from "@/utils/domain";
import type { ChartPoint, ReportPeriod } from "@/types";

const PERIOD_OPTIONS: { value: ReportPeriod; label: string }[] = [
  { value: "week", label: "آخر ٧ أيام" },
  { value: "month", label: "آخر ٣٠ يوم" },
  { value: "3months", label: "آخر ٣ شهور" },
  { value: "6months", label: "آخر ٦ شهور" },
  { value: "year", label: "آخر سنة" },
];

const PALETTE = ["#3b82f6", "#8b5cf6", "#10b981", "#f59e0b", "#f43f5e", "#06b6d4", "#ec4899", "#84cc16"];

// -----------------------------------------------------------------------------
// Chart card wrapper
// -----------------------------------------------------------------------------
function ChartCard({
  title,
  subtitle,
  icon,
  children,
  className,
  action,
}: {
  title: string;
  subtitle?: string;
  icon: string;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader title={title} subtitle={subtitle} icon={icon} action={action} />
      <div className="p-4">{children}</div>
    </Card>
  );
}

// -----------------------------------------------------------------------------
// Component
// -----------------------------------------------------------------------------
export default function Analytics() {
  const [period, setPeriod] = useState<ReportPeriod>("month");
  const [loading, setLoading] = useState(true);

  const [revenue, setRevenue] = useState<{
    totalRevenue: number; averageVisitValue: number; completedVisits: number; chart: ChartPoint[];
  } | null>(null);
  const [appts, setAppts] = useState<{
    appointmentsCount: number; pending: number; confirmed: number;
    completed: number; cancelled: number; no_show: number; chart: ChartPoint[];
  } | null>(null);
  const [patients, setPatients] = useState<{
    totalPatients: number; newPatients: number; returningPatients: number; chart: ChartPoint[];
  } | null>(null);
  const [doctors, setDoctors] = useState<{
    id: string; name: string; specialty: string; visits: number;
    revenue: number; patients: number; topService: string;
  }[]>([]);
  const [services, setServices] = useState<{ name: string; count: number; revenue: number }[]>([]);

  useEffect(() => {
    let cancelled = false;
    // Wrapped in an async IIFE so setLoading is called from a callback,
    // not synchronously in the effect body (avoids cascading renders).
    (async () => {
      setLoading(true);
      try {
        const [r, a, p, d, s] = await Promise.all([
          api.revenueReport(period),
          api.appointmentsReport(period),
          api.patientsReport(period),
          api.doctorsReport(period),
          api.servicesReport(period),
        ]);
        if (cancelled) return;
        setRevenue(r as any);
        setAppts(a as any);
        setPatients(p as any);
        setDoctors(d as any);
        setServices(s as any);
      } catch {
        /* keep last known — analytics are non-critical */
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [period]);

  // Derived chart data
  const completedCancelledData = useMemo(() => {
    if (!appts) return [];
    return [
      { name: "مكتمل", value: appts.completed, color: STATUS_HEX.completed },
      { name: "مؤكد", value: appts.confirmed, color: STATUS_HEX.confirmed },
      { name: "قيد الانتظار", value: appts.pending, color: STATUS_HEX.pending },
      { name: "ملغي", value: appts.cancelled, color: STATUS_HEX.cancelled },
      { name: "لم يحضر", value: appts.no_show, color: STATUS_HEX.no_show },
    ].filter((x) => x.value > 0);
  }, [appts]);

  const doctorsBarData = useMemo(
    () => doctors.map((d) => ({ name: d.name, visits: d.visits, revenue: d.revenue })),
    [doctors]
  );
  const servicesBarData = useMemo(
    () => services.slice(0, 8).map((s) => ({ name: s.name, count: s.count, revenue: s.revenue })),
    [services]
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Period selector */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 dark:text-white">
            تحليلات الأعمال
          </h2>
          <p className="text-sm text-slate-400">
            اختر الفترة الزمنية لعرض التقارير التفصيلية
          </p>
        </div>
        <Segmented options={PERIOD_OPTIONS} value={period} onChange={setPeriod} />
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="p-4">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الإيرادات</p>
          {loading || !revenue ? (
            <Skeleton className="mt-2 h-7 w-28" />
          ) : (
            <p className="mt-1 text-xl font-extrabold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(revenue.totalRevenue)}
            </p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">زيارات مكتملة</p>
          {loading || !revenue ? (
            <Skeleton className="mt-2 h-7 w-20" />
          ) : (
            <p className="mt-1 text-xl font-extrabold text-brand-600 dark:text-brand-300">
              {formatNumber(revenue.completedVisits)}
            </p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي المواعيد</p>
          {loading || !appts ? (
            <Skeleton className="mt-2 h-7 w-20" />
          ) : (
            <p className="mt-1 text-xl font-extrabold text-amber-600 dark:text-amber-300">
              {formatNumber(appts.appointmentsCount)}
            </p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">مرضى جدد</p>
          {loading || !patients ? (
            <Skeleton className="mt-2 h-7 w-20" />
          ) : (
            <p className="mt-1 text-xl font-extrabold text-violet-600 dark:text-violet-300">
              {formatNumber(patients.newPatients)}
            </p>
          )}
        </Card>
      </div>

      {/* Charts row 1 — revenue + appointments */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ChartCard title="اتجاه الإيرادات" subtitle="إيرادات الزيارات المدفوعة" icon="💰">
          {loading || !revenue ? (
            <Skeleton className="h-64 w-full rounded-xl" />
          ) : revenue.chart.length === 0 ? (
            <EmptyState emoji="💰" title="لا بيانات" />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenue.chart} margin={{ top: 10, right: 5, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748b", fontFamily: "Cairo" }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#64748b" }} tickLine={false} axisLine={false} width={40} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    formatter={(v: any) => [formatCurrency(v as number), "الإيراد"]}
                  />
                  <Area type="monotone" dataKey="amount" stroke="#10b981" strokeWidth={2.5} fill="url(#revFill)" dot={false} activeDot={{ r: 5 }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>

        <ChartCard title="اتجاه المواعيد" subtitle="عدد المواعيد المحجوزة" icon="📅">
          {loading || !appts ? (
            <Skeleton className="h-64 w-full rounded-xl" />
          ) : appts.chart.length === 0 ? (
            <EmptyState emoji="📅" title="لا بيانات" />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={appts.chart} margin={{ top: 10, right: 5, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748b", fontFamily: "Cairo" }} tickLine={false} axisLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#64748b" }} tickLine={false} axisLine={false} width={28} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    formatter={(v: any) => [`${v} موعد`, "المواعيد"]}
                  />
                  <Line type="monotone" dataKey="count" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 3, fill: "#3b82f6" }} activeDot={{ r: 5 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>
      </div>

      {/* Charts row 2 — patient growth + status donut */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <ChartCard title="نمو المرضى" subtitle="المرضى الجدد" icon="👥" className="lg:col-span-2">
          {loading || !patients ? (
            <Skeleton className="h-64 w-full rounded-xl" />
          ) : patients.chart.length === 0 ? (
            <EmptyState emoji="👥" title="لا بيانات" />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={patients.chart} margin={{ top: 10, right: 5, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748b", fontFamily: "Cairo" }} tickLine={false} axisLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#64748b" }} tickLine={false} axisLine={false} width={28} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    cursor={{ fill: "rgba(139,92,246,0.08)" }}
                    formatter={(v: any) => [`${v} مريض`, "جدد"]}
                  />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[6, 6, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>

        <ChartCard title="حالات المواعيد" subtitle="توزيع الحالات" icon="🥧">
          {loading || !appts ? (
            <Skeleton className="h-64 w-full rounded-xl" />
          ) : completedCancelledData.length === 0 ? (
            <EmptyState emoji="🥧" title="لا بيانات" />
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={completedCancelledData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={85}
                    paddingAngle={3}
                  >
                    {completedCancelledData.map((entry, idx) => (
                      <Cell key={idx} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    formatter={(v: any, n: any) => [`${v} موعد`, n]}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    wrapperStyle={{ fontSize: 11, fontFamily: "Cairo" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>
      </div>

      {/* Charts row 3 — doctors + services */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ChartCard title="أداء الأطباء" subtitle="عدد الزيارات لكل طبيب" icon="👨‍⚕️">
          {loading ? (
            <Skeleton className="h-72 w-full rounded-xl" />
          ) : doctorsBarData.length === 0 ? (
            <EmptyState emoji="👨‍⚕️" title="لا بيانات" />
          ) : (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={doctorsBarData}
                  layout="vertical"
                  margin={{ top: 5, right: 10, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: "#64748b" }} tickLine={false} axisLine={false} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={100}
                    tick={{ fontSize: 11, fill: "#64748b", fontFamily: "Cairo" }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    cursor={{ fill: "rgba(59,130,246,0.08)" }}
                    formatter={(v: any) => [`${v} زيارة`, "الزيارات"]}
                  />
                  <Bar dataKey="visits" radius={[0, 6, 6, 0]} maxBarSize={22}>
                    {doctorsBarData.map((_, idx) => (
                      <Cell key={idx} fill={PALETTE[idx % PALETTE.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>

        <ChartCard title="شعبية الخدمات" subtitle="عدد الزيارات لكل خدمة" icon="🦷">
          {loading ? (
            <Skeleton className="h-72 w-full rounded-xl" />
          ) : servicesBarData.length === 0 ? (
            <EmptyState emoji="🦷" title="لا بيانات" />
          ) : (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={servicesBarData}
                  layout="vertical"
                  margin={{ top: 5, right: 10, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: "#64748b" }} tickLine={false} axisLine={false} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={110}
                    tick={{ fontSize: 10, fill: "#64748b", fontFamily: "Cairo" }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontFamily: "Cairo", fontSize: 12 }}
                    cursor={{ fill: "rgba(16,185,129,0.08)" }}
                    formatter={(v: any) => [`${v} زيارة`, "الزيارات"]}
                  />
                  <Bar dataKey="count" radius={[0, 6, 6, 0]} maxBarSize={22}>
                    {servicesBarData.map((_, idx) => (
                      <Cell key={idx} fill={PALETTE[(idx + 2) % PALETTE.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </ChartCard>
      </div>

      {/* Doctor leaderboard table */}
      <Card className="overflow-hidden">
        <CardHeader title="ترتيب الأطباء حسب الإيرادات" icon="🏆" />
        {loading ? (
          <div className="space-y-2 p-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-10 w-full rounded-lg" />
            ))}
          </div>
        ) : doctors.length === 0 ? (
          <EmptyState emoji="🏆" title="لا بيانات للأطباء" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="border-b border-slate-100 bg-slate-50/70 text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-400">
                <tr>
                  <th className="px-5 py-3 font-bold">#</th>
                  <th className="px-3 py-3 font-bold">الطبيب</th>
                  <th className="px-3 py-3 font-bold">التخصص</th>
                  <th className="px-3 py-3 font-bold">الزيارات</th>
                  <th className="px-3 py-3 font-bold">المرضى</th>
                  <th className="px-3 py-3 font-bold">الخدمة الأكثر</th>
                  <th className="px-5 py-3 font-bold">الإيراد</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {doctors.map((d, i) => (
                  <tr key={d.id} className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                    <td className="px-5 py-3">
                      <span
                        className={cn(
                          "inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold",
                          i === 0
                            ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                            : i === 1
                            ? "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200"
                            : i === 2
                            ? "bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300"
                            : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                        )}
                      >
                        {i + 1}
                      </span>
                    </td>
                    <td className="px-3 py-3 font-bold text-slate-800 dark:text-white">{d.name}</td>
                    <td className="px-3 py-3 text-slate-500 dark:text-slate-400">{d.specialty}</td>
                    <td className="px-3 py-3 font-semibold text-brand-600 dark:text-brand-300">{d.visits}</td>
                    <td className="px-3 py-3 text-slate-600 dark:text-slate-300">{d.patients}</td>
                    <td className="px-3 py-3 text-xs text-slate-500 dark:text-slate-400">{d.topService}</td>
                    <td className="px-5 py-3 font-bold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(d.revenue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
