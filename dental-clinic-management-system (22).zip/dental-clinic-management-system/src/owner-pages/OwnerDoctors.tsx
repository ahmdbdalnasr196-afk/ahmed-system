"use client";

// =============================================================================
// OwnerDoctors — doctor performance monitoring (owner view).
//
// For each doctor, compute from real visits + appointments:
//   • name, specialty, working hours (12h)
//   • appointment count, completed visits, revenue, top service
// Performance ranking by revenue.
// =============================================================================

import { useMemo } from "react";
import { useApp } from "@/contexts/AppContext";
import { Avatar, Card, CardHeader, EmptyState, Skeleton } from "@/components/ui";
import { cn } from "@/utils/cn";
import { formatCurrency, formatNumber, to12h } from "@/utils/format";
import { DAY_LABELS, serviceEmoji } from "@/utils/domain";
import type { Doctor } from "@/types";

interface DoctorStat {
  doctor: Doctor;
  appointmentsCount: number;
  completedVisits: number;
  revenue: number;
  topService: string | null;
  uniquePatients: number;
  rank?: number;
}

export default function OwnerDoctors() {
  const { data, loading } = useApp();

  const stats = useMemo<DoctorStat[]>(() => {
    const doctors = data.doctors.filter((d) => !d.isDeleted && d.isActive);
    const appts = data.appointments.filter((a) => !a.isDeleted);
    const visits = data.visits.filter((v) => !v.isDeleted);

    const out: DoctorStat[] = doctors.map((doctor) => {
      const docAppts = appts.filter((a) => a.doctorId === doctor.id);
      const docVisits = visits.filter((v) => v.doctorId === doctor.id);

      // Top service by visit count
      const svcCount: Record<string, number> = {};
      docVisits.forEach((v) => {
        const name = v.serviceName || "";
        if (name) svcCount[name] = (svcCount[name] || 0) + 1;
      });
      const topService =
        Object.entries(svcCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

      return {
        doctor,
        appointmentsCount: docAppts.length,
        completedVisits: docVisits.length,
        revenue: docVisits.reduce((s, v) => s + (v.paidAmount || 0), 0),
        topService,
        uniquePatients: new Set(docVisits.map((v) => v.patientId)).size,
      };
    });

    // Rank by revenue desc
    return out
      .sort((a, b) => b.revenue - a.revenue)
      .map((s, i) => ({ ...s, rank: i + 1 }));
  }, [data.doctors, data.appointments, data.visits]);

  if (loading && stats.length === 0) {
    return (
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-72 rounded-2xl" />
        ))}
      </div>
    );
  }

  const maxRevenue = Math.max(1, ...stats.map((s) => s.revenue));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header summary */}
      <Card className="overflow-hidden">
        <CardHeader
          title="أداء الأطباء"
          icon="👨‍⚕️"
          subtitle={`${formatNumber(stats.length)} طبيب نشط • مرتبة حسب الإيرادات`}
        />
        <div className="grid grid-cols-2 gap-4 p-5 lg:grid-cols-4">
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الإيرادات</p>
            <p className="mt-1 text-xl font-extrabold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(stats.reduce((s, d) => s + d.revenue, 0))}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الزيارات</p>
            <p className="mt-1 text-xl font-extrabold text-brand-600 dark:text-brand-300">
              {formatNumber(stats.reduce((s, d) => s + d.completedVisits, 0))}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي المواعيد</p>
            <p className="mt-1 text-xl font-extrabold text-amber-600 dark:text-amber-300">
              {formatNumber(stats.reduce((s, d) => s + d.appointmentsCount, 0))}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">مرضى فريدون</p>
            <p className="mt-1 text-xl font-extrabold text-violet-600 dark:text-violet-300">
              {formatNumber(stats.reduce((s, d) => s + d.uniquePatients, 0))}
            </p>
          </div>
        </div>
      </Card>

      {/* Doctor cards */}
      {stats.length === 0 ? (
        <Card>
          <EmptyState
            emoji="👨‍⚕️"
            title="لا يوجد أطباء"
            description="لم يتم تسجيل أي أطباء نشطين بعد"
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {stats.map((s) => {
            const rank = s.rank || 0;
            const rankBadge =
              rank === 1
                ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                : rank === 2
                ? "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200"
                : rank === 3
                ? "bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300"
                : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400";
            const revenuePct = Math.round((s.revenue / maxRevenue) * 100);
            return (
              <Card key={s.doctor.id} className="overflow-hidden">
                <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-4 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <Avatar name={s.doctor.name} size="lg" src={s.doctor.image} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="truncate text-base font-bold text-slate-800 dark:text-white">
                          {s.doctor.name}
                        </h3>
                        <span
                          className={cn(
                            "inline-flex h-6 min-w-6 items-center justify-center rounded-full px-1.5 text-[11px] font-bold",
                            rankBadge
                          )}
                          title={`المرتبة #${rank}`}
                        >
                          #{rank}
                        </span>
                      </div>
                      <p className="truncate text-xs text-slate-400">{s.doctor.specialty}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 px-5 py-4 text-sm">
                  <div className="rounded-xl bg-slate-50/70 px-3 py-2.5 dark:bg-slate-800/40">
                    <p className="text-[11px] font-semibold text-slate-400">المواعيد</p>
                    <p className="text-lg font-extrabold text-amber-600 dark:text-amber-300">
                      {formatNumber(s.appointmentsCount)}
                    </p>
                  </div>
                  <div className="rounded-xl bg-slate-50/70 px-3 py-2.5 dark:bg-slate-800/40">
                    <p className="text-[11px] font-semibold text-slate-400">الزيارات المكتملة</p>
                    <p className="text-lg font-extrabold text-emerald-600 dark:text-emerald-300">
                      {formatNumber(s.completedVisits)}
                    </p>
                  </div>
                  <div className="rounded-xl bg-slate-50/70 px-3 py-2.5 dark:bg-slate-800/40">
                    <p className="text-[11px] font-semibold text-slate-400">مرضى فريدون</p>
                    <p className="text-lg font-extrabold text-violet-600 dark:text-violet-300">
                      {formatNumber(s.uniquePatients)}
                    </p>
                  </div>
                  <div className="rounded-xl bg-slate-50/70 px-3 py-2.5 dark:bg-slate-800/40">
                    <p className="text-[11px] font-semibold text-slate-400">الإيراد</p>
                    <p className="text-lg font-extrabold text-brand-600 dark:text-brand-300">
                      {formatCurrency(s.revenue)}
                    </p>
                  </div>
                </div>

                {/* Revenue bar */}
                <div className="px-5 pb-3">
                  <div className="mb-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>الحصة من الإيرادات</span>
                    <span className="font-bold">{revenuePct}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                    <div
                      className="h-full rounded-full bg-gradient-to-l from-brand-600 to-brand-400"
                      style={{ width: `${revenuePct}%` }}
                    />
                  </div>
                </div>

                {/* Meta */}
                <div className="space-y-2 border-t border-slate-100 px-5 py-4 text-xs dark:border-slate-800">
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">🕐 ساعات العمل:</span>
                    <span className="font-semibold">
                      {to12h(s.doctor.workingFrom)} — {to12h(s.doctor.workingTo)}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-start gap-1.5">
                    <span className="text-slate-400">📅 أيام العمل:</span>
                    {s.doctor.workingDays.length === 0 ? (
                      <span className="text-slate-400">—</span>
                    ) : (
                      s.doctor.workingDays.map((d) => (
                        <span
                          key={d}
                          className="inline-flex h-6 items-center rounded-md bg-brand-50 px-2 text-[11px] font-bold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                        >
                          {DAY_LABELS[d]}
                        </span>
                      ))
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">🦷 الخدمة الأكثر:</span>
                    <span className="font-semibold">
                      {s.topService ? `${serviceEmoji(s.topService)} ${s.topService}` : "—"}
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
