"use client";

// =============================================================================
// Overview — premium owner dashboard.
//
// Layout:
//   • Hero KPI strip (revenue today, revenue this month, patients, today's appts)
//   • Grouped summary cards: Patients / Appointments / Clinic / Revenue
//   • 7-day appointments trend (mini area chart)
//   • Today's appointments list (live from data.appointments)
//   • Recent activity feed (from data.activityLogs)
//
// All metrics are derived from `useApp().data` — no dummy numbers.
// =============================================================================

import { useMemo } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Link } from "react-router-dom";
import { useApp } from "@/contexts/AppContext";
import { Avatar, Card, CardHeader, EmptyState, Skeleton, StatusBadge } from "@/components/ui";
import { cn } from "@/utils/cn";
import {
  formatDate,
  formatCurrency,
  formatNumber,
  relativeTime,
  to12h,
  todayKey,
  daysAgoKey,
  parseDateKey,
  pad,
} from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";
import type { ActivityLog, Appointment, Visit } from "@/types";

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
function isSameMonth(iso: string): boolean {
  const d = new Date(iso);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
}

function last7DaysLabels(): { key: string; label: string }[] {
  const out: { key: string; label: string }[] = [];
  const dayNames = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    out.push({ key, label: dayNames[d.getDay()] });
  }
  return out;
}

function activityEmoji(entry: ActivityLog): string {
  const t = entry.entityType;
  if (t === "patient") return "👤";
  if (t === "doctor") return "👨‍⚕️";
  if (t === "service") return "🦷";
  if (t === "appointment") return "📅";
  if (t === "visit") return "🩺";
  if (t === "notification") return "🔔";
  if (t === "settings") return "⚙️";
  return "📝";
}

function activityColor(entry: ActivityLog): string {
  const a = entry.action;
  if (a === "created") return "text-emerald-600 dark:text-emerald-400";
  if (a === "updated") return "text-blue-600 dark:text-blue-400";
  if (a === "deleted") return "text-rose-600 dark:text-rose-400";
  if (a === "cancelled") return "text-amber-600 dark:text-amber-400";
  if (a === "completed") return "text-emerald-600 dark:text-emerald-400";
  return "text-slate-500 dark:text-slate-400";
}

// ---------------------------------------------------------------------------
// KPI card
// ---------------------------------------------------------------------------
function KpiCard({
  label,
  value,
  icon,
  trend,
  accent,
}: {
  label: string;
  value: string;
  icon: string;
  trend?: string;
  accent: "brand" | "emerald" | "amber" | "rose" | "violet";
}) {
  const accentMap: Record<string, string> = {
    brand: "from-brand-500/15 to-brand-500/5 text-brand-600 dark:text-brand-300 ring-brand-500/20",
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-300 ring-emerald-500/20",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-600 dark:text-amber-300 ring-amber-500/20",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-600 dark:text-rose-300 ring-rose-500/20",
    violet: "from-violet-500/15 to-violet-500/5 text-violet-600 dark:text-violet-300 ring-violet-500/20",
  };
  return (
    <Card className="overflow-hidden p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{label}</p>
          <p className="mt-1 truncate text-2xl font-extrabold text-slate-800 dark:text-white">
            {value}
          </p>
          {trend && <p className="mt-1 text-[11px] font-medium text-slate-400">{trend}</p>}
        </div>
        <div
          className={cn(
            "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br text-xl ring-1",
            accentMap[accent]
          )}
        >
          {icon}
        </div>
      </div>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Section card (group container)
// ---------------------------------------------------------------------------
function SectionCard({
  title,
  icon,
  children,
  action,
  className,
}: {
  title: string;
  icon: string;
  children: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader title={title} icon={icon} action={action} />
      <div className="p-4">{children}</div>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Group summary mini-card
// ---------------------------------------------------------------------------
function MiniStat({
  label,
  value,
  icon,
  accent,
}: {
  label: string;
  value: string;
  icon: string;
  accent: "brand" | "emerald" | "amber" | "rose" | "violet";
}) {
  const dotMap: Record<string, string> = {
    brand: "bg-brand-500",
    emerald: "bg-emerald-500",
    amber: "bg-amber-500",
    rose: "bg-rose-500",
    violet: "bg-violet-500",
  };
  return (
    <div className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-3 dark:border-slate-800 dark:bg-slate-800/40">
      <div className="flex items-center gap-3">
        <span className={cn("h-2 w-2 rounded-full", dotMap[accent])} />
        <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">{label}</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-base">{icon}</span>
        <span className="text-lg font-extrabold text-slate-800 dark:text-white">{value}</span>
      </div>
    </div>
  );
}

// =========================================================================
// Component
// =========================================================================
export default function Overview() {
  const { data, loading } = useApp();
  const today = todayKey();

  const stats = useMemo(() => {
    const activePatients = data.patients.filter((p) => !p.isDeleted);
    const activeDoctors = data.doctors.filter((d) => !d.isDeleted && d.isActive);
    const activeServices = data.services.filter((s) => !s.isDeleted && s.isActive);
    const activeAppointments = data.appointments.filter((a) => !a.isDeleted);
    const visits = data.visits.filter((v) => !v.isDeleted);

    const todaysAppointments = activeAppointments.filter((a) => a.date === today);
    const upcomingAppointments = activeAppointments.filter(
      (a) => a.date > today && a.status !== "cancelled" && a.status !== "completed"
    );
    const completedAppointments = activeAppointments.filter((a) => a.status === "completed");
    const cancelledAppointments = activeAppointments.filter((a) => a.status === "cancelled");

    const newPatientsThisMonth = activePatients.filter((p) => isSameMonth(p.createdAt));

    const todayRevenue = visits
      .filter((v) => v.visitDate === today)
      .reduce((s, v: Visit) => s + (v.paidAmount || 0), 0);
    const monthRevenue = visits
      .filter((v) => isSameMonth(v.visitDate))
      .reduce((s, v: Visit) => s + (v.paidAmount || 0), 0);

    return {
      totalPatients: activePatients.length,
      newPatients: newPatientsThisMonth.length,
      todaysAppointments: todaysAppointments.length,
      upcomingAppointments: upcomingAppointments.length,
      completedAppointments: completedAppointments.length,
      cancelledAppointments: cancelledAppointments.length,
      totalDoctors: activeDoctors.length,
      totalServices: activeServices.length,
      todayRevenue,
      monthRevenue,
      todaysAppointmentsList: todaysAppointments
        .slice()
        .sort((a, b) => (a.time < b.time ? -1 : 1)),
    };
  }, [data, today]);

  // 7-day appointments trend
  const trendData = useMemo(() => {
    const labels = last7DaysLabels();
    const apps = data.appointments.filter((a) => !a.isDeleted);
    return labels.map(({ key, label }) => ({
      label,
      count: apps.filter((a) => a.date === key).length,
    }));
  }, [data.appointments]);

  const recentActivity = useMemo(() => {
    return [...data.activityLogs].sort((a, b) =>
      a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0
    );
  }, [data.activityLogs]);

  if (loading && stats.totalPatients === 0) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <Skeleton className="h-72 rounded-2xl lg:col-span-2" />
          <Skeleton className="h-72 rounded-2xl" />
        </div>
      </div>
    );
  }

  const maxTrend = Math.max(1, ...trendData.map((d) => d.count));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hero KPI strip */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard
          label="إيرادات اليوم"
          value={formatCurrency(stats.todayRevenue)}
          icon="💰"
          accent="emerald"
          trend={`من ${formatCurrency(stats.monthRevenue)} هذا الشهر`}
        />
        <KpiCard
          label="إيرادات الشهر"
          value={formatCurrency(stats.monthRevenue)}
          icon="📈"
          accent="brand"
          trend={`${formatNumber(stats.completedAppointments)} زيارة مكتملة`}
        />
        <KpiCard
          label="إجمالي المرضى"
          value={formatNumber(stats.totalPatients)}
          icon="👥"
          accent="violet"
          trend={`+${formatNumber(stats.newPatients)} هذا الشهر`}
        />
        <KpiCard
          label="مواعيد اليوم"
          value={formatNumber(stats.todaysAppointments)}
          icon="📅"
          accent="amber"
          trend={`${formatNumber(stats.upcomingAppointments)} موعد قادم`}
        />
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Left: grouped stats + chart */}
        <div className="space-y-6 lg:col-span-2">
          {/* Grouped summary */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <SectionCard title="المرضى" icon="👥">
              <div className="space-y-2.5">
                <MiniStat
                  label="إجمالي المرضى"
                  value={formatNumber(stats.totalPatients)}
                  icon="👥"
                  accent="violet"
                />
                <MiniStat
                  label="مرضى جدد (الشهر)"
                  value={formatNumber(stats.newPatients)}
                  icon="✨"
                  accent="emerald"
                />
              </div>
            </SectionCard>
            <SectionCard title="المواعيد" icon="📅">
              <div className="space-y-2.5">
                <MiniStat
                  label="مواعيد اليوم"
                  value={formatNumber(stats.todaysAppointments)}
                  icon="📅"
                  accent="amber"
                />
                <MiniStat
                  label="مواعيد قادمة"
                  value={formatNumber(stats.upcomingAppointments)}
                  icon="⏭️"
                  accent="brand"
                />
              </div>
            </SectionCard>
            <SectionCard title="حالة المواعيد" icon="✅">
              <div className="space-y-2.5">
                <MiniStat
                  label="مكتملة"
                  value={formatNumber(stats.completedAppointments)}
                  icon="✅"
                  accent="emerald"
                />
                <MiniStat
                  label="ملغاة"
                  value={formatNumber(stats.cancelledAppointments)}
                  icon="❌"
                  accent="rose"
                />
              </div>
            </SectionCard>
            <SectionCard title="العاصمة الطبية" icon="🩺">
              <div className="space-y-2.5">
                <MiniStat
                  label="عدد الأطباء"
                  value={formatNumber(stats.totalDoctors)}
                  icon="👨‍⚕️"
                  accent="brand"
                />
                <MiniStat
                  label="عدد الخدمات"
                  value={formatNumber(stats.totalServices)}
                  icon="🦷"
                  accent="violet"
                />
              </div>
            </SectionCard>
          </div>

          {/* 7-day trend */}
          <Card className="overflow-hidden">
            <CardHeader
              title="اتجاه المواعيد (آخر ٧ أيام)"
              icon="📈"
              subtitle="عدد المواعيد المحجوزة لكل يوم"
            />
            <div className="p-4">
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData} margin={{ top: 10, right: 5, left: -10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 12, fill: "#64748b", fontFamily: "Cairo" }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 12, fill: "#64748b" }}
                      tickLine={false}
                      axisLine={false}
                      width={28}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: 12,
                        border: "1px solid #e2e8f0",
                        fontFamily: "Cairo",
                        fontSize: 12,
                        boxShadow: "0 8px 24px -8px rgba(15,23,42,0.15)",
                      }}
                      labelStyle={{ fontWeight: 700 }}
                      formatter={(value: any) => [`${value} موعد`, "المواعيد"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="count"
                      stroke="#3b82f6"
                      strokeWidth={2.5}
                      fill="url(#trendFill)"
                      dot={{ r: 3, fill: "#3b82f6", strokeWidth: 0 }}
                      activeDot={{ r: 5, fill: "#2563eb" }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 flex items-center justify-between px-2 text-[11px] text-slate-400">
                <span>الذروة: {maxTrend} موعد/يوم</span>
                <span>المتوسط: {Math.round(trendData.reduce((s, d) => s + d.count, 0) / 7)} موعد/يوم</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Right: today's appointments + activity */}
        <div className="space-y-6">
          <Card className="overflow-hidden">
            <CardHeader
              title="مواعيد اليوم"
              icon="📅"
              action={
                <Link
                  to="/appointments"
                  className="text-xs font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
                >
                  عرض الكل ←
                </Link>
              }
            />
            <div className="max-h-80 overflow-y-auto p-3">
              {stats.todaysAppointmentsList.length === 0 ? (
                <EmptyState emoji="🌙" title="لا مواعيد اليوم" description="يوم هادئ — استمح!" />
              ) : (
                <ul className="space-y-2">
                  {stats.todaysAppointmentsList.slice(0, 8).map((a: Appointment) => (
                    <li
                      key={a.id}
                      className="flex items-center gap-3 rounded-xl border border-slate-100 bg-white px-3 py-2.5 dark:border-slate-800 dark:bg-slate-800/40"
                    >
                      <div className="flex h-10 w-12 shrink-0 flex-col items-center justify-center rounded-lg bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
                        <span className="text-[10px] font-bold leading-none">الساعة</span>
                        <span className="text-[11px] font-extrabold leading-tight">{to12h(a.time)}</span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-slate-800 dark:text-white">
                          {a.patientName || "—"}
                        </p>
                        <p className="truncate text-xs text-slate-400">
                          {a.doctorName || "—"} • {serviceEmoji(a.serviceName || "")} {a.serviceName || "—"}
                        </p>
                      </div>
                      <StatusBadge status={a.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader
              title="آخر النشاطات"
              icon="🕐"
              action={
                <Link
                  to="/activity"
                  className="text-xs font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
                >
                  الكل ←
                </Link>
              }
            />
            <div className="max-h-96 overflow-y-auto p-3">
              {recentActivity.length === 0 ? (
                <EmptyState emoji="📭" title="لا نشاطات بعد" description="ستظهر أحداث العيادة هنا" />
              ) : (
                <ol className="relative space-y-1 before:absolute before:right-[18px] before:top-2 before:bottom-2 before:w-px before:bg-slate-200 dark:before:bg-slate-700">
                  {recentActivity.slice(0, 12).map((entry) => (
                    <li key={entry.id} className="relative flex gap-3 rounded-lg px-2 py-2 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <div className="z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-base shadow ring-2 ring-white dark:bg-slate-900 dark:ring-slate-900">
                        {activityEmoji(entry)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                          <span className={activityColor(entry)}>{entry.description}</span>
                        </p>
                        <p className="mt-0.5 text-[10px] text-slate-400">
                          {relativeTime(entry.createdAt)} • {formatDate(parseDateKey(entry.createdAt).toISOString())}
                        </p>
                      </div>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
