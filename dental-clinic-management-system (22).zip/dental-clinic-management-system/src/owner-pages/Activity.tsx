"use client";

// =============================================================================
// Activity — chronological feed of all clinic events.
//
// • Reads from `useApp().data.activityLogs` (already polled every 15s).
// • Color-coded by action type (created/updated/deleted/cancelled/completed).
// • Filter by entity type.
// =============================================================================

import { useMemo, useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { Card, CardHeader, EmptyState, Segmented, Skeleton, Button, SearchInput } from "@/components/ui";
import { cn } from "@/utils/cn";
import { relativeTime, formatDateTime } from "@/utils/format";
import type { ActivityLog } from "@/types";

type FilterKey = "all" | "patients" | "appointments" | "doctors" | "services" | "visits";

const FILTER_OPTIONS: { value: FilterKey; label: string }[] = [
  { value: "all", label: "الكل" },
  { value: "patients", label: "المرضى" },
  { value: "appointments", label: "المواعيد" },
  { value: "doctors", label: "الأطباء" },
  { value: "services", label: "الخدمات" },
  { value: "visits", label: "الزيارات" },
];

const ENTITY_EMOJI: Record<string, string> = {
  patient: "👤",
  doctor: "👨‍⚕️",
  service: "🦷",
  appointment: "📅",
  visit: "🩺",
  notification: "🔔",
  settings: "⚙️",
};

const ACTION_META: Record<string, { label: string; color: string; bg: string; ring: string }> = {
  created: {
    label: "إضافة",
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500",
    ring: "ring-emerald-500/30",
  },
  updated: {
    label: "تعديل",
    color: "text-blue-600 dark:text-blue-400",
    bg: "bg-blue-500",
    ring: "ring-blue-500/30",
  },
  deleted: {
    label: "حذف",
    color: "text-rose-600 dark:text-rose-400",
    bg: "bg-rose-500",
    ring: "ring-rose-500/30",
  },
  cancelled: {
    label: "إلغاء",
    color: "text-amber-600 dark:text-amber-400",
    bg: "bg-amber-500",
    ring: "ring-amber-500/30",
  },
  completed: {
    label: "إكمال",
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500",
    ring: "ring-emerald-500/30",
  },
};

function matchesFilter(entry: ActivityLog, filter: FilterKey): boolean {
  if (filter === "all") return true;
  return entry.entityType === filter.slice(0, -1); // patients → patient, etc.
}

export default function Activity() {
  const { data, loading, refreshActivity } = useApp();
  const [filter, setFilter] = useState<FilterKey>("all");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    let list = [...data.activityLogs].sort((a, b) =>
      a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0
    );
    list = list.filter((e) => matchesFilter(e, filter));
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (e) =>
          e.description.toLowerCase().includes(q) ||
          (e.entityName || "").toLowerCase().includes(q) ||
          e.action.toLowerCase().includes(q)
      );
    }
    return list;
  }, [data.activityLogs, filter, query]);

  // Counts per filter
  const counts = useMemo(() => {
    const c: Record<FilterKey, number> = {
      all: data.activityLogs.length,
      patients: 0,
      appointments: 0,
      doctors: 0,
      services: 0,
      visits: 0,
    };
    data.activityLogs.forEach((e) => {
      if (e.entityType === "patient") c.patients += 1;
      else if (e.entityType === "appointment") c.appointments += 1;
      else if (e.entityType === "doctor") c.doctors += 1;
      else if (e.entityType === "service") c.services += 1;
      else if (e.entityType === "visit") c.visits += 1;
    });
    return c;
  }, [data.activityLogs]);

  if (loading && data.activityLogs.length === 0) {
    return (
      <Card className="overflow-hidden">
        <CardHeader title="سجل النشاط" icon="🕐" />
        <div className="space-y-3 p-5">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Filter toolbar */}
      <Card className="overflow-hidden">
        <CardHeader
          title="سجل النشاط"
          icon="🕐"
          subtitle={`${counts.all} حدث • ${filtered.length} معروض`}
          action={
            <Button variant="outline" size="sm" onClick={() => refreshActivity()}>
              🔄 تحديث
            </Button>
          }
        />
        <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
          <Segmented
            options={FILTER_OPTIONS.map((o) => ({
              value: o.value,
              label: `${o.label} (${counts[o.value] || 0})`,
            }))}
            value={filter}
            onChange={setFilter}
            size="sm"
          />
          <div className="w-full sm:w-72">
            <SearchInput value={query} onChange={setQuery} placeholder="بحث في النشاط..." />
          </div>
        </div>
      </Card>

      {/* Timeline */}
      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState emoji="📭" title="لا توجد نشاطات" description="لا توجد أحداث مطابقة للفلتر الحالي" />
        ) : (
          <ol className="relative px-5 py-5 before:absolute before:right-[28px] before:top-6 before:bottom-6 before:w-px before:bg-slate-200 dark:before:bg-slate-700">
            {filtered.map((entry) => {
              const meta = ACTION_META[entry.action] || {
                label: entry.action,
                color: "text-slate-500 dark:text-slate-400",
                bg: "bg-slate-500",
                ring: "ring-slate-500/30",
              };
              const emoji = ENTITY_EMOJI[entry.entityType] || "📝";
              return (
                <li
                  key={entry.id}
                  className="relative mb-3 flex gap-4 rounded-xl border border-slate-100 bg-white px-4 py-3 shadow-sm transition-colors hover:border-slate-200 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700"
                >
                  <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-lg shadow ring-2 ring-white dark:bg-slate-900 dark:ring-slate-900">
                    <span>{emoji}</span>
                    <span
                      className={cn(
                        "absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full ring-2 ring-white dark:ring-slate-900",
                        meta.bg
                      )}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                        {entry.description}
                      </p>
                      <span
                        className={cn(
                          "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ring-1",
                          meta.color,
                          meta.ring
                        )}
                      >
                        {meta.label}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                      <span className="inline-flex items-center gap-1">
                        🕒 {relativeTime(entry.createdAt)}
                      </span>
                      <span className="inline-flex items-center gap-1">•</span>
                      <span>{formatDateTime(entry.createdAt)}</span>
                      {entry.entityName && (
                        <>
                          <span>•</span>
                          <span className="font-semibold text-slate-500 dark:text-slate-400">
                            {entry.entityName}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>
        )}
      </Card>
    </div>
  );
}
