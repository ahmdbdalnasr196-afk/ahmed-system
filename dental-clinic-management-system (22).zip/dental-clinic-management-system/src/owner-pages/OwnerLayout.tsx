"use client";

// =============================================================================
// OwnerLayout — premium owner area shell.
//
// This is the layout component (sidebar + header + Outlet) used as the
// element of a parent <Route>. The HashRouter + Routes wiring is provided
// by `@/components/OwnerApp` (along with AppProvider).
//
// Distinct from the admin Layout: uses a dark gradient sidebar (slate-950 →
// brand-950) with subtle glassy panels, a slimmer premium header, and a
// logout button. The owner area is a read/monitoring surface for the clinic
// owner — every page is a business-intelligence view.
// =============================================================================

import { useEffect, useMemo, useRef, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Bell, Check, LogOut, Menu, Monitor, Moon, Sun, Trash2, X } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import { useAuth } from "@/contexts/AuthContext";
import type { AppNotification, ThemeMode } from "@/types";
import { cn } from "@/utils/cn";
import { notificationEmoji } from "@/utils/domain";
import { relativeTime } from "@/utils/format";
import { Avatar } from "@/components/ui";

// ---- Navigation items (emoji + Arabic label) -------------------------------
const NAV: { to: string; label: string; icon: string; end?: boolean }[] = [
  { to: "/", label: "نظرة عامة", icon: "📊", end: true },
  { to: "/appointments", label: "المواعيد", icon: "📅" },
  { to: "/patients", label: "المرضى", icon: "👥" },
  { to: "/doctors", label: "الأطباء", icon: "👨‍⚕️" },
  { to: "/services", label: "الخدمات", icon: "🦷" },
  { to: "/analytics", label: "التحليلات", icon: "📈" },
  { to: "/activity", label: "النشاط", icon: "🕐" },
  { to: "/settings", label: "الإعدادات", icon: "⚙️" },
];

// ---- Page title map (used by header) ---------------------------------------
const TITLE_MAP: Record<string, { title: string; subtitle: string }> = {
  "/": { title: "نظرة عامة", subtitle: "ملخص أداء العيادة لحظة بلحظة" },
  "/appointments": { title: "المواعيد", subtitle: "متابعة المواعيد اليومية والقادمة" },
  "/patients": { title: "المرضى", subtitle: "قاعدة بيانات المرضى ونموها" },
  "/doctors": { title: "الأطباء", subtitle: "أداء الأطباء ومؤشرات الإنتاجية" },
  "/services": { title: "الخدمات", subtitle: "الخدمات المقدمة ومدى الإقبال عليها" },
  "/analytics": { title: "التحليلات", subtitle: "تحليلات الأعمال والاتجاهات" },
  "/activity": { title: "النشاط", subtitle: "سجل أحداث العيادة الكامل" },
  "/settings": { title: "الإعدادات", subtitle: "إعدادات العيادة والتنبيهات" },
};

// =============================================================================
// Sidebar — premium dark gradient
// =============================================================================
function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { settings } = useApp();
  return (
    <div className="flex h-full flex-col text-slate-300">
      {/* Brand block */}
      <div className="flex items-center gap-3 border-b border-white/5 px-5 py-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 text-2xl shadow-lg shadow-brand-900/50 ring-1 ring-white/10">
          🦷
        </div>
        <div className="min-w-0">
          <p className="truncate text-base font-extrabold text-white">
            {settings.clinicName || "عيادة الأسنان"}
          </p>
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-brand-300">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-brand-400 animate-soft-pulse" />
            منطقة المالك
          </p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          القائمة الرئيسية
        </p>
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all",
                isActive
                  ? "bg-gradient-to-l from-brand-500/30 to-brand-500/10 text-white shadow-inner ring-1 ring-brand-400/30"
                  : "text-slate-400 hover:bg-white/5 hover:text-white"
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span className="absolute right-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-l-full bg-brand-400" />
                )}
                <span className="text-lg">{item.icon}</span>
                <span>{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Owner badge */}
      <div className="border-t border-white/5 px-5 py-4">
        <div className="flex items-center gap-3 rounded-xl bg-white/5 p-3 ring-1 ring-white/5">
          <Avatar
            name={settings.doctorName || "مالك العيادة"}
            size="md"
            src={settings.doctorImage}
          />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-white">
              {settings.doctorName || "مالك العيادة"}
            </p>
            <p className="truncate text-[11px] text-slate-400">
              {settings.doctorSpecialty || "صاحب العيادة"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// =============================================================================
// Theme menu
// =============================================================================
const THEME_OPTIONS: { value: ThemeMode; label: string; icon: typeof Sun }[] = [
  { value: "light", label: "فاتح", icon: Sun },
  { value: "dark", label: "داكن", icon: Moon },
  { value: "system", label: "النظام", icon: Monitor },
];

function ThemeMenu() {
  const { theme, setTheme } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  const Active = theme === "light" ? Sun : theme === "dark" ? Moon : Monitor;
  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:text-brand-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
        aria-label="تبديل المظهر"
      >
        <Active className="h-5 w-5" />
      </button>
      {open && (
        <div className="absolute top-full left-0 z-50 mt-2 w-40 rounded-xl border border-slate-200 bg-white p-1 shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
          {THEME_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => {
                setTheme(opt.value);
                setOpen(false);
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-colors",
                theme === opt.value
                  ? "bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              )}
            >
              <opt.icon className="h-4 w-4" />
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// =============================================================================
// Notification bell
// =============================================================================
function NotificationBell() {
  const { data, markNotificationRead, markAllRead, clearNotifications } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const all = useMemo(
    () => [...data.notifications].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)),
    [data.notifications]
  );
  const unread = all.filter((n) => !n.isRead).length;

  const routeFor = (n: AppNotification): string => {
    if (n.relatedType === "patient") return "/patients";
    if (n.relatedType === "doctor") return "/doctors";
    if (n.relatedType === "appointment") return "/appointments";
    if (n.relatedType === "visit") return "/patients";
    if (n.relatedType === "service") return "/services";
    return "/";
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:text-brand-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
        aria-label="الإشعارات"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow animate-scale-in">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute top-full left-0 z-50 mt-2 w-80 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900 sm:w-96">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3 dark:border-slate-800">
            <h3 className="font-bold text-slate-800 dark:text-white">🔔 الإشعارات</h3>
            <div className="flex items-center gap-1">
              <button
                onClick={markAllRead}
                title="تعليم الكل كمقروء"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-emerald-600 dark:hover:bg-slate-800"
              >
                <Check className="h-4 w-4" />
              </button>
              <button
                onClick={clearNotifications}
                title="مسح الإشعارات"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-rose-600 dark:hover:bg-slate-800"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {all.length === 0 ? (
              <p className="px-4 py-10 text-center text-sm text-slate-400">لا توجد إشعارات</p>
            ) : (
              all.map((n) => (
                <button
                  key={n.id}
                  onClick={() => {
                    if (!n.isRead) markNotificationRead(n.id);
                    navigate(routeFor(n));
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full gap-3 border-b border-slate-50 px-4 py-3 text-right transition-colors hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/50",
                    !n.isRead && "bg-brand-50/40 dark:bg-brand-500/5"
                  )}
                >
                  <span className="mt-0.5 text-base">{notificationEmoji(n)}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{n.title}</p>
                    <p className="truncate text-xs text-slate-400">{n.message}</p>
                    <p className="mt-0.5 text-[11px] text-slate-300">{relativeTime(n.createdAt)}</p>
                  </div>
                  {!n.isRead && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-brand-500" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// =============================================================================
// Toast host (mounts toasts inside owner area)
// =============================================================================
function ToastHost() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="fixed bottom-4 left-4 z-[70] flex w-full max-w-sm flex-col gap-2">
      {toasts.map((t) => (
        <ToastItem key={t.id} id={t.id} type={t.type} message={t.message} onDismiss={dismissToast} />
      ))}
    </div>
  );
}

function ToastItem({
  id,
  type,
  message,
  onDismiss,
}: {
  id: string;
  type: "success" | "warning" | "error" | "info";
  message: string;
  onDismiss: (id: string) => void;
}) {
  const timer = useRef<number | null>(null);
  const remaining = useRef(4000);
  const start = useRef(Date.now());

  useEffect(() => {
    start.current = Date.now();
    timer.current = window.setTimeout(() => onDismiss(id), remaining.current);
    return () => {
      if (timer.current) {
        remaining.current -= Date.now() - start.current;
        clearTimeout(timer.current);
      }
    };
  }, [id, onDismiss]);

  const styles = {
    success: "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300",
    warning: "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300",
    error: "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300",
    info: "border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-500/30 dark:bg-blue-500/10 dark:text-blue-300",
  };
  const icon = { success: "🟢", warning: "🟡", error: "🔴", info: "🔵" }[type];

  return (
    <div
      onMouseEnter={() => timer.current && clearTimeout(timer.current)}
      onMouseLeave={() => {
        start.current = Date.now();
        timer.current = window.setTimeout(() => onDismiss(id), remaining.current);
      }}
      className={cn(
        "flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold shadow-lg backdrop-blur animate-slide-in-left",
        styles[type]
      )}
    >
      <span>{icon}</span>
      <span className="flex-1">{message}</span>
      <button onClick={() => onDismiss(id)} className="opacity-60 hover:opacity-100">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

// =============================================================================
// Notification popup (auto-shown when a fresh notification arrives)
// =============================================================================
function NotificationPopup() {
  const { popupNotification, dismissPopup } = useApp();
  const navigate = useNavigate();
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (!popupNotification) return;
    timer.current = window.setTimeout(dismissPopup, 7000);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [popupNotification, dismissPopup]);

  if (!popupNotification) return null;
  const n = popupNotification;

  const routeFor = (n: AppNotification): string => {
    if (n.relatedType === "patient") return "/patients";
    if (n.relatedType === "doctor") return "/doctors";
    if (n.relatedType === "appointment") return "/appointments";
    if (n.relatedType === "visit") return "/patients";
    return "/";
  };

  const bar = {
    success: "bg-emerald-500",
    warning: "bg-amber-500",
    error: "bg-rose-500",
    info: "bg-blue-500",
  }[n.type];

  return (
    <div className="fixed left-1/2 top-5 z-[75] w-[min(92vw,26rem)] -translate-x-1/2">
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-start gap-3 p-4">
          <span className="text-xl">{notificationEmoji(n)}</span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-slate-800 dark:text-white">{n.title}</p>
            <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">{n.message}</p>
            <button
              onClick={() => {
                navigate(routeFor(n));
                dismissPopup();
              }}
              className="mt-2 text-xs font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
            >
              عرض التفاصيل ←
            </button>
          </div>
          <button onClick={dismissPopup} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="h-1 w-full bg-slate-100 dark:bg-slate-800">
          <div className={cn("h-full w-full origin-right", bar)} style={{ animation: "shrink 7s linear forwards" }} />
        </div>
      </div>
    </div>
  );
}

// =============================================================================
// Header — uses current route to derive page title
// =============================================================================
function Header({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  const location = useLocation();
  const { logout } = useAuth();
  const meta = TITLE_MAP[location.pathname] ?? { title: "منطقة المالك", subtitle: "" };

  return (
    <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/80 sm:px-6">
      <button
        onClick={onOpenSidebar}
        className="rounded-xl border border-slate-200 p-2 text-slate-500 lg:hidden dark:border-slate-700"
        aria-label="فتح القائمة"
      >
        <Menu className="h-5 w-5" />
      </button>

      <div className="min-w-0">
        <h1 className="truncate text-lg font-extrabold text-slate-800 dark:text-white sm:text-xl">
          {meta.title}
        </h1>
        {meta.subtitle && (
          <p className="hidden truncate text-xs text-slate-400 sm:block">{meta.subtitle}</p>
        )}
      </div>

      <div className="mr-auto flex items-center gap-2">
        <ThemeMenu />
        <NotificationBell />
        <div className="mx-1 hidden h-8 w-px bg-slate-200 dark:bg-slate-700 sm:block" />
        <button
          onClick={logout}
          title="تسجيل الخروج"
          className="flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-600 transition-colors hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-500/10 dark:hover:text-rose-300"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">خروج</span>
        </button>
      </div>
    </header>
  );
}

// =============================================================================
// OwnerLayout (default export) — sidebar + header + Outlet
// =============================================================================
export default function OwnerLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="flex min-h-screen bg-slate-100 dark:bg-slate-950">
      {/* Desktop sidebar — premium dark gradient */}
      <aside className="sticky top-0 hidden h-screen w-72 shrink-0 border-l border-white/5 bg-gradient-to-b from-slate-950 via-slate-900 to-brand-950 lg:block">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute right-0 top-0 h-full w-72 border-l border-white/5 bg-gradient-to-b from-slate-950 via-slate-900 to-brand-950 shadow-2xl animate-slide-in-left">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute left-3 top-4 rounded-lg p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
              aria-label="إغلاق القائمة"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent onNavigate={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <Header onOpenSidebar={() => setMobileOpen(true)} />
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-7xl">
            <Outlet />
          </div>
        </main>
        <footer className="mt-auto border-t border-slate-200 bg-white/60 px-6 py-4 text-center text-xs text-slate-400 dark:border-slate-800 dark:bg-slate-900/60">
          © {new Date().getFullYear()} منطقة المالك — نظام إدارة عيادة الأسنان
        </footer>
      </div>

      <ToastHost />
      <NotificationPopup />
    </div>
  );
}
