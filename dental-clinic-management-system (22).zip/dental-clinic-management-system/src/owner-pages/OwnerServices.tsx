"use client";

// =============================================================================
// OwnerServices — services overview (owner view).
//
// Service cards with: name, price, duration, visit count, revenue.
// Most popular services highlighted.
// =============================================================================

import { useMemo } from "react";
import { useApp } from "@/contexts/AppContext";
import { Card, CardHeader, EmptyState, Skeleton } from "@/components/ui";
import { cn } from "@/utils/cn";
import { formatCurrency, formatNumber } from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";
import type { Service } from "@/types";

interface ServiceStat {
  service: Service;
  visitsCount: number;
  revenue: number;
  uniquePatients: number;
  popularity: number; // 0-100
}

export default function OwnerServices() {
  const { data, loading } = useApp();

  const stats = useMemo<{ list: ServiceStat[]; totalRevenue: number; totalVisits: number }>(() => {
    const services = data.services.filter((s) => !s.isDeleted && s.isActive);
    const visits = data.visits.filter((v) => !v.isDeleted);

    const list: ServiceStat[] = services.map((service) => {
      const svcVisits = visits.filter((v) => v.serviceId === service.id);
      const revenue = svcVisits.reduce((s, v) => s + (v.paidAmount || 0), 0);
      return {
        service,
        visitsCount: svcVisits.length,
        revenue,
        uniquePatients: new Set(svcVisits.map((v) => v.patientId)).size,
        popularity: 0,
      };
    });

    const totalRevenue = list.reduce((s, x) => s + x.revenue, 0);
    const totalVisits = list.reduce((s, x) => s + x.visitsCount, 0);
    const maxVisits = Math.max(1, ...list.map((x) => x.visitsCount));
    list.forEach((x) => {
      x.popularity = Math.round((x.visitsCount / maxVisits) * 100);
    });

    // Sort by visits count (most popular first)
    list.sort((a, b) => b.visitsCount - a.visitsCount);

    return { list, totalRevenue, totalVisits };
  }, [data.services, data.visits]);

  if (loading && stats.list.length === 0) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="h-56 rounded-2xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Aggregate */}
      <Card className="overflow-hidden">
        <CardHeader
          title="الخدمات المقدمة"
          icon="🦷"
          subtitle={`${formatNumber(stats.list.length)} خدمة نشطة`}
        />
        <div className="grid grid-cols-2 gap-4 p-5 lg:grid-cols-3">
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الإيرادات</p>
            <p className="mt-1 text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(stats.totalRevenue)}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الزيارات</p>
            <p className="mt-1 text-2xl font-extrabold text-brand-600 dark:text-brand-300">
              {formatNumber(stats.totalVisits)}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">متوسط قيمة الزيارة</p>
            <p className="mt-1 text-2xl font-extrabold text-violet-600 dark:text-violet-300">
              {formatCurrency(stats.totalVisits > 0 ? stats.totalRevenue / stats.totalVisits : 0)}
            </p>
          </div>
        </div>
      </Card>

      {/* Service cards */}
      {stats.list.length === 0 ? (
        <Card>
          <EmptyState emoji="🦷" title="لا خدمات" description="لم تتم إضافة أي خدمات بعد" />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {stats.list.map((s, idx) => {
            const isTop = idx < 3 && s.visitsCount > 0;
            return (
              <Card
                key={s.service.id}
                className={cn(
                  "relative overflow-hidden p-5 transition-all",
                  isTop && "ring-2 ring-amber-300/60 dark:ring-amber-500/40"
                )}
              >
                {/* Top badge */}
                {isTop && (
                  <div className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-gradient-to-l from-amber-400 to-amber-500 px-2.5 py-1 text-[10px] font-bold text-white shadow-sm">
                    ⭐ الأكثر طلباً #{idx + 1}
                  </div>
                )}

                <div className="flex items-start justify-between gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500/15 to-brand-500/5 text-3xl ring-1 ring-brand-500/20">
                    {serviceEmoji(s.service.name)}
                  </div>
                  <div className="text-left">
                    <p className="text-[11px] font-semibold text-slate-400">السعر</p>
                    <p className="text-base font-extrabold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(s.service.price)}
                    </p>
                  </div>
                </div>

                <h3 className="mt-3 text-base font-bold text-slate-800 dark:text-white">
                  {s.service.name}
                </h3>
                <p className="mt-0.5 text-xs text-slate-400">
                  ⏱️ المدة: {s.service.duration} دقيقة
                </p>

                {s.service.description && (
                  <p className="mt-2 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">
                    {s.service.description}
                  </p>
                )}

                {/* Stats */}
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-slate-50/70 px-2 py-2 dark:bg-slate-800/40">
                    <p className="text-[10px] font-semibold text-slate-400">الزيارات</p>
                    <p className="text-sm font-extrabold text-brand-600 dark:text-brand-300">
                      {formatNumber(s.visitsCount)}
                    </p>
                  </div>
                  <div className="rounded-lg bg-slate-50/70 px-2 py-2 dark:bg-slate-800/40">
                    <p className="text-[10px] font-semibold text-slate-400">المرضى</p>
                    <p className="text-sm font-extrabold text-violet-600 dark:text-violet-300">
                      {formatNumber(s.uniquePatients)}
                    </p>
                  </div>
                  <div className="rounded-lg bg-slate-50/70 px-2 py-2 dark:bg-slate-800/40">
                    <p className="text-[10px] font-semibold text-slate-400">الإيراد</p>
                    <p className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(s.revenue)}
                    </p>
                  </div>
                </div>

                {/* Popularity bar */}
                <div className="mt-3">
                  <div className="mb-1 flex items-center justify-between text-[10px] text-slate-400">
                    <span>الشعبية</span>
                    <span className="font-bold">{s.popularity}%</span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        isTop
                          ? "bg-gradient-to-l from-amber-500 to-amber-400"
                          : "bg-gradient-to-l from-brand-600 to-brand-400"
                      )}
                      style={{ width: `${s.popularity}%` }}
                    />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
