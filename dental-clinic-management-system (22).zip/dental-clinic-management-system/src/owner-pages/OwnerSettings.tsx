"use client";

// =============================================================================
// OwnerSettings — owner-level settings page.
//
// Sections:
//   • Clinic information (name, phone, address, email)
//   • Doctor display info (name, specialty, image)
//   • Working hours & days
//   • Notification sound (toggle + sound selection + preview)
//   • Event-level notification toggles grouped by category
//   • Theme selection
//
// All saves via `useApp().updateSettings()`.
// =============================================================================

import { useEffect, useRef, useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { api, ApiError } from "@/lib/api";
import {
  Button,
  Card,
  CardHeader,
  Field,
  Input,
  Segmented,
  Skeleton,
} from "@/components/ui";
import { ImageUpload } from "@/components/ImageUpload";
import { cn } from "@/utils/cn";
import { to12h } from "@/utils/format";
import { DAY_OPTIONS } from "@/utils/domain";
import type { EventSettings, Settings, ThemeMode, WeekDay } from "@/types";

// ---------------------------------------------------------------------------
// Event settings metadata (grouped by category)
// ---------------------------------------------------------------------------
interface EventToggle {
  key: keyof EventSettings;
  label: string;
}
const EVENT_GROUPS: { title: string; icon: string; items: EventToggle[] }[] = [
  {
    title: "المرضى",
    icon: "👥",
    items: [
      { key: "patientCreated", label: "إضافة مريض جديد" },
      { key: "patientUpdated", label: "تعديل بيانات مريض" },
      { key: "patientDeleted", label: "حذف مريض" },
    ],
  },
  {
    title: "المواعيد",
    icon: "📅",
    items: [
      { key: "appointmentCreated", label: "حجز موعد جديد" },
      { key: "appointmentUpdated", label: "تعديل موعد" },
      { key: "appointmentCancelled", label: "إلغاء موعد" },
      { key: "appointmentCompleted", label: "إكمال موعد" },
    ],
  },
  {
    title: "الأطباء",
    icon: "👨‍⚕️",
    items: [
      { key: "doctorCreated", label: "إضافة طبيب" },
      { key: "doctorUpdated", label: "تعديل بيانات طبيب" },
      { key: "doctorDeleted", label: "حذف طبيب" },
    ],
  },
  {
    title: "الخدمات",
    icon: "🦷",
    items: [
      { key: "serviceCreated", label: "إضافة خدمة" },
      { key: "serviceUpdated", label: "تعديل خدمة" },
      { key: "serviceDeleted", label: "حذف خدمة" },
    ],
  },
  {
    title: "الزيارات",
    icon: "🩺",
    items: [{ key: "visitAdded", label: "تسجيل زيارة جديدة" }],
  },
];

const THEME_OPTIONS: { value: ThemeMode; label: string }[] = [
  { value: "light", label: "☀️ فاتح" },
  { value: "dark", label: "🌙 داكن" },
  { value: "system", label: "💻 النظام" },
];

const SOUND_OPTIONS: { value: string; label: string }[] = [
  { value: "default", label: "افتراضي" },
  { value: "soft", label: "هادئ" },
  { value: "chime", label: "رنين" },
];

// ---------------------------------------------------------------------------
// Local notification sound player (mirrors AppContext's internal player)
// ---------------------------------------------------------------------------
let previewCtx: AudioContext | null = null;
function playPreviewSound(sound: string) {
  try {
    if (!previewCtx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      previewCtx = new AC();
    }
    if (previewCtx.state === "suspended") previewCtx.resume().catch(() => {});
    const now = previewCtx.currentTime;
    const notes =
      sound === "soft" ? [880, 1108] : sound === "chime" ? [659, 880, 1108] : [784, 1047];
    notes.forEach((freq, i) => {
      const osc = previewCtx!.createOscillator();
      const gain = previewCtx!.createGain();
      osc.connect(gain);
      gain.connect(previewCtx!.destination);
      osc.frequency.value = freq;
      osc.type = "sine";
      const start = now + i * 0.12;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.3);
      osc.start(start);
      osc.stop(start + 0.3);
    });
  } catch {
    /* ignore audio failures */
  }
}

// ---------------------------------------------------------------------------
// Toggle switch (premium custom)
// ---------------------------------------------------------------------------
function Toggle({
  checked,
  onChange,
  label,
  description,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  description?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-3 dark:border-slate-800 dark:bg-slate-800/40">
      <div className="min-w-0">
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{label}</p>
        {description && <p className="mt-0.5 text-xs text-slate-400">{description}</p>}
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={cn(
          "relative h-6 w-11 shrink-0 rounded-full transition-colors",
          checked ? "bg-brand-500" : "bg-slate-300 dark:bg-slate-700"
        )}
        aria-pressed={checked}
        aria-label={label}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform",
            checked ? "left-0.5" : "left-[22px]"
          )}
        />
      </button>
    </div>
  );
}

// =========================================================================
// AccountManager — owner-only credential management for both accounts.
// Passwords are NEVER displayed. Only email is shown and editable.
// =========================================================================
function AccountManager() {
  const { toast } = useApp();
  const [accounts, setAccounts] = useState<{ id: string; email: string; role: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null); // which role is saving

  useEffect(() => {
    api.getAccounts()
      .then(setAccounts)
      .catch(() => toast("error", "تعذر جلب بيانات الحسابات"))
      .finally(() => setLoading(false));
  }, [toast]);

  const admin = accounts.find((a) => a.role === "admin");
  const owner = accounts.find((a) => a.role === "owner");

  return (
    <Card className="overflow-hidden">
      <CardHeader title="إدارة حسابات الدخول" icon="🔐" subtitle="تحكم في بيانات دخول حسابات المدير والمالك — كلمات المرور لا تُعرض أبداً" />
      <div className="space-y-5 p-5">
        {loading ? (
          <Skeleton className="h-40 rounded-xl" />
        ) : (
          <>
            <AccountSection
              title="حساب المدير"
              icon="👨‍💼"
              accent="brand"
              account={admin}
              onSave={async (email, newPassword, confirmPassword) => {
                setSaving("admin");
                try {
                  await api.updateAccount("admin", { email, newPassword, confirmPassword });
                  const fresh = await api.getAccounts();
                  setAccounts(fresh);
                  toast("success", "تم تحديث بيانات حساب المدير بنجاح");
                } catch (e: any) {
                  toast("error", e instanceof ApiError ? e.message : "تعذر تحديث الحساب");
                } finally {
                  setSaving(null);
                }
              }}
              saving={saving === "admin"}
            />
            <AccountSection
              title="حساب المالك"
              icon="👑"
              accent="amber"
              account={owner}
              onSave={async (email, newPassword, confirmPassword) => {
                setSaving("owner");
                try {
                  await api.updateAccount("owner", { email, newPassword, confirmPassword });
                  const fresh = await api.getAccounts();
                  setAccounts(fresh);
                  toast("success", "تم تحديث بيانات حساب المالك بنجاح");
                } catch (e: any) {
                  toast("error", e instanceof ApiError ? e.message : "تعذر تحديث الحساب");
                } finally {
                  setSaving(null);
                }
              }}
              saving={saving === "owner"}
            />
          </>
        )}
      </div>
    </Card>
  );
}

function AccountSection({
  title,
  icon,
  accent,
  account,
  onSave,
  saving,
}: {
  title: string;
  icon: string;
  accent: "brand" | "amber";
  account?: { id: string; email: string; role: string; name: string };
  onSave: (email: string, newPassword: string, confirmPassword: string) => Promise<void>;
  saving: boolean;
}) {
  const [email, setEmail] = useState(account?.email ?? "");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setEmail(account?.email ?? "");
  }, [account?.email]);

  const handleSave = async () => {
    setError("");
    if (!email.trim()) { setError("البريد الإلكتروني مطلوب"); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { setError("صيغة البريد الإلكتروني غير صحيحة"); return; }
    if (newPassword || confirmPassword) {
      if (newPassword.length < 6) { setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل"); return; }
      if (newPassword !== confirmPassword) { setError("كلمتا المرور غير متطابقتين"); return; }
    }
    await onSave(email.trim(), newPassword, confirmPassword);
    setNewPassword("");
    setConfirmPassword("");
  };

  const accentClasses = accent === "brand"
    ? "border-brand-200 bg-brand-50/40 dark:border-brand-500/20 dark:bg-brand-500/5"
    : "border-amber-200 bg-amber-50/40 dark:border-amber-500/20 dark:bg-amber-500/5";

  return (
    <div className={cn("rounded-xl border p-4", accentClasses)}>
      <div className="mb-4 flex items-center gap-2">
        <span className="text-xl">{icon}</span>
        <div>
          <p className="text-sm font-bold text-slate-800 dark:text-white">{title}</p>
          <p className="text-xs text-slate-400">{account?.name ?? "—"}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Field label="البريد الإلكتروني">
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@clinic.com" dir="ltr" />
        </Field>
        <Field label="كلمة مرور جديدة" hint="اتركها فارغة لعدم التغيير">
          <div className="relative">
            <Input
              type={showPwd ? "text" : "password"}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••"
              dir="ltr"
              className="pl-9"
            />
            <button
              type="button"
              onClick={() => setShowPwd((s) => !s)}
              className="absolute left-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              {showPwd ? "🙈" : "👁️"}
            </button>
          </div>
        </Field>
        <Field label="تأكيد كلمة المرور">
          <Input
            type={showPwd ? "text" : "password"}
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="••••••••"
            dir="ltr"
          />
        </Field>
      </div>
      {error && <p className="mt-2 text-xs font-medium text-rose-500">{error}</p>}
      <div className="mt-3 flex justify-end">
        <Button size="sm" onClick={handleSave} loading={saving} disabled={!email.trim()}>
          💾 حفظ التغييرات
        </Button>
      </div>
    </div>
  );
}

// =========================================================================
// Component
// =========================================================================
export default function OwnerSettings() {
  const { settings, updateSettings, theme, setTheme, loading } = useApp();
  const [form, setForm] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const debounceRef = useRef<number | null>(null);

  // Sync form with settings
  useEffect(() => {
    setForm(settings);
  }, [settings]);

  if (loading || !form) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-72 rounded-2xl" />
        <Skeleton className="h-72 rounded-2xl" />
        <Skeleton className="h-72 rounded-2xl" />
      </div>
    );
  }

  // Patch form + auto-save (debounced)
  const patch = (p: Partial<Settings>) => {
    const next = { ...form, ...p };
    setForm(next);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(async () => {
      setSaving(true);
      try {
        await updateSettings(p);
      } finally {
        setSaving(false);
      }
    }, 600);
  };

  const patchEvent = (key: keyof EventSettings, value: boolean) => {
    const nextEvents = { ...(form.eventSettings || {}), [key]: value } as EventSettings;
    patch({ eventSettings: nextEvents });
  };

  const toggleWorkingDay = (day: WeekDay) => {
    const set = new Set<WeekDay>(form.workingDays || []);
    if (set.has(day)) set.delete(day);
    else set.add(day);
    patch({ workingDays: Array.from(set) });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Save indicator */}
      {saving && (
        <div className="fixed bottom-4 right-1/2 z-50 translate-x-1/2 rounded-full bg-brand-600 px-4 py-2 text-xs font-bold text-white shadow-lg">
          💾 جارٍ الحفظ...
        </div>
      )}

      {/* Account management (owner-only) */}
      <AccountManager />

      {/* Clinic info */}
      <Card className="overflow-hidden">
        <CardHeader title="معلومات العيادة" icon="🏥" subtitle="البيانات الأساسية للعيادة" />
        <div className="space-y-4 p-5">
          <Field label="شعار العيادة">
            <ImageUpload
              value={form.clinicLogo || ""}
              onChange={(url) => patch({ clinicLogo: url })}
              fallbackName={form.clinicName || "عيادة"}
            />
          </Field>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="اسم العيادة">
              <Input
                value={form.clinicName}
                onChange={(e) => patch({ clinicName: e.target.value })}
                placeholder="اسم العيادة"
              />
            </Field>
            <Field label="هاتف العيادة">
              <Input
                value={form.clinicPhone || ""}
                onChange={(e) => patch({ clinicPhone: e.target.value })}
                placeholder="01xxxxxxxxx"
                dir="ltr"
              />
            </Field>
            <Field label="البريد الإلكتروني">
              <Input
                type="email"
                value={form.clinicEmail || ""}
                onChange={(e) => patch({ clinicEmail: e.target.value })}
                placeholder="clinic@example.com"
                dir="ltr"
              />
            </Field>
            <Field label="العنوان">
              <Input
                value={form.clinicAddress || ""}
                onChange={(e) => patch({ clinicAddress: e.target.value })}
                placeholder="العنوان"
              />
            </Field>
          </div>
        </div>
      </Card>

      {/* Doctor display info */}
      <Card className="overflow-hidden">
        <CardHeader title="بيانات الطبيب المعروضة" icon="👨‍⚕️" subtitle="تظهر في الشريط الجانبي والتقارير" />
        <div className="space-y-4 p-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="اسم الطبيب">
              <Input
                value={form.doctorName || ""}
                onChange={(e) => patch({ doctorName: e.target.value })}
                placeholder="د. اسم الطبيب"
              />
            </Field>
            <Field label="التخصص">
              <Input
                value={form.doctorSpecialty || ""}
                onChange={(e) => patch({ doctorSpecialty: e.target.value })}
                placeholder="التخصص"
              />
            </Field>
          </div>
          <Field label="صورة الطبيب">
            <ImageUpload
              value={form.doctorImage || ""}
              onChange={(url) => patch({ doctorImage: url })}
              fallbackName={form.doctorName || "طبيب"}
            />
          </Field>
        </div>
      </Card>

      {/* Working hours & days */}
      <Card className="overflow-hidden">
        <CardHeader title="ساعات وأيام العمل" icon="🕐" subtitle="أوقات عمل العيادة الرسمية" />
        <div className="space-y-5 p-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="من الساعة">
              <Input
                type="time"
                value={form.workingFrom}
                onChange={(e) => patch({ workingFrom: e.target.value })}
              />
              <p className="mt-1 text-xs text-slate-400">يعرض: {to12h(form.workingFrom)}</p>
            </Field>
            <Field label="إلى الساعة">
              <Input
                type="time"
                value={form.workingTo}
                onChange={(e) => patch({ workingTo: e.target.value })}
              />
              <p className="mt-1 text-xs text-slate-400">يعرض: {to12h(form.workingTo)}</p>
            </Field>
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold text-slate-600 dark:text-slate-300">
              أيام العمل
            </p>
            <div className="flex flex-wrap gap-2">
              {DAY_OPTIONS.map((d) => {
                const active = (form.workingDays || []).includes(d.value);
                return (
                  <button
                    key={d.value}
                    type="button"
                    onClick={() => toggleWorkingDay(d.value)}
                    className={cn(
                      "rounded-xl border px-3.5 py-2 text-sm font-semibold transition-all",
                      active
                        ? "border-brand-500 bg-brand-50 text-brand-700 dark:border-brand-500/60 dark:bg-brand-500/15 dark:text-brand-300"
                        : "border-slate-200 bg-white text-slate-500 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400"
                    )}
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </Card>

      {/* Notification sound */}
      <Card className="overflow-hidden">
        <CardHeader title="أصوات التنبيهات" icon="🔔" subtitle="التحكم في صوت الإشعارات" />
        <div className="space-y-4 p-5">
          <Toggle
            checked={!!form.soundEnabled}
            onChange={(v) => patch({ soundEnabled: v })}
            label="تفعيل الصوت"
            description="تشغيل صوت تنبيه عند وصول إشعارات جديدة"
          />
          <div className={cn(!form.soundEnabled && "pointer-events-none opacity-50")}>
            <Field label="نوع الصوت">
              <div className="flex flex-wrap items-center gap-3">
                <Segmented
                  options={SOUND_OPTIONS}
                  value={form.notificationSound || "default"}
                  onChange={(v) => patch({ notificationSound: v })}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => playPreviewSound(form.notificationSound || "default")}
                >
                  ▶️ استماع
                </Button>
              </div>
            </Field>
          </div>
        </div>
      </Card>

      {/* Event-level notification toggles */}
      <Card className="overflow-hidden">
        <CardHeader
          title="تنبيهات الأحداث"
          icon="⚡"
          subtitle="تحكم في تنبيهات كل نوع حدث بشكل منفصل"
        />
        <div className="grid grid-cols-1 gap-5 p-5 md:grid-cols-2">
          {EVENT_GROUPS.map((group) => (
            <div key={group.title}>
              <p className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
                <span className="text-base">{group.icon}</span>
                {group.title}
              </p>
              <div className="space-y-2">
                {group.items.map((item) => (
                  <Toggle
                    key={item.key}
                    checked={!!(form.eventSettings && form.eventSettings[item.key])}
                    onChange={(v) => patchEvent(item.key, v)}
                    label={item.label}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Theme selection */}
      <Card className="overflow-hidden">
        <CardHeader title="المظهر" icon="🎨" subtitle="اختر مظهر الواجهة" />
        <div className="p-5">
          <div className="flex flex-wrap gap-2">
            {THEME_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setTheme(opt.value)}
                className={cn(
                  "rounded-xl border px-5 py-3 text-sm font-bold transition-all",
                  theme === opt.value
                    ? "border-brand-500 bg-brand-50 text-brand-700 dark:border-brand-500/60 dark:bg-brand-500/15 dark:text-brand-300"
                    : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Save button (manual trigger for safety) */}
      <div className="flex justify-end">
        <Button
          onClick={() => updateSettings(form)}
          loading={saving}
        >
          💾 حفظ التعديلات
        </Button>
      </div>
    </div>
  );
}
