"use client";

// =============================================================================
// OwnerPatients — owner view of clinic patients.
//
// Stats: Total patients, New this month, Active (with visits)
// Patient growth mini chart (last 6 months)
// Recent patients table (name, phone, visits count, last visit, created date)
// =============================================================================

import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useApp } from "@/contexts/AppContext";
import {
  Avatar,
  Card,
  CardHeader,
  EmptyState,
  Pagination,
  SearchInput,
  Skeleton,
} from "@/components/ui";
import { cn } from "@/utils/cn";
import { formatDate, formatNumber, pad, relativeTime } from "@/utils/format";
import { GENDER_LABELS } from "@/utils/domain";
import type { Patient, Visit } from "@/types";

function isSameMonth(iso: string, ref: Date = new Date()): boolean {
  const d = new Date(iso);
  return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth();
}

function last6Months(): { key: string; label: string; year: number; month: number }[] {
  const out: { key: string; label: string; year: number; month: number }[] = [];
  const monthNames = ["ينا", "فبر", "مار", "أبر", "ماي", "يون", "يول", "أغس", "سبت", "أكت", "نوف", "ديس"];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    out.push({
      key: `${d.getFullYear()}-${pad(d.getMonth() + 1)}`,
      label: monthNames[d.getMonth()],
      year: d.getFullYear(),
      month: d.getMonth(),
    });
  }
  return out;
}

export default function OwnerPatients() {
  const { data, loading } = useApp();
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { totalPatients, newThisMonth, activePatients, growthData, recent, pageCount, paged } =
    useMemo(() => {
      const patients = data.patients.filter((p) => !p.isDeleted);
      const visits = data.visits.filter((v) => !v.isDeleted);

      const visitCountByPatient: Record<string, number> = {};
      const lastVisitByPatient: Record<string, string> = {};
      visits.forEach((v: Visit) => {
        visitCountByPatient[v.patientId] = (visitCountByPatient[v.patientId] || 0) + 1;
        const cur = lastVisitByPatient[v.patientId];
        if (!cur || v.visitDate > cur) lastVisitByPatient[v.patientId] = v.visitDate;
      });

      const newCount = patients.filter((p: Patient) => isSameMonth(p.createdAt)).length;
      const activeCount = patients.filter((p: Patient) => (visitCountByPatient[p.id] || 0) > 0).length;

      const months = last6Months();
      const growth = months.map((m) => ({
        label: m.label,
        count: patients.filter((p: Patient) => {
          const d = new Date(p.createdAt);
          return d.getFullYear() === m.year && d.getMonth() === m.month;
        }).length,
      }));

      // Sorted recent patients (newest createdAt first)
      let list = patients
        .slice()
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));

      const q = query.trim().toLowerCase();
      if (q) {
        list = list.filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            p.phone.includes(q) ||
            (p.address || "").toLowerCase().includes(q)
        );
      }

      const total = list.length;
      const pages = Math.max(1, Math.ceil(total / pageSize));
      const safePage = Math.min(page, pages);
      const slice = list.slice((safePage - 1) * pageSize, safePage * pageSize);

      return {
        totalPatients: patients.length,
        newThisMonth: newCount,
        activePatients: activeCount,
        growthData: growth,
        recent: list,
        pageCount: pages,
        paged: slice.map((p) => ({
          patient: p,
          visitsCount: visitCountByPatient[p.id] || 0,
          lastVisit: lastVisitByPatient[p.id] || null,
        })),
      };
    }, [data.patients, data.visits, query, page, pageSize]);

  if (loading && totalPatients === 0) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 rounded-2xl" />
        <Skeleton className="h-72 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="flex items-center gap-4 p-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500/15 to-violet-500/5 text-2xl ring-1 ring-violet-500/20">
            👥
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي المرضى</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white">
              {formatNumber(totalPatients)}
            </p>
          </div>
        </Card>
        <Card className="flex items-center gap-4 p-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500/15 to-emerald-500/5 text-2xl ring-1 ring-emerald-500/20">
            ✨
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">جدد هذا الشهر</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white">
              {formatNumber(newThisMonth)}
            </p>
          </div>
        </Card>
        <Card className="flex items-center gap-4 p-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500/15 to-brand-500/5 text-2xl ring-1 ring-brand-500/20">
            🩺
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">مرضى نشطون (لديهم زيارات)</p>
            <p className="text-2xl font-extrabold text-slate-800 dark:text-white">
              {formatNumber(activePatients)}
            </p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Growth chart */}
        <Card className="overflow-hidden lg:col-span-1">
          <CardHeader title="نمو المرضى" icon="📈" subtitle="آخر ٦ أشهر" />
          <div className="p-4">
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={growthData} margin={{ top: 10, right: 5, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" strokeOpacity={0.4} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 12, fill: "#64748b", fontFamily: "Cairo" }}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    allowDecimals={false}
                    tick={{ fontSize: 12, fill: "#64748b" }}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                  />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 12,
                      border: "1px solid #e2e8f0",
                      fontFamily: "Cairo",
                      fontSize: 12,
                    }}
                    cursor={{ fill: "rgba(59,130,246,0.08)" }}
                    formatter={(v: any) => [`${v} مريض`, "جدد"]}
                  />
                  <Bar dataKey="count" fill="#8b5cf6" radius={[6, 6, 0, 0]} maxBarSize={32} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Card>

        {/* Recent patients table */}
        <Card className="overflow-hidden lg:col-span-2">
          <CardHeader
            title="قائمة المرضى"
            icon="📋"
            action={
              <div className="w-full sm:w-64">
                <SearchInput value={query} onChange={(v) => { setQuery(v); setPage(1); }} placeholder="بحث..." />
              </div>
            }
          />
          {paged.length === 0 ? (
            <EmptyState emoji="🔍" title="لا نتائج" description="جرّب تعديل كلمات البحث" />
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-sm">
                  <thead className="border-b border-slate-100 bg-slate-50/70 text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-800/40 dark:text-slate-400">
                    <tr>
                      <th className="px-5 py-3 font-bold">المريض</th>
                      <th className="px-3 py-3 font-bold">الجنس</th>
                      <th className="px-3 py-3 font-bold">الهاتف</th>
                      <th className="px-3 py-3 font-bold">الزيارات</th>
                      <th className="px-3 py-3 font-bold">آخر زيارة</th>
                      <th className="px-5 py-3 font-bold">أُنشئ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {paged.map(({ patient, visitsCount, lastVisit }) => (
                      <tr
                        key={patient.id}
                        className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/40"
                      >
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-3">
                            <Avatar name={patient.name} size="sm" />
                            <div className="min-w-0">
                              <p className="truncate text-sm font-bold text-slate-800 dark:text-white">
                                {patient.name}
                              </p>
                              <p className="truncate text-[11px] text-slate-400">
                                {patient.age} سنة
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-slate-600 dark:text-slate-300">
                          {GENDER_LABELS[patient.gender]}
                        </td>
                        <td className="px-3 py-3 text-slate-600 dark:text-slate-300" dir="ltr">
                          {patient.phone}
                        </td>
                        <td className="px-3 py-3">
                          <span
                            className={cn(
                              "inline-flex h-6 min-w-6 items-center justify-center rounded-md px-1.5 text-xs font-bold",
                              visitsCount > 0
                                ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                                : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                            )}
                          >
                            {visitsCount}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-xs text-slate-500 dark:text-slate-400">
                          {lastVisit ? (
                            <div>
                              <div>{formatDate(lastVisit)}</div>
                              <div className="text-[10px] text-slate-400">{relativeTime(lastVisit)}</div>
                            </div>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="px-5 py-3 text-xs text-slate-500 dark:text-slate-400">
                          {formatDate(patient.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Pagination
                page={page}
                pageCount={pageCount}
                total={recent.length}
                pageSize={pageSize}
                onPage={setPage}
                onPageSize={(s) => {
                  setPageSize(s);
                  setPage(1);
                }}
              />
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
