"use client";

// =============================================================================
// OwnerAppointments — read-only owner view of all clinic appointments.
//
// Tabs: Today / Upcoming / Completed / Cancelled
// Stats cards: total today, upcoming, completed, cancelled
// Appointment list (read-only — owner monitors, doesn't manage)
// =============================================================================

import { useMemo, useState } from "react";
import { useApp } from "@/contexts/AppContext";
import {
  Avatar,
  Card,
  CardHeader,
  EmptyState,
  Segmented,
  Skeleton,
  StatusBadge,
  SearchInput,
} from "@/components/ui";
import { cn } from "@/utils/cn";
import { to12h, formatDate, todayKey, formatNumber } from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";
import type { Appointment } from "@/types";

type TabKey = "today" | "upcoming" | "completed" | "cancelled";

const TAB_OPTIONS: { value: TabKey; label: string }[] = [
  { value: "today", label: "اليوم" },
  { value: "upcoming", label: "القادمة" },
  { value: "completed", label: "المكتملة" },
  { value: "cancelled", label: "الملغاة" },
];

function StatCard({
  label,
  value,
  icon,
  accent,
  active,
  onClick,
}: {
  label: string;
  value: string;
  icon: string;
  accent: "brand" | "emerald" | "amber" | "rose";
  active: boolean;
  onClick: () => void;
}) {
  const accentMap: Record<string, string> = {
    brand: "from-brand-500/15 to-brand-500/5 text-brand-600 dark:text-brand-300 ring-brand-500/20",
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-300 ring-emerald-500/20",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-600 dark:text-amber-300 ring-amber-500/20",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-600 dark:text-rose-300 ring-rose-500/20",
  };
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center justify-between gap-3 rounded-2xl border bg-white p-4 text-right transition-all dark:bg-slate-900",
        active
          ? "border-brand-300 shadow-md shadow-brand-500/10 dark:border-brand-500/40"
          : "border-slate-200/80 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700"
      )}
    >
      <div>
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{label}</p>
        <p className="mt-1 text-2xl font-extrabold text-slate-800 dark:text-white">{value}</p>
      </div>
      <div
        className={cn(
          "flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br text-lg ring-1",
          accentMap[accent]
        )}
      >
        {icon}
      </div>
    </button>
  );
}

export default function OwnerAppointments() {
  const { data, loading } = useApp();
  const [tab, setTab] = useState<TabKey>("today");
  const [query, setQuery] = useState("");

  const today = todayKey();

  const { stats, filtered } = useMemo(() => {
    const apps = data.appointments.filter((a) => !a.isDeleted);
    const todays = apps.filter((a) => a.date === today);
    const upcoming = apps.filter(
      (a) => a.date > today && a.status !== "cancelled" && a.status !== "completed"
    );
    const completed = apps.filter((a) => a.status === "completed");
    const cancelled = apps.filter((a) => a.status === "cancelled");

    let pool: Appointment[] = [];
    if (tab === "today") pool = todays;
    else if (tab === "upcoming") pool = upcoming;
    else if (tab === "completed") pool = completed;
    else pool = cancelled;

    const q = query.trim().toLowerCase();
    if (q) {
      pool = pool.filter((a) => {
        const p = (a.patientName || "").toLowerCase();
        const d = (a.doctorName || "").toLowerCase();
        const s = (a.serviceName || "").toLowerCase();
        return p.includes(q) || d.includes(q) || s.includes(q);
      });
    }

    pool = pool.slice().sort((a, b) => {
      // today/upcoming → ascending by date+time; completed/cancelled → newest first
      if (tab === "today" || tab === "upcoming") {
        const k1 = `${a.date} ${a.time}`;
        const k2 = `${b.date} ${b.time}`;
        return k1 < k2 ? -1 : k1 > k2 ? 1 : 0;
      }
      return a.updatedAt < b.updatedAt ? 1 : a.updatedAt > b.updatedAt ? -1 : 0;
    });

    return {
      stats: {
        today: todays.length,
        upcoming: upcoming.length,
        completed: completed.length,
        cancelled: cancelled.length,
      },
      filtered: pool,
    };
  }, [data.appointments, today, tab, query]);

  if (loading && data.appointments.length === 0) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 rounded-2xl" />
        <Skeleton className="h-96 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="مواعيد اليوم"
          value={formatNumber(stats.today)}
          icon="📅"
          accent="amber"
          active={tab === "today"}
          onClick={() => setTab("today")}
        />
        <StatCard
          label="مواعيد قادمة"
          value={formatNumber(stats.upcoming)}
          icon="⏭️"
          accent="brand"
          active={tab === "upcoming"}
          onClick={() => setTab("upcoming")}
        />
        <StatCard
          label="مواعيد مكتملة"
          value={formatNumber(stats.completed)}
          icon="✅"
          accent="emerald"
          active={tab === "completed"}
          onClick={() => setTab("completed")}
        />
        <StatCard
          label="مواعيد ملغاة"
          value={formatNumber(stats.cancelled)}
          icon="❌"
          accent="rose"
          active={tab === "cancelled"}
          onClick={() => setTab("cancelled")}
        />
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Segmented options={TAB_OPTIONS} value={tab} onChange={setTab} />
        <div className="w-full sm:w-72">
          <SearchInput
            value={query}
            onChange={setQuery}
            placeholder="بحث باسم المريض، الطبيب، الخدمة..."
          />
        </div>
      </div>

      {/* List */}
      <Card className="overflow-hidden">
        <CardHeader
          title={TAB_OPTIONS.find((t) => t.value === tab)?.label || ""}
          subtitle={`${formatNumber(filtered.length)} موعد`}
          icon="📅"
        />
        {filtered.length === 0 ? (
          <EmptyState
            emoji="📭"
            title="لا توجد مواعيد"
            description="لا توجد مواعيد مطابقة في هذا التصنيف"
          />
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {filtered.map((a) => (
              <li
                key={a.id}
                className="flex flex-col gap-3 px-5 py-4 transition-colors hover:bg-slate-50/70 dark:hover:bg-slate-800/40 sm:flex-row sm:items-center"
              >
                <div className="flex items-center gap-3 sm:w-56">
                  <Avatar name={a.patientName || "—"} size="md" />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-slate-800 dark:text-white">
                      {a.patientName || "—"}
                    </p>
                    <p className="truncate text-xs text-slate-400">
                      {a.doctorName || "—"}
                    </p>
                  </div>
                </div>

                <div className="flex flex-1 flex-wrap items-center gap-4 text-sm">
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                    <span>🦷</span>
                    <span className="font-semibold">{a.serviceName || "—"}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <span>🗓️</span>
                    <span>{formatDate(a.date)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <span>⏰</span>
                    <span className="font-semibold">{to12h(a.time)}</span>
                  </div>
                </div>

                <div className="sm:mr-auto">
                  <StatusBadge status={a.status} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
