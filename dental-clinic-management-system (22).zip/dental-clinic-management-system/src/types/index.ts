export type ID = string;
export type Gender = "male" | "female";
export type WeekDay = "saturday" | "sunday" | "monday" | "tuesday" | "wednesday" | "thursday" | "friday";

export interface Patient {
  id: ID; name: string; phone: string; age: number; gender: Gender;
  address?: string; notes?: string; createdAt: string; updatedAt: string;
  isDeleted: boolean; deletedAt: string | null;
}

export interface Doctor {
  id: ID; name: string; image?: string; specialty: string; phone?: string;
  description?: string; workingDays: WeekDay[]; workingFrom: string; workingTo: string;
  createdAt: string; updatedAt: string; isActive: boolean; isDeleted: boolean; deletedAt: string | null;
}

export interface Service {
  id: ID; name: string; avatar?: string; price: number; duration: number;
  description?: string; isActive: boolean; createdAt: string; updatedAt: string;
  isDeleted: boolean; deletedAt: string | null;
}

export type AppointmentStatus = "pending" | "confirmed" | "completed" | "cancelled" | "no_show";

export interface Appointment {
  id: ID; patientId: ID; doctorId: ID; serviceId: ID; date: string; time: string;
  endTime: string; status: AppointmentStatus; notes?: string; createdAt: string; updatedAt: string;
  isDeleted: boolean; deletedAt: string | null;
  patientName?: string | null; doctorName?: string | null; serviceName?: string | null;
}

export interface Visit {
  id: ID; patientId: ID; doctorId: ID; serviceId: ID; appointmentId?: ID; visitDate: string;
  servicePrice: number; paidAmount: number; remainingAmount: number; diagnosis?: string;
  treatmentPlan?: string; notes?: string; createdAt: string; updatedAt: string;
  isDeleted: boolean; deletedAt: string | null;
  patientName?: string | null; doctorName?: string | null; serviceName?: string | null;
}

export type NotificationType = "success" | "warning" | "error" | "info";
export type RelatedType = "appointment" | "patient" | "visit" | "doctor" | "service" | "system";
export type NotificationCategory = "appointment" | "visit" | "patient" | "doctor" | "service" | "settings" | "reminder" | "warning" | "success" | "error";

export interface AppNotification {
  id: ID; title: string; message: string; type: NotificationType;
  relatedType: RelatedType; relatedId?: ID; isRead: boolean; createdAt: string;
  category?: NotificationCategory; key?: string;
}

export interface PatientSearchResult {
  id: ID; name: string; phone: string; age: number; gender: Gender;
  visitsCount: number; lastVisit: string | null;
}

export type ThemeMode = "light" | "dark" | "system";

export interface EventSettings {
  patientCreated?: boolean; patientUpdated?: boolean; patientDeleted?: boolean;
  appointmentCreated?: boolean; appointmentUpdated?: boolean; appointmentCancelled?: boolean; appointmentCompleted?: boolean;
  doctorCreated?: boolean; doctorUpdated?: boolean; doctorDeleted?: boolean;
  serviceCreated?: boolean; serviceUpdated?: boolean; serviceDeleted?: boolean;
  visitAdded?: boolean;
}

export interface Settings {
  id: ID; clinicName: string; clinicLogo?: string; clinicPhone?: string;
  clinicAddress?: string; clinicEmail?: string; doctorName?: string; doctorImage?: string;
  doctorSpecialty?: string; workingDays: WeekDay[]; workingFrom: string; workingTo: string;
  currency: "EGP"; theme: ThemeMode; notificationsEnabled: boolean;
  notificationTypes: { newAppointment: boolean; newPatient: boolean; visitAdded: boolean; appointmentReminder: boolean };
  notificationSound?: string; soundEnabled?: boolean; eventSettings?: EventSettings;
  updatedAt: string;
}

export interface ApiLog {
  id: ID; endpoint: string; method: string; statusCode: number; responseTime: number; createdAt: string;
}

export interface ActivityLog {
  id: ID; entityType: string; action: string; entityName: string; entityId: string; description: string; createdAt: string;
}

export interface Database {
  patients: Patient[]; doctors: Doctor[]; services: Service[]; appointments: Appointment[];
  visits: Visit[]; notifications: AppNotification[]; apiLogs: ApiLog[]; settings: Settings;
  activityLogs: ActivityLog[];
}

export type ReportPeriod = "week" | "month" | "3months" | "6months" | "year";
export interface ChartPoint { label: string; amount: number; count?: number; }

export type UserRole = "admin" | "owner";
export interface AuthUser { email: string; role: UserRole; name: string; }
