"use client";

import {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState,
  type ReactNode,
} from "react";
import { api, ApiError } from "@/lib/api";
import type {
  AppNotification, Appointment, AppointmentStatus, Database, Doctor, Patient,
  ReportPeriod, Service, Settings, ThemeMode, Visit, ActivityLog,
} from "@/types";
import { todayKey } from "@/utils/format";

type ToastType = "success" | "warning" | "error" | "info";
export interface Toast { id: string; type: ToastType; message: string; }

interface SearchResult {
  patients: Patient[]; doctors: Doctor[]; services: Service[]; appointments: Appointment[];
}

interface AppContextValue {
  data: Database;
  loading: boolean;
  refresh: () => Promise<void>;
  refreshPatients: () => Promise<void>;
  refreshDoctors: () => Promise<void>;
  refreshServices: () => Promise<void>;
  refreshAppointments: () => Promise<void>;
  refreshVisits: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  refreshActivity: () => Promise<void>;
  refreshDashboard: () => Promise<void>;
  toasts: Toast[];
  toast: (type: ToastType, message: string) => void;
  dismissToast: (id: string) => void;
  theme: ThemeMode;
  setTheme: (t: ThemeMode) => void;
  effectiveDark: boolean;
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => Promise<void>;
  popupNotification: AppNotification | null;
  dismissPopup: () => void;
  markNotificationRead: (id: string) => void;
  markAllRead: () => void;
  clearNotifications: () => void;
  globalSearch: (q: string) => SearchResult;
  createPatient: (input: any) => Promise<Patient>;
  updatePatient: (id: string, patch: Partial<Patient>) => Promise<Patient>;
  deletePatient: (id: string) => Promise<void>;
  createDoctor: (input: any) => Promise<Doctor>;
  updateDoctor: (id: string, patch: Partial<Doctor>) => Promise<Doctor>;
  deleteDoctor: (id: string) => Promise<void>;
  createService: (input: any) => Promise<Service>;
  updateService: (id: string, patch: Partial<Service>) => Promise<Service>;
  deleteService: (id: string) => Promise<void>;
  bookAppointment: (input: any) => Promise<Appointment>;
  updateAppointment: (id: string, patch: any) => Promise<Appointment>;
  cancelAppointment: (id: string) => Promise<void>;
  completeAppointment: (id: string) => Promise<void>;
  createVisit: (input: any) => Promise<Visit>;
  updateVisit: (id: string, patch: Partial<Visit>) => Promise<Visit>;
  deleteVisit: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const emptyDatabase: Database = {
  patients: [], doctors: [], services: [], appointments: [], visits: [],
  notifications: [], apiLogs: [], activityLogs: [],
  settings: {
    id: "1", clinicName: "", workingDays: [], workingFrom: "09:00", workingTo: "22:00",
    currency: "EGP", theme: "system", notificationsEnabled: true,
    notificationTypes: { newAppointment: true, newPatient: true, visitAdded: true, appointmentReminder: true },
    updatedAt: new Date().toISOString(),
  },
};

function systemDark(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches;
}
function applyTheme(mode: ThemeMode): boolean {
  const dark = mode === "dark" || (mode === "system" && systemDark());
  if (typeof document !== "undefined") {
    document.documentElement.classList.toggle("dark", dark);
  }
  return dark;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Database>(emptyDatabase);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try { const raw = localStorage.getItem("dental_theme"); return raw ? (JSON.parse(raw) as ThemeMode) : "system"; } catch { return "system"; }
  });
  const [effectiveDark, setEffectiveDark] = useState(() => applyTheme(theme));
  const [popupNotification, setPopupNotification] = useState<AppNotification | null>(null);

  // ---- Targeted refresh functions (real-time sync without full reload) ----
  // Each function fetches ONLY its specific resource and merges it into state,
  // preserving all other data and user UI state (forms, modals, filters).
  const refreshPatients = useCallback(async () => {
    try {
      const patients = await api.getPatients();
      setData((d) => ({ ...d, patients }));
    } catch { /* keep last known */ }
  }, []);

  const refreshDoctors = useCallback(async () => {
    try {
      const doctors = await api.getDoctors();
      setData((d) => ({ ...d, doctors }));
    } catch { /* keep last known */ }
  }, []);

  const refreshServices = useCallback(async () => {
    try {
      const services = await api.getServices();
      setData((d) => ({ ...d, services }));
    } catch { /* keep last known */ }
  }, []);

  const refreshAppointments = useCallback(async () => {
    try {
      const appointments = await api.getAppointments();
      setData((d) => ({ ...d, appointments }));
    } catch { /* keep last known */ }
  }, []);

  const refreshVisits = useCallback(async () => {
    try {
      const visits = await api.getVisits();
      setData((d) => ({ ...d, visits }));
    } catch { /* keep last known */ }
  }, []);

  const refreshNotifications = useCallback(async () => {
    try {
      const notifications = await api.getNotifications();
      setData((d) => ({ ...d, notifications }));
    } catch { /* keep last known */ }
  }, []);

  const refreshActivity = useCallback(async () => {
    try {
      const activityLogs = await api.getActivity(50);
      setData((d) => ({ ...d, activityLogs }));
    } catch { /* keep last known */ }
  }, []);

  const refreshDashboard = useCallback(async () => {
    try {
      const [stats, logs] = await Promise.all([api.getDashboardStats(), api.getApiLogs()]);
      setData((d) => ({ ...d, apiLogs: logs.recent ?? [] }));
    } catch { /* keep last known */ }
  }, []);

  const refreshSettings = useCallback(async () => {
    try {
      const settings = await api.getSettings();
      setData((d) => ({ ...d, settings }));
    } catch { /* keep last known */ }
  }, []);

  const refresh = useCallback(async () => {
    try {
      const [patients, doctors, services, appointments, visits, notifications, settings, activityLogs] =
        await Promise.all([
          api.getPatients(), api.getDoctors(), api.getServices(), api.getAppointments(),
          api.getVisits(), api.getNotifications(), api.getSettings(), api.getActivity(50),
        ]);
      setData({ patients, doctors, services, appointments, visits, notifications, apiLogs: [], activityLogs, settings });
    } catch { /* keep last known */ }
  }, []);

  // ---- Initial load ----
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [patients, doctors, services, appointments, visits, notifications, settings, activityLogs] =
          await Promise.all([
            api.getPatients(), api.getDoctors(), api.getServices(), api.getAppointments(),
            api.getVisits(), api.getNotifications(), api.getSettings(), api.getActivity(50),
          ]);
        if (!cancelled) setData({ patients, doctors, services, appointments, visits, notifications, apiLogs: [], activityLogs, settings });
      } catch (e) {
        if (!cancelled) toast("error", e instanceof ApiError ? e.message : "تعذر تحميل البيانات من الخادم");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- Smart real-time polling ----
  // Polls notifications + appointments + activity frequently (every 15s) to detect
  // external changes (AI Agent, other users). Other resources poll less frequently.
  // This is targeted: only the affected slices of state are updated, never a full reload.
  useEffect(() => {
    const fastPoll = window.setInterval(async () => {
      // Notifications + activity change most frequently and are lightweight
      try {
        const [notifications, activityLogs] = await Promise.all([api.getNotifications(), api.getActivity(50)]);
        setData((d) => ({ ...d, notifications, activityLogs }));
      } catch { /* ignore */ }
    }, 15000);

    const mediumPoll = window.setInterval(async () => {
      // Appointments can be created by AI Agent — sync regularly
      try {
        const appointments = await api.getAppointments();
        setData((d) => ({ ...d, appointments }));
      } catch { /* ignore */ }
    }, 30000);

    const slowPoll = window.setInterval(async () => {
      // Patients, doctors, services, visits — less frequent changes
      try {
        const [patients, doctors, services, visits] = await Promise.all([
          api.getPatients(), api.getDoctors(), api.getServices(), api.getVisits(),
        ]);
        setData((d) => ({ ...d, patients, doctors, services, visits }));
      } catch { /* ignore */ }
    }, 60000);

    return () => {
      window.clearInterval(fastPoll);
      window.clearInterval(mediumPoll);
      window.clearInterval(slowPoll);
    };
  }, []);

  // ---- Theme handling ----
  useEffect(() => {
    localStorage.setItem("dental_theme", JSON.stringify(theme));
    setEffectiveDark(applyTheme(theme));
    if (theme === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const handler = () => setEffectiveDark(applyTheme("system"));
      mq.addEventListener("change", handler);
      return () => mq.removeEventListener("change", handler);
    }
  }, [theme]);

  const setTheme = useCallback((t: ThemeMode) => {
    setThemeState(t);
    api.updateSettings({ theme: t }).then((settings) => setData((d) => ({ ...d, settings })), () => {});
  }, []);

  // ---- Toasts ----
  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);
  const toast = useCallback((type: ToastType, message: string) => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-2), { id, type, message }]);
  }, []);

  // ---- Notification popup detection (skips seed notifications on first load) ----
  const knownIds = useRef<Set<string>>(new Set());
  const mountedRef = useRef(false);
  useEffect(() => {
    if (!loading && !mountedRef.current) {
      knownIds.current = new Set(data.notifications.map((n) => n.id));
      mountedRef.current = true;
      return;
    }
    if (!mountedRef.current) return;
    const fresh = data.notifications.filter((n) => !knownIds.current.has(n.id));
    if (!fresh.length) return;
    fresh.forEach((n) => knownIds.current.add(n.id));
    if (!data.settings.notificationsEnabled) return;
    // Show popup for the newest notification
    const newest = fresh[0];
    if (newest) setPopupNotification(newest);
    // Play sound if enabled
    if (data.settings.soundEnabled !== false) {
      playNotificationSound(data.settings.notificationSound ?? "default");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.notifications, data.settings.notificationsEnabled, data.settings.soundEnabled, loading]);

  const dismissPopup = useCallback(() => setPopupNotification(null), []);

  // ---- Mutation wrapper: run API, do targeted refresh, surface toasts ----
  // Each mutation refreshes ONLY the affected resources, not the entire app.
  const mutate = useCallback(
    async <T,>(label: { success: string; error: string }, fn: () => Promise<T>, refreshFns: (() => Promise<void>)[]): Promise<T> => {
      try {
        const result = await fn();
        // Targeted refresh — only affected resources, preserves all other state
        await Promise.all(refreshFns.map((f) => f()));
        toast("success", label.success);
        return result;
      } catch (e) {
        const message = e instanceof ApiError ? e.message : label.error;
        toast("error", message);
        throw e;
      }
    },
    [toast]
  );

  // ---- Notifications ----
  const markNotificationRead = useCallback(async (id: string) => {
    await api.markNotificationRead(id);
    const notifications = await api.getNotifications();
    setData((d) => ({ ...d, notifications }));
  }, []);
  const markAllRead = useCallback(async () => {
    await api.markAllNotificationsRead();
    const notifications = await api.getNotifications();
    setData((d) => ({ ...d, notifications }));
    toast("success", "تم تعليم كل الإشعارات كمقروءة");
  }, [toast]);
  const clearNotifications = useCallback(async () => {
    await api.clearNotifications();
    setData((d) => ({ ...d, notifications: [] }));
    toast("success", "تم مسح الإشعارات");
  }, [toast]);

  // ---- Settings ----
  const updateSettings = useCallback(async (patch: Partial<Settings>) => {
    try {
      const settings = await api.updateSettings(patch);
      setData((d) => ({ ...d, settings }));
      toast("success", "تم حفظ التعديلات");
    } catch {
      toast("error", "تعذر حفظ التعديلات");
    }
  }, [toast]);

  // ---- CRUD (each mutation refreshes only affected resources) ----
  const createPatient = useCallback((input: any) =>
    mutate({ success: "تم إنشاء ملف المريض بنجاح", error: "تعذر إنشاء ملف المريض" }, () => api.createPatient(input), [refreshPatients, refreshNotifications, refreshActivity]).then((p) => { refreshDashboard(); return p; }),
    [mutate, refreshPatients, refreshNotifications, refreshActivity, refreshDashboard]);
  const updatePatient = useCallback((id: string, patch: Partial<Patient>) =>
    mutate({ success: "تم تحديث بيانات المريض", error: "تعذر تحديث بيانات المريض" }, () => api.updatePatient(id, patch), [refreshPatients, refreshNotifications, refreshActivity]),
    [mutate, refreshPatients, refreshNotifications, refreshActivity]);
  const deletePatient = useCallback((id: string) =>
    mutate({ success: "تم حذف المريض", error: "تعذر حذف المريض" }, () => api.deletePatient(id), [refreshPatients, refreshNotifications, refreshActivity]).then(() => undefined),
    [mutate, refreshPatients, refreshNotifications, refreshActivity]);

  const createDoctor = useCallback((input: any) =>
    mutate({ success: "تم إضافة الطبيب بنجاح", error: "تعذر إضافة الطبيب" }, () => api.createDoctor(input), [refreshDoctors, refreshNotifications, refreshActivity]),
    [mutate, refreshDoctors, refreshNotifications, refreshActivity]);
  const updateDoctor = useCallback((id: string, patch: Partial<Doctor>) =>
    mutate({ success: "تم تحديث بيانات الطبيب", error: "تعذر تحديث بيانات الطبيب" }, () => api.updateDoctor(id, patch), [refreshDoctors, refreshNotifications, refreshActivity]),
    [mutate, refreshDoctors, refreshNotifications, refreshActivity]);
  const deleteDoctor = useCallback((id: string) =>
    mutate({ success: "تم حذف الطبيب", error: "تعذر حذف الطبيب" }, () => api.deleteDoctor(id), [refreshDoctors, refreshNotifications, refreshActivity]).then(() => undefined),
    [mutate, refreshDoctors, refreshNotifications, refreshActivity]);

  const createService = useCallback((input: any) =>
    mutate({ success: "تم إضافة الخدمة بنجاح", error: "تعذر إضافة الخدمة" }, () => api.createService(input), [refreshServices, refreshNotifications, refreshActivity]),
    [mutate, refreshServices, refreshNotifications, refreshActivity]);
  const updateService = useCallback((id: string, patch: Partial<Service>) =>
    mutate({ success: "تم تحديث الخدمة", error: "تعذر تحديث الخدمة" }, () => api.updateService(id, patch), [refreshServices, refreshNotifications, refreshActivity]),
    [mutate, refreshServices, refreshNotifications, refreshActivity]);
  const deleteService = useCallback((id: string) =>
    mutate({ success: "تم حذف الخدمة", error: "تعذر حذف الخدمة" }, () => api.deleteService(id), [refreshServices, refreshNotifications, refreshActivity]).then(() => undefined),
    [mutate, refreshServices, refreshNotifications, refreshActivity]);

  const bookAppointment = useCallback((input: any) =>
    mutate({ success: "تم حجز الموعد بنجاح", error: "تعذر حجز الموعد" }, () => api.createAppointment(input), [refreshAppointments, refreshPatients, refreshNotifications, refreshActivity]).then((a) => { refreshDashboard(); return a; }),
    [mutate, refreshAppointments, refreshPatients, refreshNotifications, refreshActivity, refreshDashboard]);
  const updateAppointment = useCallback((id: string, patch: any) =>
    mutate({ success: "تم تعديل الموعد بنجاح", error: "تعذر تعديل الموعد" }, () => api.updateAppointment(id, patch), [refreshAppointments, refreshNotifications, refreshActivity]),
    [mutate, refreshAppointments, refreshNotifications, refreshActivity]);
  const cancelAppointment = useCallback((id: string) =>
    mutate({ success: "تم إلغاء الموعد", error: "تعذر إلغاء الموعد" }, () => api.cancelAppointment(id), [refreshAppointments, refreshNotifications, refreshActivity]).then(() => undefined),
    [mutate, refreshAppointments, refreshNotifications, refreshActivity]);
  const completeAppointment = useCallback((id: string) =>
    mutate({ success: "تم إكمال الموعد وتسجيل الزيارة", error: "تعذر إكمال الموعد" }, () => api.completeAppointment(id), [refreshAppointments, refreshVisits, refreshNotifications, refreshActivity]).then(() => { refreshDashboard(); }),
    [mutate, refreshAppointments, refreshVisits, refreshNotifications, refreshActivity, refreshDashboard]);

  const createVisit = useCallback((input: any) =>
    mutate({ success: "تم تسجيل الزيارة بنجاح", error: "تعذر تسجيل الزيارة" }, () => api.createVisit(input), [refreshVisits, refreshPatients, refreshNotifications, refreshActivity]).then((v) => { refreshDashboard(); return v; }),
    [mutate, refreshVisits, refreshPatients, refreshNotifications, refreshActivity, refreshDashboard]);
  const updateVisit = useCallback((id: string, patch: Partial<Visit>) =>
    mutate({ success: "تم تحديث الزيارة", error: "تعذر تحديث الزيارة" }, () => api.updateVisit(id, patch), [refreshVisits]),
    [mutate, refreshVisits]);
  const deleteVisit = useCallback((id: string) =>
    mutate({ success: "تم حذف الزيارة", error: "تعذر حذف الزيارة" }, () => api.deleteVisit(id), [refreshVisits]).then(() => undefined),
    [mutate, refreshVisits]);

  // ---- Global search ----
  const globalSearch = useCallback((q: string): SearchResult => {
    const query = q.trim().toLowerCase();
    if (!query) return { patients: [], doctors: [], services: [], appointments: [] };
    const today = todayKey();
    return {
      patients: data.patients.filter((p) => !p.isDeleted && (p.name.toLowerCase().includes(query) || p.phone.includes(query))).slice(0, 5),
      doctors: data.doctors.filter((dr) => !dr.isDeleted && dr.isActive && (dr.name.toLowerCase().includes(query) || dr.specialty.toLowerCase().includes(query))).slice(0, 5),
      services: data.services.filter((s) => !s.isDeleted && s.isActive && s.name.toLowerCase().includes(query)).slice(0, 5),
      appointments: data.appointments.filter((a) => {
        if (a.isDeleted) return false;
        const p = data.patients.find((x) => x.id === a.patientId);
        const dr = data.doctors.find((x) => x.id === a.doctorId);
        return (p?.name.toLowerCase().includes(query) ?? false) || (p?.phone.includes(query) ?? false) || (dr?.name.toLowerCase().includes(query) ?? false);
      }).filter((a) => a.date >= today).slice(0, 5),
    };
  }, [data]);

  const value = useMemo<AppContextValue>(() => ({
    data, loading, refresh, refreshPatients, refreshDoctors, refreshServices,
    refreshAppointments, refreshVisits, refreshNotifications, refreshActivity, refreshDashboard,
    toasts, toast, dismissToast, theme, setTheme, effectiveDark,
    settings: data.settings, updateSettings, popupNotification, dismissPopup,
    markNotificationRead, markAllRead, clearNotifications, globalSearch,
    createPatient, updatePatient, deletePatient,
    createDoctor, updateDoctor, deleteDoctor,
    createService, updateService, deleteService,
    bookAppointment, updateAppointment, cancelAppointment, completeAppointment,
    createVisit, updateVisit, deleteVisit,
  }), [
    data, loading, refresh, refreshPatients, refreshDoctors, refreshServices,
    refreshAppointments, refreshVisits, refreshNotifications, refreshActivity, refreshDashboard,
    toasts, toast, dismissToast, theme, setTheme, effectiveDark,
    updateSettings, popupNotification, dismissPopup,
    markNotificationRead, markAllRead, clearNotifications, globalSearch,
    createPatient, updatePatient, deletePatient,
    createDoctor, updateDoctor, deleteDoctor,
    createService, updateService, deleteService,
    bookAppointment, updateAppointment, cancelAppointment, completeAppointment,
    createVisit, updateVisit, deleteVisit,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export function usePeriod(): [ReportPeriod, (p: ReportPeriod) => void] {
  const [period, setPeriod] = useState<ReportPeriod>("month");
  return [period, setPeriod];
}

// ---- Notification sound player ----
// Uses Web Audio API to generate a pleasant, short notification tone.
// Gracefully handles browser autoplay restrictions.
let audioCtx: AudioContext | null = null;
function playNotificationSound(sound: string) {
  try {
    if (!audioCtx) {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      audioCtx = new AC();
    }
    // Resume if suspended (browser autoplay restriction)
    if (audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => {});
    }
    const now = audioCtx.currentTime;
    const notes = sound === "soft" ? [880, 1108] : sound === "chime" ? [659, 880, 1108] : [784, 1047];
    notes.forEach((freq, i) => {
      const osc = audioCtx!.createOscillator();
      const gain = audioCtx!.createGain();
      osc.connect(gain);
      gain.connect(audioCtx!.destination);
      osc.frequency.value = freq;
      osc.type = "sine";
      const start = now + i * 0.12;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.15, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.3);
      osc.start(start);
      osc.stop(start + 0.3);
    });
  } catch {
    /* audio failure must never break the notification system */
  }
}
