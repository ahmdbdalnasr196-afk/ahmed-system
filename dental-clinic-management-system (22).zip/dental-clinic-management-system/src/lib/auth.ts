// Authentication library — database-backed with secure password hashing.
// Passwords are NEVER stored in plaintext or sent to the frontend.
// Uses Node's built-in crypto.scryptSync for secure password hashing.

import { db } from "@/lib/db";
import type { AuthUser, UserRole } from "@/types";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";

// ---------------------------------------------------------------------------
// Password hashing — scrypt with per-user salt. Secure and built into Node.
// ---------------------------------------------------------------------------
function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const hashBuf = Buffer.from(key, "hex");
  const testBuf = scryptSync(password, salt, 64);
  if (hashBuf.length !== testBuf.length) return false;
  return timingSafeEqual(hashBuf, testBuf);
}

// ---------------------------------------------------------------------------
// Session token (base64 of JSON). Structured so it can be replaced with JWT
// or server sessions later without touching the UI.
// ---------------------------------------------------------------------------
export function createSessionToken(user: AuthUser): string {
  const payload = { ...user, ts: Date.now() };
  return Buffer.from(JSON.stringify(payload)).toString("base64");
}

export function parseSessionToken(token: string): AuthUser | null {
  try {
    const payload = JSON.parse(Buffer.from(token, "base64").toString());
    if (!payload.email || !payload.role) return null;
    return { email: payload.email, role: payload.role, name: payload.name };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Credential verification — checks the database with hashed passwords.
// NEVER returns the password or hash to the caller.
// ---------------------------------------------------------------------------
export async function validateCredentials(email: string, password: string): Promise<AuthUser | null> {
  const account = await db.account.findUnique({
    where: { email: email.trim().toLowerCase() },
  });
  if (!account) return null;
  if (!verifyPassword(password, account.passwordHash)) return null;
  return { email: account.email, role: account.role as UserRole, name: account.name };
}

// ---------------------------------------------------------------------------
// Account management — owner-only operations.
// These functions NEVER expose password hashes.
// ---------------------------------------------------------------------------
export interface AccountInfo {
  id: string;
  email: string;
  role: UserRole;
  name: string;
}

export async function listAccounts(): Promise<AccountInfo[]> {
  const accounts = await db.account.findMany();
  return accounts.map((a) => ({ id: a.id, email: a.email, role: a.role as UserRole, name: a.name }));
}

export async function getAccountByEmail(email: string): Promise<AccountInfo | null> {
  const account = await db.account.findUnique({ where: { email: email.trim().toLowerCase() } });
  if (!account) return null;
  return { id: account.id, email: account.email, role: account.role as UserRole, name: account.name };
}

export async function updateAccountEmail(role: UserRole, newEmail: string): Promise<AccountInfo> {
  const account = await db.account.findFirst({ where: { role } });
  if (!account) throw new Error("الحساب غير موجود");
  const email = newEmail.trim().toLowerCase();
  // Check email isn't used by another account
  const existing = await db.account.findUnique({ where: { email } });
  if (existing && existing.id !== account.id) throw new Error("هذا البريد الإلكتروني مستخدم بالفعل");
  const updated = await db.account.update({ where: { id: account.id }, data: { email } });
  return { id: updated.id, email: updated.email, role: updated.role as UserRole, name: updated.name };
}

export async function updateAccountPassword(role: UserRole, newPassword: string): Promise<void> {
  const account = await db.account.findFirst({ where: { role } });
  if (!account) throw new Error("الحساب غير موجود");
  if (newPassword.length < 6) throw new Error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
  await db.account.update({ where: { id: account.id }, data: { passwordHash: hashPassword(newPassword) } });
}

// ---------------------------------------------------------------------------
// Seed default accounts on first run. Passwords are hashed immediately.
// ---------------------------------------------------------------------------
export async function ensureAccountsSeed(): Promise<void> {
  const count = await db.account.count();
  if (count > 0) return;
  // Seed with default credentials — hashed securely in the database.
  // These defaults can be changed by the owner through the Settings page.
  await db.account.createMany({
    data: [
      { email: "admin@clinic.com", passwordHash: hashPassword("Admin123"), role: "admin", name: "مدير العيادة" },
      { email: "owner@clinic.com", passwordHash: hashPassword("Owner123"), role: "owner", name: "مالك العيادة" },
    ],
  });
}
