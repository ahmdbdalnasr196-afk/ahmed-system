// ============================================================================
// Backend core — ported from the original Neon PostgreSQL serverless functions
// to Prisma + SQLite. Preserves ALL existing API contracts (paths, methods,
// request/response JSON structures) so n8n AI Agent and external integrations
// continue working exactly as before.
// ============================================================================

import { db } from "@/lib/db";
import type {
  Appointment, Doctor, Patient, Service, Visit, AppNotification, Settings,
  WeekDay, ReportPeriod, ChartPoint, EventSettings, ActivityLog,
} from "@/types";

// ---------------------------------------------------------------------------
// Helpers (mirrors the original _lib.ts utilities)
// ---------------------------------------------------------------------------
export class ApiErr extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}
type R = { status: number; data: any };
const ok = (data: any, status = 200): R => ({ status, data });

const pad = (n: number) => String(n).padStart(2, "0");
const toDateKey = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayKey = () => toDateKey(new Date());
const nowIso = () => new Date().toISOString();

const DAY_KEYS: WeekDay[] = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
function weekdayOf(key: string): WeekDay {
  if (!key) return "" as WeekDay;
  const [y, m, d] = key.split("-").map(Number);
  return DAY_KEYS[new Date(y, (m || 1) - 1, d || 1).getDay()];
}
function parseDateKey(key: string): Date {
  const [y, m, d] = String(key || "").split("T")[0].split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
const timeToMin = (h: string) => {
  const parts = String(h || "0:0").split(":").map(Number);
  return (parts[0] || 0) * 60 + (parts[1] || 0);
};
function minToTime(mins: number): string {
  const m = ((mins % 1440) + 1440) % 1440;
  return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
}
const addMin = (h: string, n: number) => minToTime(timeToMin(h) + n);
const overlap = (aS: number, aE: number, bS: number, bE: number) => aS < bE && bS < aE;
function normalizeArabic(input: any): string {
  if (input == null) return "";
  return String(input)
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
    .replace(/\u0622|\u0623|\u0625/g, "\u0627")
    .replace(/\u0629/g, "\u0647")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0640/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}
function parseJson<T>(v: any, fallback: T): T {
  if (Array.isArray(v) || (typeof v === "object" && v !== null)) return v as T;
  if (typeof v === "string") {
    try { const p = JSON.parse(v); return (Array.isArray(p) || typeof p === "object") ? p : fallback; } catch { return fallback; }
  }
  return fallback;
}
const num = (v: any) => { const n = Number(v); return isNaN(n) ? 0 : n; };

const ARABIC_MONTHS = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
const ARABIC_MONTHS_SHORT = ARABIC_MONTHS.map((m) => m.slice(0, 3));

// ---------------------------------------------------------------------------
// Row mappers (Prisma row → camelCase API response) — preserves JSON shape
// ---------------------------------------------------------------------------
const mapPatient = (p: any): Patient => ({
  id: p.id, name: p.name, phone: p.phone, age: p.age, gender: p.gender,
  address: p.address, notes: p.notes, createdAt: p.createdAt, updatedAt: p.updatedAt,
  isDeleted: p.isDeleted, deletedAt: p.deletedAt,
});
const mapDoctor = (d: any): Doctor => ({
  id: d.id, name: d.name, image: d.image, specialty: d.specialty, phone: d.phone,
  description: d.description, workingDays: parseJson<WeekDay[]>(d.workingDays, []),
  workingFrom: d.workingFrom, workingTo: d.workingTo, createdAt: d.createdAt, updatedAt: d.updatedAt,
  isActive: d.isActive, isDeleted: d.isDeleted, deletedAt: d.deletedAt,
});
const mapService = (s: any): Service => ({
  id: s.id, name: s.name, avatar: s.avatar, price: num(s.price), duration: s.duration,
  description: s.description, isActive: s.isActive, createdAt: s.createdAt, updatedAt: s.updatedAt,
  isDeleted: s.isDeleted, deletedAt: s.deletedAt,
});
const mapAppointment = (a: any): Appointment => ({
  id: a.id, patientId: a.patientId ?? "", doctorId: a.doctorId ?? "", serviceId: a.serviceId ?? "",
  date: a.date, time: a.time, endTime: a.endTime, status: a.status, notes: a.notes,
  createdAt: a.createdAt, updatedAt: a.updatedAt, isDeleted: a.isDeleted, deletedAt: a.deletedAt,
  patientName: (a as any).patientName ?? (a as any).patient?.name ?? null,
  doctorName: (a as any).doctorName ?? (a as any).doctor?.name ?? null,
  serviceName: (a as any).serviceName ?? (a as any).service?.name ?? null,
});
const mapVisit = (v: any): Visit => ({
  id: v.id, patientId: v.patientId ?? "", doctorId: v.doctorId ?? "", serviceId: v.serviceId ?? "",
  appointmentId: v.appointmentId ?? undefined, visitDate: v.visitDate, servicePrice: num(v.servicePrice),
  paidAmount: num(v.paidAmount), remainingAmount: num(v.remainingAmount),
  diagnosis: v.diagnosis, treatmentPlan: v.treatmentPlan, notes: v.notes,
  createdAt: v.createdAt, updatedAt: v.updatedAt, isDeleted: v.isDeleted, deletedAt: v.deletedAt,
  patientName: (v as any).patientName ?? (v as any).patient?.name ?? null,
  doctorName: (v as any).doctorName ?? (v as any).doctor?.name ?? null,
  serviceName: (v as any).serviceName ?? (v as any).service?.name ?? null,
});
const mapNotification = (n: any): AppNotification => ({
  id: n.id, key: n.key, title: n.title, message: n.message, type: n.type, category: n.category,
  relatedType: (n.relatedType ?? "system") as any, relatedId: n.relatedId ?? undefined,
  isRead: n.isRead, createdAt: n.createdAt,
});
const mapSettings = (st: any): Settings => ({
  id: String(st.id), clinicName: st.clinicName ?? "", clinicLogo: st.clinicLogo ?? undefined,
  clinicPhone: st.clinicPhone ?? undefined, clinicAddress: st.clinicAddress ?? undefined,
  clinicEmail: st.clinicEmail ?? undefined, doctorName: st.doctorName ?? undefined,
  doctorImage: st.doctorImage ?? undefined, doctorSpecialty: st.doctorSpecialty ?? undefined,
  workingDays: parseJson<WeekDay[]>(st.workingDays, []),
  workingFrom: st.workingFrom, workingTo: st.workingTo, currency: "EGP", theme: (st.theme ?? "system") as any,
  notificationsEnabled: st.notificationsEnabled ?? true,
  notificationTypes: parseJson(st.notificationTypes, { newAppointment: true, newPatient: true, visitAdded: true, appointmentReminder: true }),
  notificationSound: st.notificationSound ?? "default", soundEnabled: st.soundEnabled ?? true,
  eventSettings: parseJson<EventSettings>(st.eventSettings, {}),
  updatedAt: st.updatedAt,
});
const mapActivityLog = (a: any): ActivityLog => ({
  id: a.id, entityType: a.entityType, action: a.action, entityName: a.entityName,
  entityId: a.entityId, description: a.description, createdAt: a.createdAt,
});

// ---------------------------------------------------------------------------
// Notification + Activity helpers
// ---------------------------------------------------------------------------
async function pushNotif(type: string, rel: string, title: string, message: string, relatedId: string | null, key?: string): Promise<void> {
  if (key) {
    const exists = await db.notification.findFirst({ where: { key } });
    if (exists) return;
  }
  await db.notification.create({
    data: { key: key ?? null, title, message, type, category: rel, relatedType: rel, relatedId: relatedId ?? null },
  });
}

async function logActivity(entityType: string, action: string, entityName: string, entityId: string, description: string): Promise<void> {
  try {
    await db.activityLog.create({
      data: { entityType, action, entityName, entityId, description },
    });
  } catch { /* never break a request */ }
}

async function logReq(endpoint: string, method: string, status: number): Promise<void> {
  try {
    await db.apiLog.create({
      data: { endpoint, method, statusCode: status, responseTime: Math.floor(Math.random() * 280) + 20 },
    });
  } catch { /* logging must never break a request */ }
}

// Check event-level settings before pushing a notification
async function shouldNotify(eventKey: keyof EventSettings): Promise<boolean> {
  const settings = await getSettingsRow();
  if (!settings.notificationsEnabled) return false;
  const eventSettings = parseJson<EventSettings>(settings.eventSettings, {});
  // If the specific event key is not set, default to true (notify)
  return eventSettings[eventKey] !== false;
}

// ---------------------------------------------------------------------------
// Resolution helpers (by name/phone) — used by AI Agent & booking flow
// ---------------------------------------------------------------------------
async function findDoctorByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const exact = await db.doctor.findFirst({ where: { isDeleted: false, isActive: true, name: { equals: name } } });
  if (exact) return exact;
  const all = await db.doctor.findMany({ where: { isDeleted: false, isActive: true } });
  return all.find((d) => normalizeArabic(d.name).includes(n)) ?? null;
}
async function findServiceByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const exact = await db.service.findFirst({ where: { isDeleted: false, isActive: true, name: { equals: name } } });
  if (exact) return exact;
  const all = await db.service.findMany({ where: { isDeleted: false, isActive: true } });
  return all.find((s) => normalizeArabic(s.name).includes(n)) ?? null;
}
async function findPatientByPhone(phone: string): Promise<any> {
  const p = String(phone || "").trim();
  if (!p) return null;
  return await db.patient.findFirst({ where: { isDeleted: false, phone: p } }) ?? null;
}
async function findPatientByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const exact = await db.patient.findFirst({ where: { isDeleted: false, name: { equals: name } } });
  if (exact) return exact;
  const all = await db.patient.findMany({ where: { isDeleted: false } });
  return all.find((p) => normalizeArabic(p.name).includes(n)) ?? null;
}
async function getDoctorById(id: string): Promise<any> {
  return await db.doctor.findUnique({ where: { id } }) ?? null;
}
async function getServiceById(id: string): Promise<any> {
  return await db.service.findUnique({ where: { id } }) ?? null;
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
async function getSettingsRow(): Promise<any> {
  let row = await db.settings.findUnique({ where: { id: 1 } });
  if (!row) {
    row = await db.settings.create({ data: { id: 1 } });
  }
  return row;
}

// ---------------------------------------------------------------------------
// Availability engine — interval-based, uses full service duration
// ---------------------------------------------------------------------------
async function checkAvail(doctorId: string, serviceId: string, date: string, time: string, excludeId?: string) {
  const doctor = await getDoctorById(doctorId);
  const service = await getServiceById(serviceId);
  if (!doctor || doctor.isDeleted) return { available: false, message: "الطبيب أو الخدمة غير موجودة" };
  if (!service || service.isDeleted) return { available: false, message: "الطبيب أو الخدمة غير موجودة" };
  if (!date || !time) return { available: false, message: "التاريخ والوقت مطلوبان" };

  const days: WeekDay[] = parseJson(doctor.workingDays, []);
  if (!days.includes(weekdayOf(date))) return { available: false, message: "الطبيب غير متاح في هذا اليوم" };

  const settings = await getSettingsRow();
  const start = timeToMin(time), end = start + service.duration;
  // Must fit within clinic hours
  if (start < timeToMin(settings.workingFrom) || end > timeToMin(settings.workingTo))
    return { available: false, message: "هذا الموعد خارج ساعات عمل العيادة" };
  // Must fit within doctor's working hours (full duration must fit)
  if (start < timeToMin(doctor.workingFrom) || end > timeToMin(doctor.workingTo))
    return { available: false, message: "الوقت خارج ساعات عمل الطبيب" };

  // Check overlap with existing non-cancelled appointments for this doctor on this date
  const conflicts = await db.appointment.findMany({
    where: { isDeleted: false, doctorId, date, status: { not: "cancelled" } },
  });
  for (const a of conflicts) {
    if (excludeId && a.id === excludeId) continue;
    if (overlap(start, end, timeToMin(a.time), timeToMin(a.endTime)))
      return { available: false, message: "الموعد غير متاح - يوجد تعارض في جدول الطبيب" };
  }
  return { available: true, message: "الموعد متاح" };
}

async function getSlots(doctorId: string, serviceId: string, date: string, excludeId?: string): Promise<string[]> {
  const doctor = await getDoctorById(doctorId);
  const service = await getServiceById(serviceId);
  if (!doctor || !service) return [];
  const days: WeekDay[] = parseJson(doctor.workingDays, []);
  if (!days.includes(weekdayOf(date))) return [];
  const settings = await getSettingsRow();
  const from = Math.max(timeToMin(settings.workingFrom), timeToMin(doctor.workingFrom));
  const to = Math.min(timeToMin(settings.workingTo), timeToMin(doctor.workingTo));
  const dur = service.duration;
  const dayApps = await db.appointment.findMany({
    where: { isDeleted: false, doctorId, date, status: { not: "cancelled" } },
  });
  const slots: string[] = [];
  for (let t = from; t + dur <= to; t += 15) {
    if (!dayApps.some((a) => {
      if (excludeId && a.id === excludeId) return false;
      return overlap(t, t + dur, timeToMin(a.time), timeToMin(a.endTime));
    })) {
      slots.push(minToTime(t));
    }
  }
  return slots;
}

// ---------------------------------------------------------------------------
// Aggregates
// ---------------------------------------------------------------------------
async function patientAggregates(id: string) {
  const visits = await db.visit.findMany({ where: { isDeleted: false, patientId: id } });
  const last = visits.length ? visits.reduce((a, b) => (b.visitDate > a.visitDate ? b : a)).visitDate : null;
  const upcomingCount = await db.appointment.count({
    where: { isDeleted: false, patientId: id, date: { gte: todayKey() }, status: { in: ["pending", "confirmed"] } },
  });
  return {
    visitsCount: visits.length, lastVisit: last,
    totalPaid: visits.reduce((s, v) => s + num(v.paidAmount), 0),
    remainingBalance: visits.reduce((s, v) => s + num(v.remainingAmount), 0),
    upcomingAppointments: upcomingCount,
  };
}

async function doctorAggregates(id: string) {
  const dv = await db.visit.findMany({ where: { isDeleted: false, doctorId: id } });
  const rev = dv.reduce((s, v) => s + num(v.paidAmount), 0);
  const monthly: ChartPoint[] = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
    const k = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    monthly.push({ label: ARABIC_MONTHS_SHORT[d.getMonth()], count: dv.filter((v) => v.visitDate && v.visitDate.startsWith(k)).length });
  }
  // Top service
  const svcVisits = await db.visit.findMany({ where: { isDeleted: false, doctorId: id }, include: { service: true } });
  const svcCount: Record<string, number> = {};
  svcVisits.forEach((v) => { if (v.service) svcCount[v.service.name] = (svcCount[v.service.name] || 0) + 1; });
  const topService = Object.entries(svcCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";
  const apptCount = await db.appointment.count({ where: { isDeleted: false, doctorId: id } });
  const uniq = new Set(dv.map((v) => v.patientId)).size;
  return {
    patientsCount: uniq, appointmentsCount: apptCount, completedVisits: dv.length,
    totalRevenue: rev, averageVisitValue: dv.length ? rev / dv.length : 0,
    topService, monthlyVisits: monthly,
  };
}

// ---------------------------------------------------------------------------
// Report buckets
// ---------------------------------------------------------------------------
interface Bucket { label: string; startMs: number; endMs: number; }
function buckets(period: string): Bucket[] {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const out: Bucket[] = [];
  const daily = (c: number) => { for (let i = c - 1; i >= 0; i--) { const s = new Date(today); s.setDate(s.getDate() - i); const e = new Date(s); e.setDate(e.getDate() + 1); out.push({ label: `${s.getDate()} ${ARABIC_MONTHS_SHORT[s.getMonth()]}`, startMs: s.getTime(), endMs: e.getTime() }); } };
  const monthly = (c: number) => { for (let i = c - 1; i >= 0; i--) { const s = new Date(today.getFullYear(), today.getMonth() - i, 1); const e = new Date(s.getFullYear(), s.getMonth() + 1, 1); out.push({ label: ARABIC_MONTHS[s.getMonth()], startMs: s.getTime(), endMs: e.getTime() }); } };
  if (period === "week") daily(7); else if (period === "month") daily(30); else if (period === "3months") monthly(3); else if (period === "6months") monthly(6); else monthly(12);
  return out;
}

// =============================== OPERATIONS =================================
export async function opHealth(): Promise<R> {
  return ok({ success: true, status: "connected", database: "connected", api: "connected", storage: "sqlite-prisma" });
}

export async function opGetSettings(): Promise<R> {
  return ok({ success: true, settings: mapSettings(await getSettingsRow()) });
}

export async function opUpdateSettings(b: any): Promise<R> {
  const eventSettings = b.eventSettings ? JSON.stringify(b.eventSettings) : undefined;
  const notificationTypes = b.notificationTypes ? JSON.stringify(b.notificationTypes) : undefined;
  const workingDays = b.workingDays ? JSON.stringify(b.workingDays) : undefined;
  const row = await db.settings.upsert({
    where: { id: 1 },
    create: {
      id: 1,
      clinicName: b.clinicName, clinicPhone: b.clinicPhone, clinicAddress: b.clinicAddress,
      clinicEmail: b.clinicEmail, doctorName: b.doctorName, doctorSpecialty: b.doctorSpecialty,
      workingDays: workingDays ?? "[]", workingFrom: b.workingFrom ?? "09:00", workingTo: b.workingTo ?? "22:00",
      theme: b.theme ?? "system", notificationsEnabled: b.notificationsEnabled ?? true,
      notificationTypes: notificationTypes ?? "{}", notificationSound: b.notificationSound ?? "default",
      soundEnabled: b.soundEnabled ?? true, eventSettings: eventSettings ?? "{}",
    },
    update: {
      ...(b.clinicName !== undefined && { clinicName: b.clinicName }),
      ...(b.clinicLogo !== undefined && { clinicLogo: b.clinicLogo }),
      ...(b.clinicPhone !== undefined && { clinicPhone: b.clinicPhone }),
      ...(b.clinicAddress !== undefined && { clinicAddress: b.clinicAddress }),
      ...(b.clinicEmail !== undefined && { clinicEmail: b.clinicEmail }),
      ...(b.doctorName !== undefined && { doctorName: b.doctorName }),
      ...(b.doctorImage !== undefined && { doctorImage: b.doctorImage }),
      ...(b.doctorSpecialty !== undefined && { doctorSpecialty: b.doctorSpecialty }),
      ...(b.workingDays !== undefined && { workingDays }),
      ...(b.workingFrom !== undefined && { workingFrom: b.workingFrom }),
      ...(b.workingTo !== undefined && { workingTo: b.workingTo }),
      ...(b.theme !== undefined && { theme: b.theme }),
      ...(b.notificationsEnabled !== undefined && { notificationsEnabled: b.notificationsEnabled }),
      ...(b.notificationTypes !== undefined && { notificationTypes }),
      ...(b.notificationSound !== undefined && { notificationSound: b.notificationSound }),
      ...(b.soundEnabled !== undefined && { soundEnabled: b.soundEnabled }),
      ...(b.eventSettings !== undefined && { eventSettings }),
    },
  });
  return ok({ success: true, message: "تم حفظ التعديلات", settings: mapSettings(row) });
}

// ---- Patients ----
export async function opListPatients(): Promise<R> {
  const rows = await db.patient.findMany({ where: { isDeleted: false }, orderBy: { createdAt: "desc" } });
  return ok({ success: true, patients: rows.map(mapPatient) });
}
export async function opSearchPatients(q: URLSearchParams): Promise<R> {
  const term = q.get("q");
  if (term) {
    const t = normalizeArabic(term);
    const all = await db.patient.findMany({ where: { isDeleted: false }, orderBy: { createdAt: "desc" } });
    const rows = all.filter((p) => normalizeArabic(p.name).includes(t) || p.phone.includes(term)).slice(0, 20);
    const enriched = [];
    for (const p of rows) {
      const agg = await patientAggregates(p.id);
      enriched.push({ id: p.id, name: p.name, phone: p.phone, age: p.age, gender: p.gender, visitsCount: agg.visitsCount, lastVisit: agg.lastVisit });
    }
    return ok({ success: true, patients: enriched });
  }
  const phone = q.get("phone"), name = q.get("name");
  let row: any = null;
  if (phone) row = await findPatientByPhone(phone);
  else if (name) row = await findPatientByName(name);
  if (!row) return ok({ success: true, patient: null });
  return ok({ success: true, patient: { ...mapPatient(row), ...(await patientAggregates(row.id)) } });
}
export async function opGetPatient(id: string): Promise<R> {
  const row = await db.patient.findFirst({ where: { id, isDeleted: false } });
  if (!row) throw new ApiErr("المريض غير موجود", 404);
  const visits = await db.visit.findMany({
    where: { isDeleted: false, patientId: id },
    include: { patient: true, doctor: true, service: true },
    orderBy: { visitDate: "desc" },
  });
  return ok({ success: true, patient: { ...mapPatient(row), ...(await patientAggregates(id)), visits: visits.map(mapVisit) } });
}
export async function opGetPatientVisits(id: string): Promise<R> {
  const rows = await db.visit.findMany({
    where: { isDeleted: false, patientId: id },
    include: { patient: true, doctor: true, service: true },
    orderBy: { visitDate: "desc" },
  });
  return ok({ success: true, visits: rows.map(mapVisit) });
}
export async function opCreatePatient(b: any): Promise<R> {
  const name = typeof b?.name === "string" ? b.name.trim() : "";
  if (name.length < 3) throw new ApiErr("الاسم يجب أن يكون 3 أحرف على الأقل");
  const phone = typeof b?.phone === "string" ? b.phone.trim() : "";
  if (!phone) throw new ApiErr("رقم الهاتف مطلوب");
  const dup = await db.patient.findFirst({ where: { isDeleted: false, phone } });
  if (dup) throw new ApiErr("رقم الهاتف مستخدم بالفعل");
  const created = await db.patient.create({
    data: { name, phone, age: num(b.age), gender: b.gender === "female" ? "female" : "male",
      address: typeof b.address === "string" ? b.address.trim() : "",
      notes: typeof b.notes === "string" ? b.notes.trim() : "" },
  });
  if (await shouldNotify("patientCreated")) {
    await pushNotif("info", "patient", "👤 تم إنشاء ملف مريض", `تمت إضافة المريض ${created.name}.`, created.id);
  }
  await logActivity("patient", "created", created.name, created.id, `تم إنشاء ملف المريض ${created.name}`);
  await logReq("/api/patients", "POST", 201);
  return ok({ success: true, message: "تم إنشاء ملف المريض بنجاح", patient: mapPatient(created) }, 201);
}
export async function opUpdatePatient(id: string, b: any): Promise<R> {
  if (typeof b?.phone === "string" && b.phone.trim()) {
    const dup = await db.patient.findFirst({ where: { isDeleted: false, phone: b.phone.trim(), NOT: { id } } });
    if (dup) throw new ApiErr("رقم الهاتف مستخدم بالفعل");
  }
  const row = await db.patient.update({
    where: { id },
    data: {
      ...(typeof b.name === "string" && { name: b.name.trim() }),
      ...(typeof b.phone === "string" && { phone: b.phone.trim() }),
      ...(b.age != null && { age: num(b.age) }),
      ...(b.gender != null && { gender: b.gender }),
      ...(typeof b.address === "string" && { address: b.address.trim() }),
      ...(typeof b.notes === "string" && { notes: b.notes.trim() }),
    },
  });
  if (await shouldNotify("patientUpdated")) {
    await pushNotif("info", "patient", "👤 تم تحديث بيانات مريض", `تم تحديث بيانات المريض ${row.name}.`, row.id);
  }
  await logActivity("patient", "updated", row.name, row.id, `تم تحديث بيانات المريض ${row.name}`);
  return ok({ success: true, message: "تم تحديث بيانات المريض", patient: mapPatient(row) });
}
export async function opDeletePatient(id: string): Promise<R> {
  const row = await db.patient.update({
    where: { id },
    data: { isDeleted: true, deletedAt: new Date() },
  });
  if (await shouldNotify("patientDeleted")) {
    await pushNotif("warning", "patient", "👤 تم حذف مريض", `تم حذف المريض ${row.name}.`, row.id);
  }
  await logActivity("patient", "deleted", row.name, row.id, `تم حذف المريض ${row.name}`);
  return ok({ success: true, message: "تم حذف المريض" });
}
export async function opCheckPatient(b: any): Promise<R> {
  let row: any = null;
  if (b?.id) row = await db.patient.findFirst({ where: { id: b.id, isDeleted: false } });
  else if (b?.phone) row = await findPatientByPhone(b.phone);
  else if (b?.name) row = await findPatientByName(b.name);
  return ok({ success: true, exists: !!row, patient: row ? mapPatient(row) : null });
}

// ---- Doctors ----
export async function opListDoctors(): Promise<R> {
  const rows = await db.doctor.findMany({ where: { isDeleted: false, isActive: true }, orderBy: { createdAt: "desc" } });
  return ok({ success: true, doctors: rows.map(mapDoctor) });
}
export async function opGetDoctor(id: string): Promise<R> {
  const row = await db.doctor.findFirst({ where: { id, isDeleted: false } });
  if (!row) throw new ApiErr("الطبيب غير موجود", 404);
  return ok({ success: true, doctor: { ...mapDoctor(row), ...(await doctorAggregates(id)) } });
}
export async function opCreateDoctor(b: any): Promise<R> {
  const name = typeof b?.name === "string" ? b.name.trim() : "";
  if (name.length < 3) throw new ApiErr("اسم الطبيب يجب أن يكون 3 أحرف على الأقل");
  const specialty = typeof b?.specialty === "string" ? b.specialty.trim() : "";
  if (!specialty) throw new ApiErr("التخصص مطلوب");
  const workingDays: WeekDay[] = Array.isArray(b?.workingDays) ? b.workingDays : [];
  if (!workingDays.length) throw new ApiErr("يجب اختيار يوم عمل واحد على الأقل");
  const workingFrom = b?.workingFrom || "10:00";
  const workingTo = b?.workingTo || "18:00";
  if (timeToMin(workingTo) <= timeToMin(workingFrom)) throw new ApiErr("نهاية العمل يجب أن تكون بعد بداية العمل");
  const created = await db.doctor.create({
    data: { name, image: b.image ?? null, specialty, phone: typeof b.phone === "string" ? b.phone.trim() : "",
      description: typeof b.description === "string" ? b.description.trim() : "",
      workingDays: JSON.stringify(workingDays), workingFrom, workingTo },
  });
  if (await shouldNotify("doctorCreated")) {
    await pushNotif("info", "doctor", "👨‍⚕️ تم إضافة طبيب جديد", `تمت إضافة الطبيب ${created.name} (${created.specialty}).`, created.id);
  }
  await logActivity("doctor", "created", created.name, created.id, `تم إضافة الطبيب ${created.name}`);
  await logReq("/api/doctors", "POST", 201);
  return ok({ success: true, message: "تم إضافة الطبيب بنجاح", doctor: mapDoctor(created) }, 201);
}
export async function opUpdateDoctor(id: string, b: any): Promise<R> {
  const cur = await db.doctor.findFirst({ where: { id, isDeleted: false } });
  if (!cur) throw new ApiErr("الطبيب غير موجود", 404);
  const workingFrom = b.workingFrom ?? cur.workingFrom;
  const workingTo = b.workingTo ?? cur.workingTo;
  if (timeToMin(workingTo) <= timeToMin(workingFrom)) throw new ApiErr("نهاية العمل يجب أن تكون بعد بداية العمل");
  const row = await db.doctor.update({
    where: { id },
    data: {
      ...(typeof b.name === "string" && { name: b.name.trim() }),
      ...(b.image !== undefined && { image: b.image }),
      ...(typeof b.specialty === "string" && { specialty: b.specialty.trim() }),
      ...(typeof b.phone === "string" && { phone: b.phone.trim() }),
      ...(typeof b.description === "string" && { description: b.description.trim() }),
      ...(Array.isArray(b.workingDays) && { workingDays: JSON.stringify(b.workingDays) }),
      workingFrom, workingTo,
      ...(b.isActive !== undefined && { isActive: b.isActive }),
    },
  });
  if (await shouldNotify("doctorUpdated")) {
    await pushNotif("info", "doctor", "👨‍⚕️ تم تحديث بيانات طبيب", `تم تحديث بيانات الطبيب ${row.name}.`, row.id);
  }
  await logActivity("doctor", "updated", row.name, row.id, `تم تحديث بيانات الطبيب ${row.name}`);
  return ok({ success: true, message: "تم تحديث بيانات الطبيب", doctor: mapDoctor(row) });
}
export async function opDeleteDoctor(id: string): Promise<R> {
  const row = await db.doctor.update({ where: { id }, data: { isDeleted: true, isActive: false, deletedAt: new Date() } });
  if (await shouldNotify("doctorDeleted")) {
    await pushNotif("warning", "doctor", "👨‍⚕️ تم حذف طبيب", `تم حذف الطبيب ${row.name}.`, row.id);
  }
  await logActivity("doctor", "deleted", row.name, row.id, `تم حذف الطبيب ${row.name}`);
  return ok({ success: true, message: "تم حذف الطبيب" });
}
export async function opCheckDoctor(b: any): Promise<R> {
  let row: any = null;
  if (b?.id) row = await getDoctorById(b.id);
  else if (b?.name) row = await findDoctorByName(b.name);
  return ok({ success: true, exists: !!(row && !row.isDeleted), doctor: row ? mapDoctor(row) : null });
}

// ---- Services ----
export async function opListServices(): Promise<R> {
  const rows = await db.service.findMany({ where: { isDeleted: false, isActive: true }, orderBy: { createdAt: "desc" } });
  return ok({ success: true, services: rows.map(mapService) });
}
export async function opGetService(id: string): Promise<R> {
  const row = await db.service.findFirst({ where: { id, isDeleted: false } });
  if (!row) throw new ApiErr("الخدمة غير موجودة", 404);
  const visits = await db.visit.findMany({ where: { isDeleted: false, serviceId: id } });
  return ok({ success: true, service: { ...mapService(row), visitsCount: visits.length, totalRevenue: visits.reduce((s, v) => s + num(v.paidAmount), 0), doctors: [] } });
}
export async function opCreateService(b: any): Promise<R> {
  const name = typeof b?.name === "string" ? b.name.trim() : "";
  if (name.length < 2) throw new ApiErr("اسم الخدمة يجب أن يكون حرفين على الأقل");
  const price = num(b?.price);
  if (price < 0) throw new ApiErr("السعر لا يمكن أن يكون سالباً");
  const duration = num(b?.duration);
  if (!duration || duration < 5) throw new ApiErr("مدة الخدمة غير صحيحة");
  const created = await db.service.create({
    data: { name, avatar: b.avatar ?? null, price, duration, description: typeof b.description === "string" ? b.description.trim() : "" },
  });
  if (await shouldNotify("serviceCreated")) {
    await pushNotif("success", "service", "🦷 تم إضافة خدمة جديدة", `تمت إضافة خدمة ${created.name} بسعر ${created.price} ج.م.`, created.id);
  }
  await logActivity("service", "created", created.name, created.id, `تم إضافة خدمة ${created.name}`);
  await logReq("/api/services", "POST", 201);
  return ok({ success: true, message: "تم إضافة الخدمة بنجاح", service: mapService(created) }, 201);
}
export async function opUpdateService(id: string, b: any): Promise<R> {
  if (b.price !== undefined && num(b.price) < 0) throw new ApiErr("السعر لا يمكن أن يكون سالباً");
  const row = await db.service.update({
    where: { id },
    data: {
      ...(typeof b.name === "string" && { name: b.name.trim() }),
      ...(b.avatar !== undefined && { avatar: b.avatar }),
      ...(b.price != null && { price: num(b.price) }),
      ...(b.duration != null && { duration: num(b.duration) }),
      ...(typeof b.description === "string" && { description: b.description.trim() }),
      ...(b.isActive !== undefined && { isActive: b.isActive }),
    },
  });
  if (await shouldNotify("serviceUpdated")) {
    await pushNotif("info", "service", "🦷 تم تحديث خدمة", `تم تحديث خدمة ${row.name}.`, row.id);
  }
  await logActivity("service", "updated", row.name, row.id, `تم تحديث خدمة ${row.name}`);
  return ok({ success: true, message: "تم تحديث الخدمة", service: mapService(row) });
}
export async function opDeleteService(id: string): Promise<R> {
  const row = await db.service.update({ where: { id }, data: { isDeleted: true, isActive: false, deletedAt: new Date() } });
  if (await shouldNotify("serviceDeleted")) {
    await pushNotif("warning", "service", "🦷 تم حذف خدمة", `تم حذف خدمة ${row.name}.`, row.id);
  }
  await logActivity("service", "deleted", row.name, row.id, `تم حذف خدمة ${row.name}`);
  return ok({ success: true, message: "تم حذف الخدمة" });
}
export async function opCheckService(b: any): Promise<R> {
  let row: any = null;
  if (b?.id) row = await getServiceById(b.id);
  else if (b?.name) row = await findServiceByName(b.name);
  return ok({ success: true, exists: !!(row && !row.isDeleted), service: row ? mapService(row) : null });
}

// ---- Appointments ----
export async function opListAppointments(q: URLSearchParams): Promise<R> {
  const where: any = { isDeleted: false };
  if (q.get("date")) where.date = q.get("date")!;
  if (q.get("status")) where.status = q.get("status");
  if (q.get("doctor")) where.doctorId = q.get("doctor");
  const rows = await db.appointment.findMany({
    where, include: { patient: true, doctor: true, service: true },
    orderBy: [{ date: "desc" }, { time: "desc" }],
  });
  return ok({ success: true, appointments: rows.map(mapAppointment) });
}
export async function opGetAppointment(id: string): Promise<R> {
  const row = await db.appointment.findFirst({
    where: { id, isDeleted: false }, include: { patient: true, doctor: true, service: true },
  });
  if (!row) throw new ApiErr("الموعد غير موجود", 404);
  return ok({ success: true, appointment: mapAppointment(row) });
}
export async function opCheckAppointment(b: any): Promise<R> {
  let doctor = b?.doctorId ? await getDoctorById(b.doctorId) : null;
  if (!doctor && b?.doctorName) doctor = await findDoctorByName(b.doctorName);
  let service = b?.serviceId ? await getServiceById(b.serviceId) : null;
  if (!service && b?.serviceName) service = await findServiceByName(b.serviceName);
  if (!doctor) throw new ApiErr("الطبيب غير موجود");
  if (!service) throw new ApiErr("الخدمة غير متاحة حالياً");
  const res = await checkAvail(doctor.id, service.id, b.date, b.time);
  return ok({ success: true, available: res.available, message: res.message });
}
export async function opGetSlots(q: URLSearchParams): Promise<R> {
  const slots = await getSlots(q.get("doctorId") || "", q.get("serviceId") || "", q.get("date") || todayKey(), q.get("excludeId") || undefined);
  return ok({ success: true, slots });
}
export async function opCreateAppointment(b: any): Promise<R> {
  let doctor = (b?.doctorId ? await getDoctorById(b.doctorId) : null) || (b?.doctorName ? await findDoctorByName(b.doctorName) : null);
  if (!doctor || doctor.isDeleted) throw new ApiErr("الطبيب غير موجود");
  let service = (b?.serviceId ? await getServiceById(b.serviceId) : null) || (b?.serviceName ? await findServiceByName(b.serviceName) : null);
  if (!service || service.isDeleted) throw new ApiErr("الخدمة غير متاحة حالياً");

  let patient = (b?.patientId ? await db.patient.findFirst({ where: { id: b.patientId, isDeleted: false } }) : null)
    || (b?.phone ? await findPatientByPhone(b.phone) : null)
    || (b?.patientName ? await findPatientByName(b.patientName) : null);
  if (!patient) {
    const pname = typeof b?.patientName === "string" ? b.patientName.trim() : "";
    const pphone = typeof b?.phone === "string" ? b.phone.trim() : "";
    if (!pname || !pphone) throw new ApiErr("اسم المريض ورقم الهاتف مطلوبان");
    patient = await db.patient.create({ data: { name: pname, phone: pphone, age: 0, gender: "male", notes: "تم الإنشاء تلقائياً أثناء حجز موعد." } });
    if (await shouldNotify("patientCreated")) {
      await pushNotif("info", "patient", "👤 تم إنشاء ملف مريض", `تم إنشاء ملف ${patient.name} أثناء الحجز.`, patient.id);
    }
    await logActivity("patient", "created", patient.name, patient.id, `تم إنشاء ملف المريض ${patient.name} أثناء الحجز`);
  }

  if (!b?.date || !b?.time) throw new ApiErr("التاريخ والوقت مطلوبان");
  const avail = await checkAvail(doctor.id, service.id, b.date, b.time);
  if (!avail.available) throw new ApiErr(avail.message);

  const endTime = addMin(b.time, service.duration);
  const created = await db.appointment.create({
    data: { patientId: patient.id, doctorId: doctor.id, serviceId: service.id, date: b.date, time: b.time, endTime, status: "confirmed", notes: typeof b.notes === "string" ? b.notes.trim() : "" },
  });
  if (await shouldNotify("appointmentCreated")) {
    await pushNotif("success", "appointment", "📅 تم حجز موعد جديد", `موعد مع ${doctor.name} الساعة ${b.time}.`, created.id);
  }
  await logActivity("appointment", "created", patient.name, created.id, `تم حجز موعد للمريض ${patient.name} مع ${doctor.name}`);
  await logReq("/api/appointments", "POST", 201);
  return ok({ success: true, message: "تم حجز الموعد بنجاح", appointment: { ...mapAppointment(created), patientName: patient.name, doctorName: doctor.name, serviceName: service.name } }, 201);
}
export async function opUpdateAppointment(id: string, b: any): Promise<R> {
  const cur = await db.appointment.findFirst({ where: { id, isDeleted: false } });
  if (!cur) throw new ApiErr("الموعد غير موجود", 404);
  const doctorId = b.doctorId || cur.doctorId;
  const serviceId = b.serviceId || cur.serviceId;
  const date = b.date || cur.date;
  const time = b.time || cur.time;
  if (b.doctorId || b.serviceId || b.date || b.time) {
    const avail = await checkAvail(doctorId, serviceId, date, time, id);
    if (!avail.available) throw new ApiErr(avail.message);
  }
  const service = await getServiceById(serviceId);
  const endTime = addMin(time, service?.duration ?? 30);
  const row = await db.appointment.update({
    where: { id },
    data: { doctorId, serviceId, date, time, endTime, ...(b.status !== undefined && { status: b.status }), ...(typeof b.notes === "string" && { notes: b.notes.trim() }) },
  });
  if (await shouldNotify("appointmentUpdated")) {
    await pushNotif("info", "appointment", "📅 تم تعديل موعد", `تم تعديل موعد بتاريخ ${row.date}.`, row.id);
  }
  await logActivity("appointment", "updated", "", row.id, `تم تعديل موعد بتاريخ ${row.date} الساعة ${row.time}`);
  return ok({ success: true, message: "تم تعديل الموعد بنجاح", appointment: mapAppointment(row) });
}
export async function opCancelAppointment(id: string): Promise<R> {
  const row = await db.appointment.update({ where: { id }, data: { status: "cancelled" } });
  if (await shouldNotify("appointmentCancelled")) {
    await pushNotif("warning", "appointment", "📅 تم إلغاء موعد", `تم إلغاء موعد بتاريخ ${row.date}.`, row.id);
  }
  await logActivity("appointment", "cancelled", "", row.id, `تم إلغاء موعد بتاريخ ${row.date} الساعة ${row.time}`);
  return ok({ success: true, message: "تم إلغاء الموعد", appointment: mapAppointment(row) });
}
export async function opCompleteAppointment(id: string): Promise<R> {
  const appt = await db.appointment.findFirst({ where: { id, isDeleted: false } });
  if (!appt) throw new ApiErr("الموعد غير موجود", 404);
  const service = await getServiceById(appt.serviceId ?? "");
  await db.appointment.update({ where: { id }, data: { status: "completed" } });
  let visit = await db.visit.findFirst({ where: { appointmentId: id, isDeleted: false } });
  if (!visit) {
    visit = await db.visit.create({
      data: { patientId: appt.patientId ?? "", doctorId: appt.doctorId ?? "", serviceId: appt.serviceId ?? "",
        appointmentId: id, visitDate: appt.date, servicePrice: num(service?.price ?? 0),
        paidAmount: num(service?.price ?? 0), remainingAmount: 0, notes: appt.notes || "" },
    });
    if (await shouldNotify("visitAdded")) {
      await pushNotif("success", "visit", "🦷 تم تسجيل زيارة جديدة", "تم إكمال الموعد وتسجيل الزيارة.", visit.id);
    }
    await logActivity("visit", "created", "", visit.id, "تم تسجيل زيارة جديدة من إكمال موعد");
  }
  if (await shouldNotify("appointmentCompleted")) {
    await pushNotif("success", "appointment", "📅 تم إكمال موعد", `تم إكمال موعد بتاريخ ${appt.date}.`, appt.id);
  }
  await logActivity("appointment", "completed", "", appt.id, `تم إكمال موعد بتاريخ ${appt.date}`);
  return ok({ success: true, message: "تم إكمال الموعد وتسجيل الزيارة", appointment: mapAppointment(appt), visit: mapVisit(visit) });
}

// ---- Visits ----
export async function opListVisits(q: URLSearchParams): Promise<R> {
  const where: any = { isDeleted: false };
  if (q.get("doctor")) where.doctorId = q.get("doctor");
  if (q.get("service")) where.serviceId = q.get("service");
  const rows = await db.visit.findMany({ where, include: { patient: true, doctor: true, service: true }, orderBy: { visitDate: "desc" } });
  return ok({ success: true, visits: rows.map(mapVisit) });
}
export async function opGetVisit(id: string): Promise<R> {
  const row = await db.visit.findFirst({ where: { id, isDeleted: false }, include: { patient: true, doctor: true, service: true } });
  if (!row) throw new ApiErr("الزيارة غير موجودة", 404);
  return ok({ success: true, visit: mapVisit(row) });
}
export async function opCreateVisit(b: any): Promise<R> {
  let doctor = (b?.doctorId ? await getDoctorById(b.doctorId) : null) || (b?.doctorName ? await findDoctorByName(b.doctorName) : null);
  if (!doctor) throw new ApiErr("الطبيب غير موجود");
  let service = (b?.serviceId ? await getServiceById(b.serviceId) : null) || (b?.serviceName ? await findServiceByName(b.serviceName) : null);
  if (!service) throw new ApiErr("الخدمة غير متاحة حالياً");
  let patient = (b?.patientId ? await db.patient.findFirst({ where: { id: b.patientId, isDeleted: false } }) : null)
    || (b?.phone ? await findPatientByPhone(b.phone) : null)
    || (b?.patientName ? await findPatientByName(b.patientName) : null);
  if (!patient) {
    const pname = typeof b?.patientName === "string" ? b.patientName.trim() : "";
    const pphone = typeof b?.phone === "string" ? b.phone.trim() : "";
    if (!pname) throw new ApiErr("اسم المريض مطلوب");
    patient = await db.patient.create({ data: { name: pname, phone: pphone, age: 0, gender: "male", notes: "تم الإنشاء تلقائياً عند تسجيل زيارة." } });
  }
  if (!b?.visitDate) throw new ApiErr("تاريخ الزيارة مطلوب");
  const price = b.price != null ? num(b.price) : num(service.price);
  const paid = Math.min(b.paid != null ? num(b.paid) : 0, price);
  const created = await db.visit.create({
    data: { patientId: patient.id, doctorId: doctor.id, serviceId: service.id, visitDate: b.visitDate,
      servicePrice: price, paidAmount: paid, remainingAmount: price - paid,
      diagnosis: typeof b.diagnosis === "string" ? b.diagnosis.trim() : "",
      treatmentPlan: typeof b.treatmentPlan === "string" ? b.treatmentPlan.trim() : "",
      notes: typeof b.notes === "string" ? b.notes.trim() : "" },
  });
  if (await shouldNotify("visitAdded")) {
    await pushNotif("success", "visit", "🦷 تم تسجيل زيارة جديدة", `زيارة ${service.name} للمريض ${patient.name}.`, created.id);
  }
  await logActivity("visit", "created", patient.name, created.id, `تم تسجيل زيارة ${service.name} للمريض ${patient.name}`);
  await logReq("/api/visits", "POST", 201);
  return ok({ success: true, message: "تم تسجيل الزيارة بنجاح", visit: { ...mapVisit(created), patientName: patient.name, doctorName: doctor.name, serviceName: service.name } }, 201);
}
export async function opUpdateVisit(id: string, b: any): Promise<R> {
  const cur = await db.visit.findFirst({ where: { id, isDeleted: false } });
  if (!cur) throw new ApiErr("الزيارة غير موجودة", 404);
  const price = b.servicePrice != null ? num(b.servicePrice) : num(cur.servicePrice);
  const paid = b.paidAmount != null ? Math.min(num(b.paidAmount), price) : num(cur.paidAmount);
  const row = await db.visit.update({
    where: { id },
    data: { servicePrice: price, paidAmount: paid, remainingAmount: price - paid,
      ...(typeof b.diagnosis === "string" && { diagnosis: b.diagnosis.trim() }),
      ...(typeof b.treatmentPlan === "string" && { treatmentPlan: b.treatmentPlan.trim() }),
      ...(typeof b.notes === "string" && { notes: b.notes.trim() }) },
  });
  return ok({ success: true, message: "تم تحديث الزيارة", visit: mapVisit(row) });
}
export async function opDeleteVisit(id: string): Promise<R> {
  await db.visit.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date() } });
  return ok({ success: true, message: "تم حذف الزيارة" });
}
export async function opCheckVisit(b: any): Promise<R> {
  let row: any = null;
  if (b?.id) row = await db.visit.findFirst({ where: { id: b.id, isDeleted: false } });
  else if (b?.appointmentId) row = await db.visit.findFirst({ where: { appointmentId: b.appointmentId, isDeleted: false } });
  return ok({ success: true, exists: !!row, visit: row ? mapVisit(row) : null });
}

// ---- Reports ----
export async function opRevenue(period: string): Promise<R> {
  const bk = buckets(period);
  const visits = await db.visit.findMany({ where: { isDeleted: false } });
  const chart = bk.map((b) => ({ label: b.label, amount: visits.filter((v) => { const t = parseDateKey(v.visitDate).getTime(); return t >= b.startMs && t < b.endMs; }).reduce((s, v) => s + num(v.paidAmount), 0) }));
  const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const inRange = visits.filter((v) => { const t = parseDateKey(v.visitDate).getTime(); return t >= start && t < end; });
  const total = inRange.reduce((s, v) => s + num(v.paidAmount), 0);
  return ok({ success: true, period, totalRevenue: total, completedVisits: inRange.length, averageVisitValue: inRange.length ? total / inRange.length : 0, chart });
}
export async function opAppointmentsReport(period: string): Promise<R> {
  const bk = buckets(period);
  const apps = await db.appointment.findMany({ where: { isDeleted: false } });
  const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const inRange = apps.filter((a) => { const t = parseDateKey(a.date).getTime(); return t >= start && t < end; });
  const cnt = (s: string) => inRange.filter((a) => a.status === s).length;
  const chart = bk.map((b) => ({ label: b.label, count: apps.filter((a) => { const t = parseDateKey(a.date).getTime(); return t >= b.startMs && t < b.endMs; }).length }));
  return ok({ success: true, appointmentsCount: inRange.length, pending: cnt("pending"), confirmed: cnt("confirmed"), completed: cnt("completed"), cancelled: cnt("cancelled"), no_show: cnt("no_show"), chart });
}
export async function opPatientsReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const active = await db.patient.findMany({ where: { isDeleted: false } });
  const visits = await db.visit.findMany({ where: { isDeleted: false }, select: { patientId: true } });
  const visitCount: Record<string, number> = {};
  visits.forEach((v) => { visitCount[v.patientId] = (visitCount[v.patientId] || 0) + 1; });
  const newPatients = active.filter((p) => { const t = new Date(p.createdAt).getTime(); return t >= start && t < end; }).length;
  const returning = Object.values(visitCount).filter((c) => c >= 2).length;
  const chart = bk.map((b) => ({ label: b.label, count: active.filter((p) => { const t = new Date(p.createdAt).getTime(); return t >= b.startMs && t < b.endMs; }).length }));
  return ok({ success: true, totalPatients: active.length, newPatients, returningPatients: returning, chart });
}
export async function opDoctorsReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const doctors = await db.doctor.findMany({ where: { isDeleted: false, isActive: true } });
  const out = [];
  for (const d of doctors) {
    const dv = await db.visit.findMany({ where: { isDeleted: false, doctorId: d.id }, include: { service: true } });
    const inRange = dv.filter((v) => { const t = parseDateKey(v.visitDate).getTime(); return t >= start && t < end; });
    const svcCount: Record<string, number> = {};
    dv.forEach((v) => { if (v.service) svcCount[v.service.name] = (svcCount[v.service.name] || 0) + 1; });
    const topService = Object.entries(svcCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";
    out.push({ id: d.id, name: d.name, specialty: d.specialty, visits: inRange.length, revenue: inRange.reduce((s, v) => s + num(v.paidAmount), 0), patients: new Set(inRange.map((v) => v.patientId)).size, topService });
  }
  return ok({ success: true, doctors: out.filter((x) => x.visits > 0).sort((a, b) => b.visits - a.visits) });
}
export async function opServicesReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const services = await db.service.findMany({ where: { isDeleted: false, isActive: true } });
  const out = [];
  for (const s of services) {
    const sv = await db.visit.findMany({ where: { isDeleted: false, serviceId: s.id } });
    const inRange = sv.filter((v) => { const t = parseDateKey(v.visitDate).getTime(); return t >= start && t < end; });
    if (inRange.length) out.push({ name: s.name, count: inRange.length, revenue: inRange.reduce((sum, v) => sum + num(v.paidAmount), 0) });
  }
  return ok({ success: true, services: out.sort((a, b) => b.count - a.count) });
}

// ---- Notifications ----
export async function opListNotifications(): Promise<R> {
  const rows = await db.notification.findMany({ orderBy: { createdAt: "desc" }, take: 80 });
  return ok({ success: true, notifications: rows.map(mapNotification) });
}
export async function opMarkRead(id: string): Promise<R> {
  await db.notification.update({ where: { id }, data: { isRead: true } });
  return ok({ success: true, message: "تم التحديث" });
}
export async function opMarkAllRead(): Promise<R> {
  await db.notification.updateMany({ where: { isRead: false }, data: { isRead: true } });
  return ok({ success: true, message: "تم تعليم الكل كمقروء" });
}
export async function opClearNotifications(): Promise<R> {
  await db.notification.deleteMany({});
  return ok({ success: true, message: "تم مسح الإشعارات" });
}
export async function opDeleteNotification(id: string): Promise<R> {
  await db.notification.delete({ where: { id } });
  return ok({ success: true, message: "تم الحذف" });
}

// ---- Dashboard / logs / activity ----
export async function opDashboardStats(): Promise<R> {
  const today = todayKey();
  const p = await db.patient.count({ where: { isDeleted: false } });
  const d = await db.doctor.count({ where: { isDeleted: false, isActive: true } });
  const a = await db.appointment.count({ where: { isDeleted: false, date: today, status: { not: "cancelled" } } });
  const revVisits = await db.visit.findMany({ where: { isDeleted: false, visitDate: today } });
  const rev = revVisits.reduce((s, v) => s + num(v.paidAmount), 0);
  return ok({ success: true, stats: { patientsCount: p, doctorsCount: d, todayAppointments: a, todayRevenue: rev } });
}
export async function opGetLogs(): Promise<R> {
  const logs = await db.apiLog.findMany({ orderBy: { createdAt: "desc" }, take: 8 });
  const yesterday = new Date(Date.now() - 86400000);
  const today = await db.apiLog.count({ where: { createdAt: { gte: yesterday } } });
  return ok({ success: true, today, lastUsed: logs[0]?.createdAt ?? null, recent: logs.map((l) => ({ id: l.id, endpoint: l.endpoint ?? "", method: l.method ?? "", statusCode: l.statusCode ?? 0, responseTime: l.responseTime ?? 0, createdAt: l.createdAt })) });
}
export async function opListActivity(limit = 50): Promise<R> {
  const rows = await db.activityLog.findMany({ orderBy: { createdAt: "desc" }, take: limit });
  return ok({ success: true, activities: rows.map(mapActivityLog) });
}

// ---- Schema seed ----
export async function ensureSeed(): Promise<void> {
  // Ensure default auth accounts exist (hashed passwords in DB)
  try {
    const { ensureAccountsSeed } = await import("@/lib/auth");
    await ensureAccountsSeed();
  } catch { /* auth seed must never break app seed */ }

  const doctorCount = await db.doctor.count();
  if (doctorCount === 0) {
    const doctors = [
      { name: "د. كريم عبد الله", specialty: "تقويم الأسنان", workingDays: ["sunday","monday","tuesday","wednesday","thursday"], workingFrom: "10:00", workingTo: "18:00", phone: "01001112223", description: "استشاري تقويم الأسنان بخبرة تزيد عن 12 عاماً." },
      { name: "د. سارة محمود", specialty: "علاج الجذور وتجميل الأسنان", workingDays: ["saturday","sunday","monday","tuesday","wednesday"], workingFrom: "11:00", workingTo: "19:00", phone: "01002223334", description: "متخصصة في علاج الجذور والتجميل والابتسامة الهوليودية." },
      { name: "د. أحمد فؤاد", specialty: "جراحة الفم والأسنان", workingDays: ["sunday","tuesday","wednesday","thursday","friday"], workingFrom: "09:00", workingTo: "17:00", phone: "01003334445", description: "جراح فم وأسنان متخصص في الخلع المعقد وزراعة الأسنان." },
      { name: "د. منى حسن", specialty: "طب أسنان الأطفال", workingDays: ["saturday","monday","wednesday","thursday","friday"], workingFrom: "12:00", workingTo: "20:00", phone: "01004445556", description: "طبيبة أسنان أطفال تهتم برعاية صغار المرضى." },
      { name: "د. يوسف خالد", specialty: "تركيبات وزراعة الأسنان", workingDays: ["sunday","monday","wednesday","thursday","saturday"], workingFrom: "10:00", workingTo: "18:00", phone: "01005556667", description: "خبير التركيبات الثابتة والزرعات." },
    ];
    for (const d of doctors) {
      await db.doctor.create({ data: { ...d, workingDays: JSON.stringify(d.workingDays) } });
    }
  }
  const svcCount = await db.service.count();
  if (svcCount === 0) {
    const services = [
      { name: "كشف عام", price: 200, duration: 30, description: "فحص شامل للأسنان واللثة وتشخيص الحالة." },
      { name: "تنظيف الأسنان", price: 500, duration: 45, description: "إزالة الجير والتصبغات وتنظيف الأسنان احترافياً." },
      { name: "حشو الأسنان", price: 600, duration: 60, description: "علاج تسوس الأسنان وحشوها بمواد عالية الجودة." },
      { name: "تبييض الأسنان", price: 1500, duration: 90, description: "تبييض احترافي لإضفاء لون أكثر إشراقاً." },
      { name: "خلع الأسنان", price: 800, duration: 45, description: "خلع آمن للأسنان التالفة أو الضرس العقل." },
      { name: "علاج الجذور", price: 1200, duration: 90, description: "علاج عصب السن وحفظه من الاستخراج." },
      { name: "تركيبات وزراعة", price: 3500, duration: 120, description: "تركيبات وزراعة أسنان لتعويض الأسنان المفقودة." },
      { name: "تقويم الأسنان", price: 20000, duration: 90, description: "تقويم أسنان معدني وشفاف لتصحيح اصطفاف الأسنان." },
    ];
    for (const sv of services) {
      await db.service.create({ data: sv });
    }
  }
  const setCount = await db.settings.count();
  if (setCount === 0) {
    await db.settings.create({
      data: { id: 1, clinicName: "عيادة الابتسامة لطب الأسنان", clinicPhone: "0223456789",
        clinicAddress: "القاهرة - مدينة نصر، شارع مكرم عبيد", clinicEmail: "info@smile-clinic.com",
        doctorName: "د. كريم عبد الله", doctorSpecialty: "استشاري تقويم الأسنان",
        workingDays: JSON.stringify(["saturday","sunday","monday","tuesday","wednesday"]),
        workingFrom: "09:00", workingTo: "22:00",
        notificationTypes: JSON.stringify({ newAppointment: true, newPatient: true, visitAdded: true, appointmentReminder: true }),
        eventSettings: JSON.stringify({ patientCreated: true, patientUpdated: true, patientDeleted: true, appointmentCreated: true, appointmentUpdated: true, appointmentCancelled: true, appointmentCompleted: true, doctorCreated: true, doctorUpdated: true, doctorDeleted: true, serviceCreated: true, serviceUpdated: true, serviceDeleted: true, visitAdded: true }),
      },
    });
  }
}
