// Shared Next.js route handler helper — mirrors the original serve() pattern.
// Handles CORS, JSON parsing, error surfacing, and seed bootstrap.

import { NextRequest, NextResponse } from "next/server";
import { ApiErr, ensureSeed } from "@/lib/backend";

let seedDone = false;
export async function ensureSeedOnce() {
  if (seedDone) return;
  seedDone = true;
  try { await ensureSeed(); } catch (e) { seedDone = false; throw e; }
}

export type RouteHandler = (req: NextRequest, ctx: { params: Promise<Record<string, string>> }) => Promise<NextResponse>;

export function withCors(data: any, status = 200): NextResponse {
  const res = NextResponse.json(data, { status });
  res.headers.set("Access-Control-Allow-Origin", "*");
  res.headers.set("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  res.headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  return res;
}

export async function handleRoute(
  req: NextRequest,
  fn: () => Promise<{ status: number; data: any }>
): Promise<NextResponse> {
  if (req.method === "OPTIONS") return new NextResponse(null, { status: 204 });
  try {
    await ensureSeedOnce();
    const { status, data } = await fn();
    return withCors(data, status);
  } catch (e: any) {
    console.error("[api] request failed", { method: req.method, url: req.url, message: e?.message });
    const status = e?.status || 500;
    const message = e?.message || (typeof e === "string" ? e : "Database error");
    const payload: any = { success: false, message };
    if (process.env.NODE_ENV !== "production") payload.stack = e?.stack;
    return withCors(payload, status);
  }
}

export async function parseBody(req: NextRequest): Promise<any> {
  try {
    const text = await req.text();
    return text ? JSON.parse(text) : {};
  } catch {
    return {};
  }
}
