// Frontend API client — mirrors the original src/api/index.ts interface exactly
// so all existing pages work without modification. Uses TanStack Query for
// smart real-time cache invalidation.

import type {
  ApiLog, Appointment, AppointmentStatus, ChartPoint, Doctor, Patient,
  PatientSearchResult, ReportPeriod, Service, Settings, Visit, AppNotification,
  ActivityLog,
} from "@/types";

export class ApiError extends Error {
  constructor(message: string) { super(message); this.name = "ApiError"; }
}

interface PatientStats {
  visitsCount: number; lastVisit: string | null; totalPaid: number;
  remainingBalance: number; upcomingAppointments: number;
}
interface DoctorStats {
  patientsCount: number; appointmentsCount: number; completedVisits: number;
  totalRevenue: number; averageVisitValue: number; topService: string; monthlyVisits: ChartPoint[];
}
interface ServiceStats { visitsCount: number; totalRevenue: number; doctorIds: string[]; }
interface AvailabilityInput { doctorId: string; serviceId: string; date: string; time: string; excludeId?: string; }
interface AvailabilityResult { available: boolean; message: string; }

async function request<T = any>(path: string, method: string, body?: any): Promise<T> {
  // Automatically include the auth token for protected endpoints
  const token = typeof window !== "undefined" ? (() => {
    try {
      const raw = localStorage.getItem("dental_auth_session");
      return raw ? JSON.parse(raw)?.token : null;
    } catch { return null; }
  })() : null;

  let res: Response;
  try {
    const headers: Record<string, string> = {};
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (token) headers["Authorization"] = `Bearer ${token}`;
    res = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت.");
  }
  let data: any = null;
  try { data = await res.json(); } catch { throw new ApiError(`خطأ غير متوقع من الخادم (${res.status})`); }
  if (!res.ok || data?.success === false) {
    throw new ApiError(data?.message || `حدث خطأ (${res.status})`);
  }
  return data as T;
}

function qs(params: Record<string, string | number | undefined | null>): string {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

export const api = {
  // ---- Auth ----
  login(email: string, password: string): Promise<{ user: { email: string; role: string; name: string }; token: string }> {
    return request("/api/auth/login", "POST", { email, password });
  },

  // ---- Account management (owner-only) ----
  getAccounts(): Promise<{ id: string; email: string; role: string; name: string }[]> {
    return request<{ accounts: any[] }>("/api/auth/accounts", "GET").then((r) => r.accounts);
  },
  updateAccount(role: string, data: { email?: string; newPassword?: string; confirmPassword?: string }): Promise<void> {
    return request("/api/auth/accounts", "POST", { role, ...data }).then(() => undefined);
  },

  // ---- Health / Settings ----
  health(): Promise<{ status: string; database: string; api: string }> {
    return request("/api/health", "GET");
  },
  getSettings(): Promise<Settings> {
    return request<{ settings: Settings }>("/api/settings", "GET").then((r) => r.settings);
  },
  updateSettings(patch: Partial<Settings>): Promise<Settings> {
    return request<{ settings: Settings }>("/api/settings", "POST", patch).then((r) => r.settings);
  },

  // ---- Patients ----
  getPatients(): Promise<Patient[]> {
    return request<{ patients: Patient[] }>("/api/patients", "GET").then((r) => r.patients);
  },
  searchPatients(query: { phone?: string; name?: string }): Promise<Patient | null> {
    return request<{ patient: Patient | null }>(`/api/patients/search${qs({ phone: query.phone, name: query.name })}`, "GET").then((r) => r.patient);
  },
  searchPatientsAdvanced(query: string, limit = 8): Promise<PatientSearchResult[]> {
    return request<{ patients: PatientSearchResult[] }>(`/api/patients/search${qs({ q: query })}`, "GET").then((r) => r.patients.slice(0, limit));
  },
  getPatient(id: string): Promise<Patient & PatientStats & { visits: Visit[] }> {
    return request<{ patient: Patient & PatientStats & { visits: Visit[] } }>(`/api/patients/${id}`, "GET").then((r) => r.patient);
  },
  createPatient(input: { name: string; phone: string; age: number; gender: Patient["gender"]; address?: string; notes?: string }): Promise<Patient> {
    return request<{ patient: Patient }>("/api/patients", "POST", input).then((r) => r.patient);
  },
  updatePatient(id: string, patch: Partial<Patient>): Promise<Patient> {
    return request<{ patient: Patient }>("/api/patients/update", "POST", { id, ...patch }).then((r) => r.patient);
  },
  deletePatient(id: string): Promise<{ id: string }> {
    return request("/api/patients/delete", "POST", { id }).then(() => ({ id }));
  },
  checkPatient(query: { id?: string; phone?: string; name?: string }): Promise<{ exists: boolean; patient: Patient | null }> {
    return request("/api/patients/check", "POST", query);
  },
  getPatientVisits(patientId: string): Promise<Visit[]> {
    return request<{ visits: Visit[] }>(`/api/patients/${patientId}/visits`, "GET").then((r) => r.visits);
  },

  // ---- Doctors ----
  getDoctors(): Promise<Doctor[]> {
    return request<{ doctors: Doctor[] }>("/api/doctors", "GET").then((r) => r.doctors);
  },
  getDoctor(id: string): Promise<Doctor & DoctorStats> {
    return request<{ doctor: Doctor & DoctorStats }>(`/api/doctors/${id}`, "GET").then((r) => r.doctor);
  },
  createDoctor(input: { name: string; specialty: string; phone?: string; description?: string; workingDays: Doctor["workingDays"]; workingFrom: string; workingTo: string; image?: string }): Promise<Doctor> {
    return request<{ doctor: Doctor }>("/api/doctors", "POST", input).then((r) => r.doctor);
  },
  updateDoctor(id: string, patch: Partial<Doctor>): Promise<Doctor> {
    return request<{ doctor: Doctor }>("/api/doctors/update", "POST", { id, ...patch }).then((r) => r.doctor);
  },
  deleteDoctor(id: string): Promise<{ id: string }> {
    return request("/api/doctors/delete", "POST", { id }).then(() => ({ id }));
  },
  checkDoctor(query: { id?: string; name?: string }): Promise<{ exists: boolean; doctor: Doctor | null }> {
    return request("/api/doctors/check", "POST", query);
  },

  // ---- Services ----
  getServices(): Promise<Service[]> {
    return request<{ services: Service[] }>("/api/services", "GET").then((r) => r.services);
  },
  getService(id: string): Promise<Service & ServiceStats> {
    return request<{ service: Service & ServiceStats }>(`/api/services/${id}`, "GET").then((r) => r.service);
  },
  createService(input: { name: string; price: number; duration: number; description?: string }): Promise<Service> {
    return request<{ service: Service }>("/api/services", "POST", input).then((r) => r.service);
  },
  updateService(id: string, patch: Partial<Service>): Promise<Service> {
    return request<{ service: Service }>("/api/services/update", "POST", { id, ...patch }).then((r) => r.service);
  },
  deleteService(id: string): Promise<{ id: string }> {
    return request("/api/services/delete", "POST", { id }).then(() => ({ id }));
  },
  checkService(query: { id?: string; name?: string }): Promise<{ exists: boolean; service: Service | null }> {
    return request("/api/services/check", "POST", query);
  },

  // ---- Appointments ----
  getAppointments(): Promise<Appointment[]> {
    return request<{ appointments: Appointment[] }>("/api/appointments", "GET").then((r) => r.appointments);
  },
  getSlots(input: Omit<AvailabilityInput, "time">): Promise<string[]> {
    return request<{ slots: string[] }>(`/api/appointments/slots${qs({ doctorId: input.doctorId, serviceId: input.serviceId, date: input.date, excludeId: input.excludeId })}`, "GET").then((r) => r.slots);
  },
  checkAvailability(input: AvailabilityInput): Promise<AvailabilityResult> {
    return request<AvailabilityResult>("/api/appointments/check", "POST", input);
  },
  createAppointment(input: { patientName: string; phone: string; doctorName: string; serviceName: string; date: string; time: string; notes?: string; patientId?: string }): Promise<Appointment> {
    return request<{ appointment: Appointment }>("/api/appointments", "POST", input).then((r) => r.appointment);
  },
  updateAppointment(id: string, input: { doctorId?: string; serviceId?: string; date?: string; time?: string; notes?: string; status?: AppointmentStatus }): Promise<Appointment> {
    return request<{ appointment: Appointment }>("/api/appointments/update", "POST", { id, ...input }).then((r) => r.appointment);
  },
  cancelAppointment(id: string): Promise<Appointment> {
    return request<{ appointment: Appointment }>("/api/appointments/delete", "POST", { id }).then((r) => r.appointment);
  },
  completeAppointment(id: string): Promise<{ appointment: Appointment; visit: Visit }> {
    return request("/api/appointments/complete", "POST", { id });
  },

  // ---- Visits ----
  getVisits(): Promise<Visit[]> {
    return request<{ visits: Visit[] }>("/api/visits", "GET").then((r) => r.visits);
  },
  createVisit(input: { patientName: string; phone?: string; doctorName: string; serviceName: string; visitDate: string; price: number; paid: number; diagnosis?: string; treatmentPlan?: string; notes?: string; patientId?: string }): Promise<Visit> {
    return request<{ visit: Visit }>("/api/visits", "POST", input).then((r) => r.visit);
  },
  updateVisit(id: string, patch: Partial<Visit>): Promise<Visit> {
    return request<{ visit: Visit }>("/api/visits/update", "POST", { id, ...patch }).then((r) => r.visit);
  },
  deleteVisit(id: string): Promise<{ id: string }> {
    return request("/api/visits/delete", "POST", { id }).then(() => ({ id }));
  },
  checkVisit(query: { id?: string; appointmentId?: string }): Promise<{ exists: boolean; visit: Visit | null }> {
    return request("/api/visits/check", "POST", query);
  },

  // ---- Notifications ----
  getNotifications(): Promise<AppNotification[]> {
    return request<{ notifications: AppNotification[] }>("/api/notifications", "GET").then((r) => r.notifications);
  },
  markNotificationRead(id: string): Promise<void> {
    return request("/api/notifications/read", "POST", { id }).then(() => undefined);
  },
  markAllNotificationsRead(): Promise<void> {
    return request("/api/notifications/read-all", "POST").then(() => undefined);
  },
  clearNotifications(): Promise<void> {
    return request("/api/notifications/clear", "POST").then(() => undefined);
  },

  // ---- Dashboard ----
  getDashboardStats(): Promise<{ patientsCount: number; doctorsCount: number; todayAppointments: number; todayRevenue: number }> {
    return request<{ stats: any }>("/api/dashboard/stats", "GET").then((r) => r.stats);
  },
  getApiLogs(): Promise<{ today: number; lastUsed: string | null; recent: ApiLog[] }> {
    return request("/api/logs", "GET");
  },

  // ---- Activity (new — for owner area) ----
  getActivity(limit = 50): Promise<ActivityLog[]> {
    return request<{ activities: ActivityLog[] }>(`/api/activity${qs({ limit })}`, "GET").then((r) => r.activities);
  },

  // ---- Reports ----
  revenueReport(period: ReportPeriod): Promise<{ totalRevenue: number; averageVisitValue: number; completedVisits: number; chart: ChartPoint[] }> {
    return request(`/api/reports/revenue${qs({ period })}`, "GET");
  },
  appointmentsReport(period: ReportPeriod): Promise<{ appointmentsCount: number; pending: number; confirmed: number; completed: number; cancelled: number; no_show: number; chart: ChartPoint[] }> {
    return request(`/api/reports/appointments${qs({ period })}`, "GET");
  },
  patientsReport(period: ReportPeriod): Promise<{ totalPatients: number; newPatients: number; returningPatients: number; chart: ChartPoint[] }> {
    return request(`/api/reports/patients${qs({ period })}`, "GET");
  },
  doctorsReport(period: ReportPeriod): Promise<{ id: string; name: string; specialty: string; visits: number; revenue: number; patients: number; topService: string }[]> {
    return request<{ doctors: any[] }>(`/api/reports/doctors${qs({ period })}`, "GET").then((r) => r.doctors);
  },
  servicesReport(period: ReportPeriod): Promise<{ name: string; count: number; revenue: number }[]> {
    return request<{ services: any[] }>(`/api/reports/services${qs({ period })}`, "GET").then((r) => r.services);
  },
};
