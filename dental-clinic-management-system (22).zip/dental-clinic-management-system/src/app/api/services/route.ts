import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opListServices, opCreateService } from "@/lib/backend";

export async function GET(req: NextRequest) {
  return handleRoute(req, opListServices);
}
export async function POST(req: NextRequest) {
  const body = await parseBody(req);
  return handleRoute(req, () => opCreateService(body));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
