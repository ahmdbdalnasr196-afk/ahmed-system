import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import {
  opCheckAppointment, opGetSlots, opUpdateAppointment,
  opCancelAppointment, opCompleteAppointment, opGetAppointment,
} from "@/lib/backend";

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const q = new URL(req.url).searchParams;
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "slots") return opGetSlots(q);
    if (slug.length === 1) return opGetAppointment(slug[0]);
    throw new Error("Not found");
  });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const body = await parseBody(req);
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "check") return opCheckAppointment(body);
    if (action === "update") return opUpdateAppointment(body?.id, body);
    if (action === "delete" || action === "cancel") return opCancelAppointment(body?.id);
    if (action === "complete") return opCompleteAppointment(body?.id);
    throw new Error("Not found");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
