import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opListAppointments, opCreateAppointment } from "@/lib/backend";

export async function GET(req: NextRequest) {
  const q = new URL(req.url).searchParams;
  return handleRoute(req, () => opListAppointments(q));
}
export async function POST(req: NextRequest) {
  const body = await parseBody(req);
  return handleRoute(req, () => opCreateAppointment(body));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
