import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opCheckDoctor, opUpdateDoctor, opDeleteDoctor, opGetDoctor } from "@/lib/backend";

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  return handleRoute(req, () => {
    if (slug.length === 1) return opGetDoctor(slug[0]);
    throw new Error("Not found");
  });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const body = await parseBody(req);
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "check") return opCheckDoctor(body);
    if (action === "update") return opUpdateDoctor(body?.id, body);
    if (action === "delete") return opDeleteDoctor(body?.id);
    throw new Error("Not found");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
