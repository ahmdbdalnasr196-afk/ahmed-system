import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import { opListActivity } from "@/lib/backend";

// /api/activity — new endpoint for the owner Activity section
export async function GET(req: NextRequest) {
  const q = new URL(req.url).searchParams;
  const limit = parseInt(q.get("limit") || "50", 10);
  return handleRoute(req, () => opListActivity(limit));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
