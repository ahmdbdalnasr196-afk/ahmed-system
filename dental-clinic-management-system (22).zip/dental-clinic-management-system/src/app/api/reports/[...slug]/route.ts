import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import {
  opRevenue, opAppointmentsReport, opPatientsReport, opDoctorsReport, opServicesReport,
} from "@/lib/backend";

// /api/reports/:type?period=
export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const q = new URL(req.url).searchParams;
  const type = slug[0];
  const period = q.get("period") || "month";
  return handleRoute(req, () => {
    if (type === "revenue") return opRevenue(period);
    if (type === "appointments") return opAppointmentsReport(period);
    if (type === "patients") return opPatientsReport(period);
    if (type === "doctors") return opDoctorsReport(period);
    if (type === "services") return opServicesReport(period);
    throw new Error("نوع تقرير غير معروف");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
