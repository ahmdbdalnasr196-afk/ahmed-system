import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import { opGetLogs } from "@/lib/backend";

// /api/logs — alias for /api/dashboard/logs (backward compatible)
export async function GET(req: NextRequest) {
  return handleRoute(req, opGetLogs);
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
