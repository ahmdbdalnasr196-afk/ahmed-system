import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opGetSettings, opUpdateSettings } from "@/lib/backend";

export async function GET(req: NextRequest) {
  return handleRoute(req, opGetSettings);
}
export async function POST(req: NextRequest) {
  const body = await parseBody(req);
  return handleRoute(req, () => opUpdateSettings(body));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
