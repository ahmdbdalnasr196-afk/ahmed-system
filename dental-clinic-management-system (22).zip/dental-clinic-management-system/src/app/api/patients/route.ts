import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opListPatients, opCreatePatient } from "@/lib/backend";

export async function GET(req: NextRequest) {
  return handleRoute(req, opListPatients);
}
export async function POST(req: NextRequest) {
  const body = await parseBody(req);
  return handleRoute(req, () => opCreatePatient(body));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
