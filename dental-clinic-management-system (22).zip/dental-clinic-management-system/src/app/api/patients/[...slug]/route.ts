import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import {
  opSearchPatients, opCheckPatient, opUpdatePatient, opDeletePatient,
  opGetPatientVisits, opGetPatient,
} from "@/lib/backend";

// Handles all /api/patients/* paths:
//   /api/patients/search          → opSearchPatients
//   /api/patients/check           → opCheckPatient
//   /api/patients/update          → opUpdatePatient
//   /api/patients/delete          → opDeletePatient
//   /api/patients/:id/visits      → opGetPatientVisits
//   /api/patients/:id             → opGetPatient
export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const q = new URL(req.url).searchParams;
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "search") return opSearchPatients(q);
    if (slug.length === 2 && slug[1] === "visits") return opGetPatientVisits(slug[0]);
    if (slug.length === 1) return opGetPatient(slug[0]);
    throw new Error("Not found");
  });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const body = await parseBody(req);
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "check") return opCheckPatient(body);
    if (action === "update") return opUpdatePatient(body?.id, body);
    if (action === "delete") return opDeletePatient(body?.id);
    throw new Error("Not found");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
