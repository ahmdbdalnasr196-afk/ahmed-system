import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import { opDashboardStats, opGetLogs } from "@/lib/backend";

// /api/dashboard/stats or /api/dashboard/logs
export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  return handleRoute(req, () => {
    const type = slug[0];
    if (type === "stats") return opDashboardStats();
    if (type === "logs") return opGetLogs();
    throw new Error("نوع لوحة غير معروف");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
