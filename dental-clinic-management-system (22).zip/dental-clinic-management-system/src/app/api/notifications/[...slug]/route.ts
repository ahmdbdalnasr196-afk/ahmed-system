import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opMarkRead, opMarkAllRead, opClearNotifications, opDeleteNotification } from "@/lib/backend";

// /api/notifications/read-all, /read, /clear, /delete
export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const body = await parseBody(req);
  const q = new URL(req.url).searchParams;
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "read-all") return opMarkAllRead();
    if (action === "read") return opMarkRead(body?.id || q.get("id") || "");
    if (action === "clear") return opClearNotifications();
    if (action === "delete") return opDeleteNotification(body?.id);
    throw new Error("Not found");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
