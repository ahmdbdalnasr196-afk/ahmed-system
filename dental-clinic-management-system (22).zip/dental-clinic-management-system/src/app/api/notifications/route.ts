import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import { opListNotifications } from "@/lib/backend";

export async function GET(req: NextRequest) {
  return handleRoute(req, opListNotifications);
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
