import { NextRequest } from "next/server";
import { handleRoute } from "@/lib/route-helpers";
import { opHealth } from "@/lib/backend";

export async function GET(req: NextRequest) {
  return handleRoute(req, opHealth);
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
