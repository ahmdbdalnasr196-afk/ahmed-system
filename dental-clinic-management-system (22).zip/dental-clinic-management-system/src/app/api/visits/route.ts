import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opListVisits, opCreateVisit } from "@/lib/backend";

export async function GET(req: NextRequest) {
  const q = new URL(req.url).searchParams;
  return handleRoute(req, () => opListVisits(q));
}
export async function POST(req: NextRequest) {
  const body = await parseBody(req);
  return handleRoute(req, () => opCreateVisit(body));
}
export async function OPTIONS() { return new Response(null, { status: 204 }); }
