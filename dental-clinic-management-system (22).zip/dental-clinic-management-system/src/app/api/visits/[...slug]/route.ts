import { NextRequest } from "next/server";
import { handleRoute, parseBody } from "@/lib/route-helpers";
import { opCheckVisit, opUpdateVisit, opDeleteVisit, opGetVisit } from "@/lib/backend";

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  return handleRoute(req, () => {
    if (slug.length === 1) return opGetVisit(slug[0]);
    throw new Error("Not found");
  });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await ctx.params;
  const body = await parseBody(req);
  return handleRoute(req, () => {
    const action = slug[0];
    if (action === "check") return opCheckVisit(body);
    if (action === "update") return opUpdateVisit(body?.id, body);
    if (action === "delete") return opDeleteVisit(body?.id);
    throw new Error("Not found");
  });
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
