import { NextRequest, NextResponse } from "next/server";
import { listAccounts, updateAccountEmail, updateAccountPassword, ensureAccountsSeed, parseSessionToken } from "@/lib/auth";
import type { UserRole } from "@/types";

// Authorization helper — only the owner can manage accounts.
// Checks the session token from the Authorization header.
function requireOwner(req: NextRequest): { authorized: boolean; response?: NextResponse } {
  const authHeader = req.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) {
    return { authorized: false, response: NextResponse.json({ success: false, message: "غير مصرح — تسجيل الدخول مطلوب" }, { status: 401 }) };
  }
  const user = parseSessionToken(token);
  if (!user || user.role !== "owner") {
    return { authorized: false, response: NextResponse.json({ success: false, message: "غير مصرح — هذه الميزة متاحة لمالك العيادة فقط" }, { status: 403 }) };
  }
  return { authorized: true };
}

// GET /api/auth/accounts — list accounts (email + role only, NO passwords)
export async function GET(req: NextRequest) {
  const auth = requireOwner(req);
  if (!auth.authorized) return auth.response!;
  try {
    await ensureAccountsSeed();
    const accounts = await listAccounts();
    return NextResponse.json({ success: true, accounts });
  } catch {
    return NextResponse.json({ success: false, message: "تعذر جلب الحسابات" }, { status: 500 });
  }
}

// POST /api/auth/accounts — update email and/or password for a specific role
// Body: { role: "admin" | "owner", email?: string, newPassword?: string }
export async function POST(req: NextRequest) {
  const auth = requireOwner(req);
  if (!auth.authorized) return auth.response!;
  try {
    const body = await req.json();
    const role = body.role as UserRole;
    if (role !== "admin" && role !== "owner") {
      return NextResponse.json({ success: false, message: "نوع الحساب غير صالح" }, { status: 400 });
    }

    // Update email if provided
    if (typeof body.email === "string" && body.email.trim()) {
      const email = body.email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return NextResponse.json({ success: false, message: "صيغة البريد الإلكتروني غير صحيحة" }, { status: 400 });
      }
      try {
        await updateAccountEmail(role, email);
      } catch (e: any) {
        return NextResponse.json({ success: false, message: e?.message || "تعذر تحديث البريد الإلكتروني" }, { status: 400 });
      }
    }

    // Update password if provided
    if (typeof body.newPassword === "string" && body.newPassword) {
      if (body.newPassword !== body.confirmPassword) {
        return NextResponse.json({ success: false, message: "كلمتا المرور غير متطابقتين" }, { status: 400 });
      }
      if (body.newPassword.length < 6) {
        return NextResponse.json({ success: false, message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }, { status: 400 });
      }
      try {
        await updateAccountPassword(role, body.newPassword);
      } catch (e: any) {
        return NextResponse.json({ success: false, message: e?.message || "تعذر تحديث كلمة المرور" }, { status: 400 });
      }
    }

    return NextResponse.json({ success: true, message: "تم تحديث بيانات الحساب بنجاح" });
  } catch {
    return NextResponse.json({ success: false, message: "حدث خطأ أثناء التحديث" }, { status: 500 });
  }
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
