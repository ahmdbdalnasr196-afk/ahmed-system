import { NextRequest, NextResponse } from "next/server";
import { validateCredentials, createSessionToken, ensureAccountsSeed } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    // Ensure default accounts exist (seeded with hashed passwords on first run)
    await ensureAccountsSeed();
    const { email, password } = await req.json();
    if (!email || !password) {
      return NextResponse.json({ success: false, message: "البريد الإلكتروني وكلمة المرور مطلوبان" }, { status: 400 });
    }
    const user = await validateCredentials(email, password);
    if (!user) {
      return NextResponse.json({ success: false, message: "بيانات الدخول غير صحيحة" }, { status: 401 });
    }
    const token = createSessionToken(user);
    return NextResponse.json({ success: true, user, token });
  } catch (e: any) {
    console.error("[auth/login] error:", e?.message, e?.stack);
    return NextResponse.json({ success: false, message: "حدث خطأ أثناء تسجيل الدخول" }, { status: 500 });
  }
}

export async function OPTIONS() { return new Response(null, { status: 204 }); }
