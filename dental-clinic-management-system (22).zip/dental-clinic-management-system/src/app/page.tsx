'use client';

// =============================================================================
// Entry page — auth-aware router.
//
// Renders LoginPage until the user signs in, then mounts AdminApp or OwnerApp
// based on the authenticated user's role. Both apps internally wrap their
// own AppProvider + HashRouter, so this page only needs to provide AuthProvider
// and pick the right shell.
// =============================================================================

import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import LoginPage from "@/components/LoginPage";
import AdminApp from "@/components/AdminApp";
import OwnerApp from "@/components/OwnerApp";

function Gate() {
  const { user, loading, isAdmin, isOwner } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-100 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-3 text-slate-500">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
          <p className="text-sm font-semibold">جارٍ التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;
  if (isOwner) return <OwnerApp />;
  return <AdminApp />;
}

export default function Home() {
  return (
    <AuthProvider>
      <Gate />
    </AuthProvider>
  );
}
