"use client";

import { useState, type FormEvent } from "react";
import {
  Activity,
  AlertCircle,
  CalendarClock,
  Eye,
  EyeOff,
  Lock,
  LogIn,
  Mail,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { ApiError } from "@/lib/api";
import { Button, Field, Input } from "@/components/ui";

interface Feature {
  icon: typeof ShieldCheck;
  title: string;
  desc: string;
}

const FEATURES: Feature[] = [
  { icon: ShieldCheck, title: "إدارة آمنة للمرضى", desc: "حفظ كامل لملفات المرضى وتاريخهم الطبي" },
  { icon: CalendarClock, title: "حجز المواعيد بسهولة", desc: "نظام مواعيد ذكي يمنع التعارض تلقائيًا" },
  { icon: Activity, title: "تقارير وإحصائيات فورية", desc: "تابع أداء العيادة لحظة بلحظة" },
];

export default function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [touched, setTouched] = useState({ email: false, password: false });

  const emailError = touched.email && !email.trim() ? "البريد الإلكتروني مطلوب" : "";
  const passwordError = touched.password && !password ? "كلمة المرور مطلوبة" : "";

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setTouched({ email: true, password: true });
    if (!email.trim() || !password) return;
    setLoading(true);
    try {
      await login(email.trim(), password);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "بيانات الدخول غير صحيحة");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen w-full bg-slate-100 dark:bg-slate-950">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col lg:flex-row">
        {/* ---- Branding panel ---- */}
        <aside className="relative overflow-hidden bg-gradient-to-br from-brand-600 via-brand-700 to-brand-900 px-7 py-9 text-white lg:w-1/2 lg:px-14 lg:py-16">
          {/* Decorative blurred shapes */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
            <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute -left-16 bottom-0 h-80 w-80 rounded-full bg-brand-300/20 blur-3xl" />
            <div className="absolute left-1/4 top-1/3 h-40 w-40 rounded-full bg-white/5 blur-2xl" />
            <div className="absolute right-1/3 bottom-1/4 h-32 w-32 rounded-full border border-white/10" />
          </div>

          <div className="relative flex h-full flex-col animate-slide-up">
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-3xl shadow-lg ring-1 ring-white/20 backdrop-blur">
                🦷
              </div>
              <div>
                <p className="text-base font-extrabold leading-tight sm:text-lg">
                  نظام إدارة عيادة الأسنان
                </p>
                <p className="text-[11px] text-white/70 sm:text-xs">
                  Dental Clinic Management System
                </p>
              </div>
            </div>

            <div className="mt-auto hidden lg:block">
              <h1 className="text-4xl font-extrabold leading-snug">
                أهلًا بك من جديد 👋
              </h1>
              <p className="mt-3 max-w-md text-white/80">
                سجّل الدخول لإدارة المرضى والمواعيد والزيارات والتقارير من مكان واحد متكامل.
              </p>
              <ul className="mt-8 space-y-4">
                {FEATURES.map((f) => (
                  <li key={f.title} className="flex items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/15">
                      <f.icon className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-bold">{f.title}</p>
                      <p className="text-sm text-white/70">{f.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <p className="mt-10 text-xs text-white/60 lg:mt-16">
              © {new Date().getFullYear()} عيادة الأسنان. جميع الحقوق محفوظة.
            </p>
          </div>
        </aside>

        {/* ---- Form panel ---- */}
        <main className="flex flex-1 items-center justify-center px-5 py-10 sm:px-8 lg:py-16">
          <div className="w-full max-w-md animate-slide-up">
            {/* Mobile-only compact logo */}
            <div className="mb-8 flex flex-col items-center text-center lg:hidden">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-3xl shadow-lg shadow-brand-600/30">
                🦷
              </div>
              <h1 className="text-xl font-extrabold text-slate-800 dark:text-white">
                نظام إدارة عيادة الأسنان
              </h1>
              <p className="mt-1 text-sm text-slate-400">سجّل الدخول للمتابعة</p>
            </div>

            <div className="hidden lg:block">
              <h2 className="text-2xl font-extrabold text-slate-800 dark:text-white">
                تسجيل الدخول
              </h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                أدخل بياناتك للوصول إلى لوحة التحكم
              </p>
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-3 text-sm font-semibold text-rose-700 animate-fade-in dark:border-rose-900/50 dark:bg-rose-950/40 dark:text-rose-300"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <Field label="البريد الإلكتروني" required error={emailError}>
                <div className="relative">
                  <Mail className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    placeholder="you@clinic.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                    className="pr-10"
                    aria-label="البريد الإلكتروني"
                  />
                </div>
              </Field>

              <Field label="كلمة المرور" required error={passwordError}>
                <div className="relative">
                  <Lock className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onBlur={() => setTouched((t) => ({ ...t, password: true }))}
                    className="px-10"
                    aria-label="كلمة المرور"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    tabIndex={-1}
                    className="absolute left-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-700"
                    aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </Field>

              <Button
                type="submit"
                size="lg"
                loading={loading}
                className="w-full"
              >
                {!loading && <LogIn className="h-4 w-4" />}
                تسجيل الدخول
              </Button>
            </form>

            {/* Download project source code */}
            <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3 text-center dark:border-slate-700 dark:bg-slate-800/50">
              <a
                href="/dental-clinic-management-system.zip"
                download
                className="inline-flex items-center gap-2 text-sm font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
              >
                📥 تحميل ملفات المشروع (ZIP)
              </a>
              <p className="mt-1 text-[11px] text-slate-400">326 KB — النسخة المصلحة الجاهزة للنشر على Vercel</p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
