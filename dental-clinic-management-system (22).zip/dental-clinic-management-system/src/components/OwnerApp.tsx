"use client";

import { lazy, Suspense } from "react";
import { HashRouter, Route, Routes } from "react-router-dom";
import { AppProvider, useApp } from "@/contexts/AppContext";
import OwnerLayout from "@/owner-pages/OwnerLayout";
import { Spinner } from "@/components/ui";

// Lazy-loaded owner pages.
const Overview = lazy(() => import("@/owner-pages/Overview"));
const OwnerAppointments = lazy(() => import("@/owner-pages/OwnerAppointments"));
const OwnerPatients = lazy(() => import("@/owner-pages/OwnerPatients"));
const OwnerDoctors = lazy(() => import("@/owner-pages/OwnerDoctors"));
const OwnerServices = lazy(() => import("@/owner-pages/OwnerServices"));
const Analytics = lazy(() => import("@/owner-pages/Analytics"));
const Activity = lazy(() => import("@/owner-pages/Activity"));
const OwnerSettings = lazy(() => import("@/owner-pages/OwnerSettings"));

function Fallback() {
  return (
    <div className="flex h-[60vh] items-center justify-center">
      <Spinner className="h-8 w-8 text-brand-500" />
    </div>
  );
}

function AppRoutes() {
  const { loading } = useApp();
  if (loading) return <Fallback />;
  return (
    <Suspense fallback={<Fallback />}>
      <Routes>
        <Route element={<OwnerLayout />}>
          <Route path="/" element={<Overview />} />
          <Route path="/appointments" element={<OwnerAppointments />} />
          <Route path="/patients" element={<OwnerPatients />} />
          <Route path="/doctors" element={<OwnerDoctors />} />
          <Route path="/services" element={<OwnerServices />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/activity" element={<Activity />} />
          <Route path="/settings" element={<OwnerSettings />} />
        </Route>
      </Routes>
    </Suspense>
  );
}

export default function OwnerApp() {
  return (
    <AppProvider>
      <HashRouter>
        <AppRoutes />
      </HashRouter>
    </AppProvider>
  );
}
