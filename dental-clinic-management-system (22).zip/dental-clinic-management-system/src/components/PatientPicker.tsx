"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown, Search, UserPlus, X } from "lucide-react";
import { api } from "@/lib/api";
import { useDebounce } from "@/hooks";
import type { PatientSearchResult } from "@/types";
import { Avatar, Input } from "@/components/ui";
import { cn } from "@/utils/cn";
import { formatDate } from "@/utils/format";

export interface PatientSelectorValue {
  patientId?: string;
  name: string;
  phone: string;
  manual: boolean;
}

/**
 * Professional patient selector.
 * Renders a single "👤 المريض" trigger that opens a dropdown (like the
 * Doctor/Service selectors) with live debounced search, rich patient cards,
 * and a manual-entry option. Selecting an existing patient links the form to
 * its database record (never duplicates). Manual entry links by phone if it
 * exists, otherwise a new patient is created on save.
 */
export function PatientSelector({
  value,
  onChange,
  initialPatient,
  error,
}: {
  value: PatientSelectorValue;
  onChange: (v: PatientSelectorValue) => void;
  initialPatient?: PatientSearchResult | null;
  error?: string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<PatientSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const debounced = useDebounce(query, 300);
  const ref = useRef<HTMLDivElement>(null);

  // Seed initial patient (edit mode) once.
  useEffect(() => {
    if (initialPatient) {
      onChange({
        patientId: initialPatient.id,
        name: initialPatient.name,
        phone: initialPatient.phone,
        manual: false,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialPatient]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Debounced AJAX search.
  useEffect(() => {
    const q = debounced.trim();
    if (!q) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    let active = true;
    api
      .searchPatientsAdvanced(q, 8)
      .then((r) => active && setResults(r))
      .catch(() => active && setResults([]))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [debounced]);

  const select = (p: PatientSearchResult) => {
    onChange({ patientId: p.id, name: p.name, phone: p.phone, manual: false });
    setOpen(false);
    setQuery("");
  };

  const goManual = () => {
    onChange({ name: "", phone: "", manual: true });
    setOpen(false);
  };

  const backToSelect = () => {
    onChange({ name: "", phone: "", manual: false });
    setQuery("");
  };

  const hasSelection = !!value.patientId && !value.manual;

  return (
    <div ref={ref} className="relative">
      <span className="mb-1.5 flex items-center gap-1 text-sm font-semibold text-slate-600 dark:text-slate-300">
        👤 المريض <span className="text-rose-500">*</span>
      </span>

      {value.manual ? (
        <div className="space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              value={value.name}
              onChange={(e) => onChange({ ...value, name: e.target.value })}
              placeholder="اسم المريض"
            />
            <Input
              value={value.phone}
              onChange={(e) => onChange({ ...value, phone: e.target.value })}
              dir="ltr"
              placeholder="رقم الهاتف (01012345678)"
            />
          </div>
          <button
            type="button"
            onClick={backToSelect}
            className="text-xs font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
          >
            ← اختيار مريض موجود
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className={cn(
            "flex w-full items-center gap-3 rounded-xl border bg-slate-50 px-3.5 py-2.5 text-right transition-colors dark:bg-slate-800/60",
            error
              ? "border-rose-400"
              : "border-slate-200 hover:border-brand-400 dark:border-slate-700",
            hasSelection && "bg-emerald-50/60 dark:bg-emerald-500/5"
          )}
        >
          {hasSelection ? (
            <>
              <Avatar name={value.name} size="sm" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-slate-700 dark:text-slate-200">
                  {value.name}
                </p>
                <p className="truncate text-xs text-slate-400" dir="ltr">
                  {value.phone}
                </p>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onChange({ name: "", phone: "", manual: true });
                }}
                className="rounded-md p-1 text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                title="تغيير"
              >
                <X className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-50 text-sm dark:bg-brand-500/15">
                👤
              </span>
              <span className="flex-1 text-sm text-slate-400">اختر مريضاً...</span>
            </>
          )}
          <ChevronDown className={cn("h-4 w-4 text-slate-400 transition-transform", open && "rotate-180")} />
        </button>
      )}

      {open && !value.manual && (
        <div className="absolute z-40 mt-2 w-full overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
          <div className="border-b border-slate-100 p-2 dark:border-slate-800">
            <div className="relative">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث بالاسم أو رقم الهاتف..."
                className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pr-9 pl-3 text-sm text-slate-800 placeholder:text-slate-400 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              />
              {loading && (
                <span className="absolute left-3 top-1/2 -translate-y-1/2">
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
                </span>
              )}
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto p-1.5">
            {!loading && results.length === 0 ? (
              <div className="px-3 py-6 text-center">
                <p className="mb-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
                  {query.trim() ? "❌ لا يوجد مريض مطابق." : "ابدأ الكتابة للبحث عن مريض..."}
                </p>
              </div>
            ) : (
              results.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => select(p)}
                  className="flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-right transition-colors hover:bg-brand-50 dark:hover:bg-brand-500/10"
                >
                  <Avatar name={p.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">
                      👤 {p.name}
                    </p>
                    <p className="truncate text-xs text-slate-400" dir="ltr">
                      📱 {p.phone} • 🎂 {p.age} سنة
                    </p>
                    <p className="mt-0.5 truncate text-[11px] text-slate-400">
                      🦷 {p.visitsCount} زيارة • 📅 آخر زيارة: {formatDate(p.lastVisit)}
                    </p>
                  </div>
                </button>
              ))
            )}
          </div>

          <button
            type="button"
            onClick={goManual}
            className="flex w-full items-center justify-center gap-1.5 border-t border-slate-100 bg-slate-50/60 py-2.5 text-sm font-bold text-brand-600 transition-colors hover:bg-brand-50 dark:border-slate-800 dark:bg-slate-800/40 dark:text-brand-400 dark:hover:bg-brand-500/10"
          >
            <UserPlus className="h-4 w-4" /> تسجيل مريض يدويًا
          </button>
        </div>
      )}
    </div>
  );
}
