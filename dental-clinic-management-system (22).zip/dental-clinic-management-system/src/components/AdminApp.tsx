"use client";

import { lazy, Suspense } from "react";
import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { AppProvider, useApp } from "@/contexts/AppContext";
import Layout from "@/components/Layout";
import { Spinner } from "@/components/ui";

// Lazy-loaded admin pages — code-split for faster initial load.
const Dashboard = lazy(() => import("@/admin-pages/Dashboard"));
const Patients = lazy(() => import("@/admin-pages/Patients"));
const PatientProfile = lazy(() => import("@/admin-pages/PatientProfile"));
const Doctors = lazy(() => import("@/admin-pages/Doctors"));
const DoctorProfile = lazy(() => import("@/admin-pages/DoctorProfile"));
const Services = lazy(() => import("@/admin-pages/Services"));
const Appointments = lazy(() => import("@/admin-pages/Appointments"));
const Visits = lazy(() => import("@/admin-pages/Visits"));
const Settings = lazy(() => import("@/admin-pages/Settings"));

function Fallback() {
  return (
    <div className="flex h-[60vh] items-center justify-center">
      <Spinner className="h-8 w-8 text-brand-500" />
    </div>
  );
}

function AppRoutes() {
  const { loading } = useApp();
  // Wait for initial data load before mounting routes — pages assume data is present.
  if (loading) return <Fallback />;
  return (
    <Suspense fallback={<Fallback />}>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/patients/:id" element={<PatientProfile />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/doctors/:id" element={<DoctorProfile />} />
          <Route path="/services" element={<Services />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/visits" element={<Visits />} />
          <Route path="/settings" element={<Settings />} />
          {/* Reports route is owner-only — admin is redirected to dashboard */}
          <Route path="/reports" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Suspense>
  );
}

export default function AdminApp() {
  return (
    <AppProvider>
      <HashRouter>
        <AppRoutes />
      </HashRouter>
    </AppProvider>
  );
}
