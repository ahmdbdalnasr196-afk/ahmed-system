"use client";

import { minutesToTime, timeToMinutes, to12h } from "@/utils/format";

const HOURS = Array.from({ length: 12 }, (_, i) => i + 1);
const MINUTES = [0, 15, 30, 45];

const sel =
  "rounded-lg border border-slate-200 bg-slate-50 px-2 py-2 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200";

export function TimePicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const total = timeToMinutes(value || "09:00");
  const h24 = Math.floor(total / 60);
  const m = total % 60;
  const period = h24 >= 12 ? "PM" : "AM";
  const h12 = (() => {
    let h = h24 % 12;
    if (h === 0) h = 12;
    return h;
  })();

  const set = (nh: number, nm: number, np: "AM" | "PM") => {
    let h = nh % 12;
    if (np === "PM") h += 12;
    onChange(minutesToTime(h * 60 + nm));
  };

  return (
    <div className="flex items-center gap-1.5" dir="ltr">
      <select className={sel} value={h12} onChange={(e) => set(Number(e.target.value), m, period)}>
        {HOURS.map((h) => (
          <option key={h} value={h}>
            {String(h).padStart(2, "0")}
          </option>
        ))}
      </select>
      <span className="text-slate-400">:</span>
      <select className={sel} value={m} onChange={(e) => set(h12, Number(e.target.value), period)}>
        {MINUTES.map((mm) => (
          <option key={mm} value={mm}>
            {String(mm).padStart(2, "0")}
          </option>
        ))}
      </select>
      <select className={sel} value={period} onChange={(e) => set(h12, m, e.target.value as "AM" | "PM")}>
        <option value="AM">AM</option>
        <option value="PM">PM</option>
      </select>
      <span className="text-xs font-medium text-slate-400">{to12h(value || "09:00")}</span>
    </div>
  );
}
