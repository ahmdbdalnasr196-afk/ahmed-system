import { serve, routeServices } from "./_lib";
export default async (req: any, res: any) => {
  try {
    await serve(req, res, routeServices);
  } catch (err: any) {
    console.error("[TOP-LEVEL CRASH GUARD]:", err);
    try {
      res.status(500).json({ success: false, message: err?.message || "Internal Server Error", error: String(err?.stack || err) });
    } catch { /* ignore */ }
  }
};
