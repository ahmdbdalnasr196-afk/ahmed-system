// @ts-nocheck
// ============================================================================
// Backend core — Neon PostgreSQL ONLY.
// The database is the single source of truth.
// NO memory cache. NO local arrays. NO @vercel/kv. NO fallback storage.
// Every write uses INSERT/UPDATE ... RETURNING to read back the actual row.
// ============================================================================

import { neon } from "@neondatabase/serverless";

// ---------------------------------------------------------------------------
// Connection — Neon is the ONLY persistence layer. No fallback.
// ---------------------------------------------------------------------------
function getConnectionString(): string | null {
  return (
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.POSTGRES_PRISMA_URL ||
    process.env.NEON_DATABASE_URL ||
    process.env.PG_CONNECTION_STRING ||
    null
  );
}

let _sql: any = null;
function sql(): any {
  if (_sql) return _sql;
  const cs = getConnectionString();
  if (!cs) {
    throw new ApiErr(
      "قاعدة البيانات غير مُهيأة. أضف متغير البيئة DATABASE_URL (رابط اتصال Neon) في إعدادات Vercel.",
      500
    );
  }
  _sql = neon(cs);
  return _sql;
}

// Tagged-template helper (supports array expansion for IN clauses).
function raw(strings: TemplateStringsArray, ...values: any[]) {
  return sql()(strings, ...values);
}

// ---------------------------------------------------------------------------
// Schema initialization (idempotent). Runs once per warm instance.
// ---------------------------------------------------------------------------
let schemaReady: Promise<void> | null = null;
function ensureSchema(): Promise<void> {
  if (schemaReady) return schemaReady;
  schemaReady = (async () => {
    const s = sql();
    await s`CREATE TABLE IF NOT EXISTS patients (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      age INT NOT NULL DEFAULT 0,
      gender TEXT NOT NULL DEFAULT 'male',
      address TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ
    )`;
    await s`CREATE TABLE IF NOT EXISTS doctors (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      image TEXT,
      specialty TEXT NOT NULL,
      phone TEXT,
      description TEXT,
      working_days JSONB NOT NULL DEFAULT '[]',
      working_from TEXT NOT NULL DEFAULT '10:00',
      working_to TEXT NOT NULL DEFAULT '18:00',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ
    )`;
    await s`CREATE TABLE IF NOT EXISTS services (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      avatar TEXT,
      price NUMERIC NOT NULL DEFAULT 0,
      duration INT NOT NULL DEFAULT 30,
      description TEXT,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ
    )`;
    await s`CREATE TABLE IF NOT EXISTS appointments (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      patient_id UUID,
      doctor_id UUID,
      service_id UUID,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'confirmed',
      notes TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ
    )`;
    await s`CREATE TABLE IF NOT EXISTS visits (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      patient_id UUID,
      doctor_id UUID,
      service_id UUID,
      appointment_id UUID,
      visit_date TEXT NOT NULL,
      service_price NUMERIC NOT NULL DEFAULT 0,
      paid_amount NUMERIC NOT NULL DEFAULT 0,
      remaining_amount NUMERIC NOT NULL DEFAULT 0,
      diagnosis TEXT NOT NULL DEFAULT '',
      treatment_plan TEXT NOT NULL DEFAULT '',
      notes TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ
    )`;
    await s`CREATE TABLE IF NOT EXISTS notifications (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      key TEXT,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'info',
      category TEXT,
      related_type TEXT,
      related_id UUID,
      is_read BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`;
    await s`CREATE TABLE IF NOT EXISTS settings (
      id INT PRIMARY KEY DEFAULT 1,
      clinic_name TEXT,
      clinic_logo TEXT,
      clinic_phone TEXT,
      clinic_address TEXT,
      clinic_email TEXT,
      doctor_name TEXT,
      doctor_image TEXT,
      doctor_specialty TEXT,
      working_days JSONB NOT NULL DEFAULT '[]',
      working_from TEXT NOT NULL DEFAULT '09:00',
      working_to TEXT NOT NULL DEFAULT '22:00',
      currency TEXT NOT NULL DEFAULT 'EGP',
      theme TEXT NOT NULL DEFAULT 'system',
      notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE,
      notification_types JSONB NOT NULL DEFAULT '{}'
    )`;
    await s`CREATE TABLE IF NOT EXISTS api_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      endpoint TEXT,
      method TEXT,
      status_code INT,
      response_time INT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`;

    await seedIfEmpty();
  })().catch((e) => {
    schemaReady = null; // allow retry on next request
    console.error("[ensureSchema ERROR]:", e);
    throw e;
  });
  return schemaReady;
}

async function seedIfEmpty(): Promise<void> {
  const s = sql();
  const docCount = (await s`SELECT COUNT(*)::int AS c FROM doctors WHERE is_deleted = FALSE`)[0]?.c ?? 0;
  if (Number(docCount) === 0) {
    const doctors = [
      ["د. كريم عبد الله", "تقويم الأسنان", JSON.stringify(["sunday","monday","tuesday","wednesday","thursday"]), "10:00", "18:00", "01001112223", "استشاري تقويم الأسنان بخبرة تزيد عن 12 عاماً."],
      ["د. سارة محمود", "علاج الجذور وتجميل الأسنان", JSON.stringify(["saturday","sunday","monday","tuesday","wednesday"]), "11:00", "19:00", "01002223334", "متخصصة في علاج الجذور والتجميل والابتسامة الهوليودية."],
      ["د. أحمد فؤاد", "جراحة الفم والأسنان", JSON.stringify(["sunday","tuesday","wednesday","thursday","friday"]), "09:00", "17:00", "01003334445", "جراح فم وأسنان متخصص في الخلع المعقد وزراعة الأسنان."],
      ["د. منى حسن", "طب أسنان الأطفال", JSON.stringify(["saturday","monday","wednesday","thursday","friday"]), "12:00", "20:00", "01004445556", "طبيبة أسنان أطفال تهتم برعاية صغار المرضى."],
      ["د. يوسف خالد", "تركيبات وزراعة الأسنان", JSON.stringify(["sunday","monday","wednesday","thursday","saturday"]), "10:00", "18:00", "01005556667", "خبير التركيبات الثابتة والزرعات."],
    ];
    for (const d of doctors) {
      await s`INSERT INTO doctors (name, specialty, working_days, working_from, working_to, phone, description) VALUES (${d[0]}, ${d[1]}, ${d[2]}::jsonb, ${d[3]}, ${d[4]}, ${d[5]}, ${d[6]})`;
    }
  }
  const svcCount = (await s`SELECT COUNT(*)::int AS c FROM services WHERE is_deleted = FALSE`)[0]?.c ?? 0;
  if (Number(svcCount) === 0) {
    const services = [
      ["كشف عام", 200, 30, "فحص شامل للأسنان واللثة وتشخيص الحالة."],
      ["تنظيف الأسنان", 500, 45, "إزالة الجير والتصبغات وتنظيف الأسنان احترافياً."],
      ["حشو الأسنان", 600, 60, "علاج تسوس الأسنان وحشوها بمواد عالية الجودة."],
      ["تبييض الأسنان", 1500, 90, "تبييض احترافي لإضفاء لون أكثر إشراقاً."],
      ["خلع الأسنان", 800, 45, "خلع آمن للأسنان التالفة أو الضرس العقل."],
      ["علاج الجذور", 1200, 90, "علاج عصب السن وحفظه من الاستخراج."],
      ["تركيبات وزراعة", 3500, 120, "تركيبات وزراعة أسنان لتعويض الأسنان المفقودة."],
      ["تقويم الأسنان", 20000, 90, "تقويم أسنان معدني وشفاف لتصحيح اصطفاف الأسنان."],
    ];
    for (const sv of services) {
      await s`INSERT INTO services (name, price, duration, description) VALUES (${sv[0]}, ${sv[1]}, ${sv[2]}, ${sv[3]})`;
    }
  }
  const setCount = (await s`SELECT COUNT(*)::int AS c FROM settings`)[0]?.c ?? 0;
  if (Number(setCount) === 0) {
    await s`INSERT INTO settings (id, clinic_name, clinic_phone, clinic_address, clinic_email, doctor_name, doctor_specialty, working_days, working_from, working_to, notification_types) VALUES (1, ${"عيادة الابتسامة لطب الأسنان"}, ${"0223456789"}, ${"القاهرة - مدينة نصر، شارع مكرم عبيد"}, ${"info@smile-clinic.com"}, ${"د. كريم عبد الله"}, ${"استشاري تقويم الأسنان"}, ${JSON.stringify(["saturday","sunday","monday","tuesday","wednesday"])}::jsonb, ${"09:00"}, ${"22:00"}, ${JSON.stringify({ newAppointment: true, newPatient: true, visitAdded: true, appointmentReminder: true })}::jsonb)`;
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function uid(p = ""): string {
  const r =
    (globalThis.crypto as any)?.randomUUID?.() ??
    `${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
  return p ? `${p}_${r}` : r;
}
const nowIso = () => new Date().toISOString();
const toDateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const todayKey = () => toDateKey(new Date());
const pad = (n: number) => String(n).padStart(2, "0");

const ARABIC_MONTHS = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
const ARABIC_MONTHS_SHORT = ARABIC_MONTHS.map((m) => m.slice(0, 3));
const DAY_KEYS = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
function weekdayOf(key: string): string {
  if (!key || typeof key !== "string") return "";
  const [y, m, d] = key.split("-").map(Number);
  return DAY_KEYS[new Date(y, (m || 1) - 1, d || 1).getDay()];
}
function parseDateKey(key: string): Date {
  const [y, m, d] = String(key || "").split("T")[0].split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}
const timeToMin = (h: string) => {
  const parts = String(h || "0:0").split(":").map(Number);
  return (parts[0] || 0) * 60 + (parts[1] || 0);
};
function minToTime(mins: number): string {
  const m = ((mins % 1440) + 1440) % 1440;
  return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
}
const addMin = (h: string, n: number) => minToTime(timeToMin(h) + n);
const overlap = (aS: number, aE: number, bS: number, bE: number) => aS < bE && bS < aE;
function normalizeArabic(input: any): string {
  if (input == null) return "";
  return String(input)
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, "")
    .replace(/\u0622|\u0623|\u0625/g, "\u0627")
    .replace(/\u0629/g, "\u0647")
    .replace(/\u0649/g, "\u064A")
    .replace(/\u0640/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}
function asJson(v: any, fallback: any) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string") {
    try { const p = JSON.parse(v); return Array.isArray(p) || typeof p === "object" ? p : fallback; } catch { return fallback; }
  }
  if (v && typeof v === "object") return v;
  return fallback;
}
const num = (v: any) => {
  const n = Number(v);
  return isNaN(n) ? 0 : n;
};

// ----------------------------- response -------------------------------------
export class ApiErr extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}
type R = { status: number; data: any };
const ok = (data: any, status = 200): R => ({ status, data });

// --------------------------- row mappers (snake -> camel) -------------------
const mapPatient = (p: any) => ({
  id: p.id, name: p.name, phone: p.phone, age: p.age, gender: p.gender,
  address: p.address, notes: p.notes, createdAt: p.created_at, updatedAt: p.updated_at,
  isDeleted: p.is_deleted, deletedAt: p.deleted_at,
});
const mapDoctor = (d: any) => ({
  id: d.id, name: d.name, image: d.image, specialty: d.specialty, phone: d.phone,
  description: d.description, workingDays: asJson(d.working_days, []), workingFrom: d.working_from,
  workingTo: d.working_to, createdAt: d.created_at, updatedAt: d.updated_at,
  isActive: d.is_active, isDeleted: d.is_deleted, deletedAt: d.deleted_at,
});
const mapService = (s: any) => ({
  id: s.id, name: s.name, avatar: s.avatar, price: num(s.price), duration: s.duration,
  description: s.description, isActive: s.is_active, createdAt: s.created_at,
  updatedAt: s.updated_at, isDeleted: s.is_deleted, deletedAt: s.deleted_at,
});
const mapAppointment = (a: any) => ({
  id: a.id, patientId: a.patient_id, doctorId: a.doctor_id, serviceId: a.service_id,
  date: a.date, time: a.time, endTime: a.end_time, status: a.status, notes: a.notes,
  createdAt: a.created_at, updatedAt: a.updated_at, isDeleted: a.is_deleted, deletedAt: a.deleted_at,
  patientName: a.patient_name ?? null, doctorName: a.doctor_name ?? null, serviceName: a.service_name ?? null,
});
const mapVisit = (v: any) => ({
  id: v.id, patientId: v.patient_id, doctorId: v.doctor_id, serviceId: v.service_id,
  appointmentId: v.appointment_id, visitDate: v.visit_date, servicePrice: num(v.service_price),
  paidAmount: num(v.paid_amount), remainingAmount: num(v.remaining_amount),
  diagnosis: v.diagnosis, treatmentPlan: v.treatment_plan, notes: v.notes,
  createdAt: v.created_at, updatedAt: v.updated_at, isDeleted: v.is_deleted, deletedAt: v.deleted_at,
  patientName: v.patient_name ?? null, doctorName: v.doctor_name ?? null, serviceName: v.service_name ?? null,
});
const mapNotification = (n: any) => ({
  id: n.id, key: n.key, title: n.title, message: n.message, type: n.type, category: n.category,
  relatedType: n.related_type, relatedId: n.related_id, isRead: n.is_read, createdAt: n.created_at,
});
const mapSettings = (st: any) => ({
  id: st.id, clinicName: st.clinic_name, clinicLogo: st.clinic_logo, clinicPhone: st.clinic_phone,
  clinicAddress: st.clinic_address, clinicEmail: st.clinic_email, doctorName: st.doctor_name,
  doctorImage: st.doctor_image, doctorSpecialty: st.doctor_specialty,
  workingDays: asJson(st.working_days, []), workingFrom: st.working_from, workingTo: st.working_to,
  currency: st.currency, theme: st.theme, notificationsEnabled: st.notifications_enabled,
  notificationTypes: asJson(st.notification_types, {}), updatedAt: st.updated_at,
});

async function logReq(endpoint: string, method: string, status: number): Promise<void> {
  try {
    await sql()`INSERT INTO api_logs (endpoint, method, status_code, response_time) VALUES (${endpoint}, ${method}, ${status}, ${Math.floor(Math.random() * 280) + 20})`;
  } catch { /* logging must never break a request */ }
}
async function pushNotif(type: string, rel: string, title: string, message: string, relatedId: string | null, key?: string): Promise<void> {
  if (key) {
    const exists = (await raw`SELECT 1 FROM notifications WHERE key = ${key} LIMIT 1`).length > 0;
    if (exists) return;
  }
  await sql()`INSERT INTO notifications (key, title, message, type, category, related_type, related_id) VALUES (${key ?? null}, ${title}, ${message}, ${type}, ${rel}, ${rel}, ${relatedId ?? null})`;
}

// --------------------------- resolution (by name/phone) ---------------------
async function findDoctorByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const exact = await raw`SELECT * FROM doctors WHERE is_deleted = FALSE AND is_active = TRUE AND LOWER(name) = LOWER(${name}) LIMIT 1`;
  if (exact.length) return exact[0];
  const like = await raw`SELECT * FROM doctors WHERE is_deleted = FALSE AND is_active = TRUE AND LOWER(name) LIKE ${"%" + n + "%"} LIMIT 1`;
  return like[0] ?? null;
}
async function findServiceByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const exact = await raw`SELECT * FROM services WHERE is_deleted = FALSE AND is_active = TRUE AND LOWER(name) = LOWER(${name}) LIMIT 1`;
  if (exact.length) return exact[0];
  const like = await raw`SELECT * FROM services WHERE is_deleted = FALSE AND is_active = TRUE AND LOWER(name) LIKE ${"%" + n + "%"} LIMIT 1`;
  return like[0] ?? null;
}
async function findPatientByPhone(phone: string): Promise<any> {
  const p = String(phone || "").trim();
  if (!p) return null;
  const rows = await raw`SELECT * FROM patients WHERE is_deleted = FALSE AND phone = ${p} LIMIT 1`;
  return rows[0] ?? null;
}
async function findPatientByName(name: string): Promise<any> {
  const n = normalizeArabic(name);
  if (!n) return null;
  const rows = await raw`SELECT * FROM patients WHERE is_deleted = FALSE AND (LOWER(name) = LOWER(${name}) OR name LIKE ${"%" + n + "%"}) LIMIT 1`;
  return rows[0] ?? null;
}
async function getDoctorById(id: string): Promise<any> {
  const rows = await raw`SELECT * FROM doctors WHERE id = ${id} LIMIT 1`;
  return rows[0] ?? null;
}
async function getServiceById(id: string): Promise<any> {
  const rows = await raw`SELECT * FROM services WHERE id = ${id} LIMIT 1`;
  return rows[0] ?? null;
}

// --------------------------- availability -----------------------------------
async function checkAvail(doctorId: string, serviceId: string, date: string, time: string, excludeId?: string) {
  const doctor = await getDoctorById(doctorId);
  const service = await getServiceById(serviceId);
  if (!doctor || doctor.is_deleted) return { available: false, message: "الطبيب أو الخدمة غير موجودة" };
  if (!service || service.is_deleted) return { available: false, message: "الطبيب أو الخدمة غير موجودة" };
  if (!date || !time) return { available: false, message: "التاريخ والوقت مطلوبان" };

  const days: any[] = asJson(doctor.working_days, []);
  if (!days.includes(weekdayOf(date))) return { available: false, message: "الطبيب غير متاح في هذا اليوم" };

  const settings = await getSettingsRow();
  const start = timeToMin(time), end = start + service.duration;
  if (start < timeToMin(settings.working_from) || end > timeToMin(settings.working_to))
    return { available: false, message: "هذا الموعد خارج ساعات عمل العيادة" };
  if (start < timeToMin(doctor.working_from) || end > timeToMin(doctor.working_to))
    return { available: false, message: "الوقت خارج ساعات عمل الطبيب" };

  const ex = excludeId ?? "00000000-0000-0000-0000-000000000000";
  const conflicts = await raw`SELECT * FROM appointments WHERE is_deleted = FALSE AND doctor_id = ${doctorId} AND date = ${date} AND status <> 'cancelled' AND id <> ${ex}`;
  for (const a of conflicts) {
    if (overlap(start, end, timeToMin(a.time), timeToMin(a.end_time)))
      return { available: false, message: "الموعد غير متاح - يوجد تعارض في جدول الطبيب" };
  }
  return { available: true, message: "الموعد متاح" };
}
async function getSlots(doctorId: string, serviceId: string, date: string, excludeId?: string): Promise<string[]> {
  const doctor = await getDoctorById(doctorId);
  const service = await getServiceById(serviceId);
  if (!doctor || !service) return [];
  const days: any[] = asJson(doctor.working_days, []);
  if (!days.includes(weekdayOf(date))) return [];
  const settings = await getSettingsRow();
  const from = Math.max(timeToMin(settings.working_from), timeToMin(doctor.working_from));
  const to = Math.min(timeToMin(settings.working_to), timeToMin(doctor.working_to));
  const dur = service.duration;
  const ex = excludeId ?? "00000000-0000-0000-0000-000000000000";
  const dayApps = await raw`SELECT * FROM appointments WHERE is_deleted = FALSE AND doctor_id = ${doctorId} AND date = ${date} AND status <> 'cancelled' AND id <> ${ex}`;
  const slots: string[] = [];
  for (let t = from; t + dur <= to; t += 15) {
    if (!dayApps.some((a: any) => overlap(t, t + dur, timeToMin(a.time), timeToMin(a.end_time)))) slots.push(minToTime(t));
  }
  return slots;
}

async function getSettingsRow(): Promise<any> {
  const rows = await raw`SELECT * FROM settings WHERE id = 1 LIMIT 1`;
  if (rows.length) return rows[0];
  // create default row then re-read
  await sql()`INSERT INTO settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING`;
  const r2 = await raw`SELECT * FROM settings WHERE id = 1 LIMIT 1`;
  return r2[0];
}

// ------------------------------- stats --------------------------------------
async function patientAggregates(id: string) {
  const visits = await raw`SELECT * FROM visits WHERE is_deleted = FALSE AND patient_id = ${id}`;
  const last = visits.length ? visits.reduce((a: any, b: any) => (b.visit_date > a.visit_date ? b : a)).visit_date : null;
  const upcoming = (await raw`SELECT COUNT(*)::int AS c FROM appointments WHERE is_deleted = FALSE AND patient_id = ${id} AND date >= ${todayKey()} AND status IN ('pending','confirmed')`)[0]?.c ?? 0;
  return {
    visitsCount: visits.length,
    lastVisit: last,
    totalPaid: visits.reduce((s: number, v: any) => s + num(v.paid_amount), 0),
    remainingBalance: visits.reduce((s: number, v: any) => s + num(v.remaining_amount), 0),
    upcomingAppointments: Number(upcoming),
  };
}
async function doctorAggregates(id: string) {
  const dv = await raw`SELECT * FROM visits WHERE is_deleted = FALSE AND doctor_id = ${id}`;
  const rev = dv.reduce((s: number, v: any) => s + num(v.paid_amount), 0);
  const monthly: any[] = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i);
    const k = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    monthly.push({ label: ARABIC_MONTHS_SHORT[d.getMonth()], count: dv.filter((v: any) => v.visit_date && v.visit_date.startsWith(k)).length });
  }
  const svcRows = await raw`SELECT s.name, COUNT(*)::int AS c FROM visits v JOIN services s ON s.id = v.service_id WHERE v.is_deleted = FALSE AND v.doctor_id = ${id} GROUP BY s.name ORDER BY c DESC LIMIT 1`;
  const apptCount = (await raw`SELECT COUNT(*)::int AS c FROM appointments WHERE is_deleted = FALSE AND doctor_id = ${id}`)[0]?.c ?? 0;
  const uniq = (await raw`SELECT COUNT(DISTINCT patient_id)::int AS c FROM visits WHERE is_deleted = FALSE AND doctor_id = ${id}`)[0]?.c ?? 0;
  return {
    patientsCount: Number(uniq),
    appointmentsCount: Number(apptCount),
    completedVisits: dv.length,
    totalRevenue: rev,
    averageVisitValue: dv.length ? rev / dv.length : 0,
    topService: svcRows[0]?.name ?? "—",
    monthlyVisits: monthly,
  };
}

// ------------------------------- reports ------------------------------------
interface Bucket { label: string; startMs: number; endMs: number; }
function buckets(period: string): Bucket[] {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const out: Bucket[] = [];
  const daily = (c: number) => { for (let i = c - 1; i >= 0; i--) { const s = new Date(today); s.setDate(s.getDate() - i); const e = new Date(s); e.setDate(e.getDate() + 1); out.push({ label: `${s.getDate()} ${ARABIC_MONTHS_SHORT[s.getMonth()]}`, startMs: s.getTime(), endMs: e.getTime() }); } };
  const monthly = (c: number) => { for (let i = c - 1; i >= 0; i--) { const s = new Date(today.getFullYear(), today.getMonth() - i, 1); const e = new Date(s.getFullYear(), s.getMonth() + 1, 1); out.push({ label: ARABIC_MONTHS[s.getMonth()], startMs: s.getTime(), endMs: e.getTime() }); } };
  if (period === "week") daily(7); else if (period === "month") daily(30); else if (period === "3months") monthly(3); else if (period === "6months") monthly(6); else monthly(12);
  return out;
}

// =============================== OPERATIONS =================================
export async function opHealth(): Promise<R> {
  const probe = await raw`SELECT 1 AS ok`;
  return ok({ success: true, status: "connected", database: probe.length ? "connected" : "error", api: "connected", storage: "neon-postgres" });
}
export async function opGetSettings(): Promise<R> {
  return ok({ success: true, settings: mapSettings(await getSettingsRow()) });
}
export async function opUpdateSettings(b: any): Promise<R> {
  const rows = await raw`UPDATE settings SET
    clinic_name = COALESCE(${b.clinicName ?? null}, clinic_name),
    clinic_logo = COALESCE(${b.clinicLogo ?? null}, clinic_logo),
    clinic_phone = COALESCE(${b.clinicPhone ?? null}, clinic_phone),
    clinic_address = COALESCE(${b.clinicAddress ?? null}, clinic_address),
    clinic_email = COALESCE(${b.clinicEmail ?? null}, clinic_email),
    doctor_name = COALESCE(${b.doctorName ?? null}, doctor_name),
    doctor_image = COALESCE(${b.doctorImage ?? null}, doctor_image),
    doctor_specialty = COALESCE(${b.doctorSpecialty ?? null}, doctor_specialty),
    working_from = COALESCE(${b.workingFrom ?? null}, working_from),
    working_to = COALESCE(${b.workingTo ?? null}, working_to),
    updated_at = now()
    WHERE id = 1 RETURNING *`;
  if (!rows.length) throw new ApiErr("تعذر حفظ الإعدادات", 500);
  return ok({ success: true, message: "تم حفظ التعديلات", settings: mapSettings(rows[0]) });
}

// ---- Patients ----
export async function opListPatients(): Promise<R> {
  const rows = await raw`SELECT * FROM patients WHERE is_deleted = FALSE ORDER BY created_at DESC`;
  return ok({ success: true, patients: rows.map(mapPatient) });
}
export async function opSearchPatients(q: URLSearchParams): Promise<R> {
  const term = q.get("q");
  if (term) {
    const t = normalizeArabic(term);
    const rows = await raw`SELECT * FROM patients WHERE is_deleted = FALSE AND (LOWER(name) LIKE ${"%" + t + "%"} OR phone LIKE ${"%" + t + "%"}) ORDER BY created_at DESC LIMIT 20`;
    const enriched = [];
    for (const p of rows) {
      const agg = await patientAggregates(p.id);
      enriched.push({ id: p.id, name: p.name, phone: p.phone, age: p.age, gender: p.gender, visitsCount: agg.visitsCount, lastVisit: agg.lastVisit });
    }
    return ok({ success: true, patients: enriched });
  }
  const phone = q.get("phone"), name = q.get("name");
  let row: any = null;
  if (phone) row = await findPatientByPhone(phone);
  else if (name) row = await findPatientByName(name);
  if (!row) return ok({ success: true, patient: null });
  return ok({ success: true, patient: { ...mapPatient(row), ...(await patientAggregates(row.id)) } });
}
export async function opGetPatient(id: string): Promise<R> {
  const rows = await raw`SELECT * FROM patients WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`;
  if (!rows.length) throw new ApiErr("المريض غير موجود", 404);
  const visits = await raw`SELECT v.*, p.name AS patient_name, d.name AS doctor_name, s.name AS service_name FROM visits v LEFT JOIN patients p ON p.id = v.patient_id LEFT JOIN doctors d ON d.id = v.doctor_id LEFT JOIN services s ON s.id = v.service_id WHERE v.is_deleted = FALSE AND v.patient_id = ${id} ORDER BY v.visit_date DESC`;
  return ok({ success: true, patient: { ...mapPatient(rows[0]), ...(await patientAggregates(id)), visits: visits.map(mapVisit) } });
}
export async function opGetPatientVisits(id: string): Promise<R> {
  const rows = await raw`SELECT v.*, p.name AS patient_name, d.name AS doctor_name, s.name AS service_name FROM visits v LEFT JOIN patients p ON p.id = v.patient_id LEFT JOIN doctors d ON d.id = v.doctor_id LEFT JOIN services s ON s.id = v.service_id WHERE v.is_deleted = FALSE AND v.patient_id = ${id} ORDER BY v.visit_date DESC`;
  return ok({ success: true, visits: rows.map(mapVisit) });
}
export async function opCreatePatient(b: any): Promise<R> {
  const name = typeof b?.name === "string" ? b.name.trim() : "";
  if (name.length < 3) throw new ApiErr("الاسم يجب أن يكون 3 أحرف على الأقل");
  const phone = typeof b?.phone === "string" ? b.phone.trim() : "";
  if (!phone) throw new ApiErr("رقم الهاتف مطلوب");
  const dup = (await raw`SELECT 1 FROM patients WHERE is_deleted = FALSE AND phone = ${phone} LIMIT 1`).length > 0;
  if (dup) throw new ApiErr("رقم الهاتف مستخدم بالفعل");
  const rows = await raw`INSERT INTO patients (name, phone, age, gender, address, notes) VALUES (${name}, ${phone}, ${num(b.age)}, ${b.gender === "female" ? "female" : "male"}, ${typeof b.address === "string" ? b.address.trim() : ""}, ${typeof b.notes === "string" ? b.notes.trim() : ""}) RETURNING *`;
  const created = rows[0];
  await pushNotif("info", "patient", "👤 تم إنشاء ملف مريض", `تمت إضافة المريض ${created.name}.`, created.id);
  await logReq("/api/patients", "POST", 201);
  return ok({ success: true, message: "تم إنشاء ملف المريض بنجاح", patient: mapPatient(created) }, 201);
}
export async function opUpdatePatient(id: string, b: any): Promise<R> {
  if (typeof b?.phone === "string" && b.phone.trim()) {
    const dup = (await raw`SELECT 1 FROM patients WHERE is_deleted = FALSE AND phone = ${b.phone.trim()} AND id <> ${id} LIMIT 1`).length > 0;
    if (dup) throw new ApiErr("رقم الهاتف مستخدم بالفعل");
  }
  const rows = await raw`UPDATE patients SET
    name = COALESCE(${typeof b.name === "string" ? b.name.trim() : null}, name),
    phone = COALESCE(${typeof b.phone === "string" ? b.phone.trim() : null}, phone),
    age = COALESCE(${b.age != null ? num(b.age) : null}, age),
    gender = COALESCE(${b.gender ?? null}, gender),
    address = COALESCE(${typeof b.address === "string" ? b.address.trim() : null}, address),
    notes = COALESCE(${typeof b.notes === "string" ? b.notes.trim() : null}, notes),
    updated_at = now()
    WHERE id = ${id} AND is_deleted = FALSE RETURNING *`;
  if (!rows.length) throw new ApiErr("المريض غير موجود", 404);
  return ok({ success: true, message: "تم تحديث بيانات المريض", patient: mapPatient(rows[0]) });
}
export async function opDeletePatient(id: string): Promise<R> {
  const rows = await raw`UPDATE patients SET is_deleted = TRUE, deleted_at = now(), updated_at = now() WHERE id = ${id} AND is_deleted = FALSE RETURNING id`;
  if (!rows.length) throw new ApiErr("المريض غير موجود", 404);
  return ok({ success: true, message: "تم حذف المريض" });
}

// ---- Doctors ----
export async function opListDoctors(): Promise<R> {
  const rows = await raw`SELECT * FROM doctors WHERE is_deleted = FALSE AND is_active = TRUE ORDER BY created_at DESC`;
  return ok({ success: true, doctors: rows.map(mapDoctor) });
}
export async function opGetDoctor(id: string): Promise<R> {
  const rows = await raw`SELECT * FROM doctors WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`;
  if (!rows.length) throw new ApiErr("الطبيب غير موجود", 404);
  return ok({ success: true, doctor: { ...mapDoctor(rows[0]), ...(await doctorAggregates(id)) } });
}

// ---- Services ----
export async function opListServices(): Promise<R> {
  const rows = await raw`SELECT * FROM services WHERE is_deleted = FALSE AND is_active = TRUE ORDER BY created_at DESC`;
  return ok({ success: true, services: rows.map(mapService) });
}
export async function opGetService(id: string): Promise<R> {
  const rows = await raw`SELECT * FROM services WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`;
  if (!rows.length) throw new ApiErr("الخدمة غير موجودة", 404);
  const agg = (await raw`SELECT COUNT(*)::int AS c, COALESCE(SUM(paid_amount),0)::numeric AS r, COUNT(DISTINCT doctor_id)::int AS docs FROM visits WHERE is_deleted = FALSE AND service_id = ${id}`)[0];
  return ok({ success: true, service: { ...mapService(rows[0]), visitsCount: Number(agg.c), totalRevenue: num(agg.r), doctors: [] } });
}

// ---- Appointments ----
export async function opListAppointments(q: URLSearchParams): Promise<R> {
  let sqlStr = `SELECT a.*, p.name AS patient_name, d.name AS doctor_name, s.name AS service_name FROM appointments a LEFT JOIN patients p ON p.id = a.patient_id LEFT JOIN doctors d ON d.id = a.doctor_id LEFT JOIN services s ON s.id = a.service_id WHERE a.is_deleted = FALSE`;
  const params: any[] = []; let i = 0;
  const date = q.get("date"), status = q.get("status"), doctorId = q.get("doctor");
  if (date) { params.push(date); sqlStr += ` AND a.date = $${++i}`; }
  if (status) { params.push(status); sqlStr += ` AND a.status = $${++i}`; }
  if (doctorId) { params.push(doctorId); sqlStr += ` AND a.doctor_id = $${++i}`; }
  sqlStr += ` ORDER BY a.date DESC, a.time DESC`;
  const rows = await sql()(sqlStr, params);
  return ok({ success: true, appointments: rows.map(mapAppointment) });
}
export async function opGetAppointment(id: string): Promise<R> {
  const rows = await raw`SELECT a.*, p.name AS patient_name, d.name AS doctor_name, s.name AS service_name FROM appointments a LEFT JOIN patients p ON p.id = a.patient_id LEFT JOIN doctors d ON d.id = a.doctor_id LEFT JOIN services s ON s.id = a.service_id WHERE a.id = ${id} AND a.is_deleted = FALSE LIMIT 1`;
  if (!rows.length) throw new ApiErr("الموعد غير موجود", 404);
  return ok({ success: true, appointment: mapAppointment(rows[0]) });
}
export async function opCheckAppointment(b: any): Promise<R> {
  let doctor = b?.doctorId ? await getDoctorById(b.doctorId) : null;
  if (!doctor && b?.doctorName) doctor = await findDoctorByName(b.doctorName);
  let service = b?.serviceId ? await getServiceById(b.serviceId) : null;
  if (!service && b?.serviceName) service = await findServiceByName(b.serviceName);
  if (!doctor) throw new ApiErr("الطبيب غير موجود");
  if (!service) throw new ApiErr("الخدمة غير متاحة حالياً");
  const res = await checkAvail(doctor.id, service.id, b.date, b.time);
  return ok({ success: true, available: res.available, message: res.message });
}
export async function opGetSlots(q: URLSearchParams): Promise<R> {
  const slots = await getSlots(q.get("doctorId") || "", q.get("serviceId") || "", q.get("date") || todayKey(), q.get("excludeId") || undefined);
  return ok({ success: true, slots });
}
export async function opCreateAppointment(b: any): Promise<R> {
  let doctor = (b?.doctorId ? await getDoctorById(b.doctorId) : null) || (b?.doctorName ? await findDoctorByName(b.doctorName) : null);
  if (!doctor || doctor.is_deleted) throw new ApiErr("الطبيب غير موجود");
  let service = (b?.serviceId ? await getServiceById(b.serviceId) : null) || (b?.serviceName ? await findServiceByName(b.serviceName) : null);
  if (!service || service.is_deleted) throw new ApiErr("الخدمة غير متاحة حالياً");

  // Resolve or create patient.
  let patient = (b?.patientId ? (await raw`SELECT * FROM patients WHERE id = ${b.patientId} AND is_deleted = FALSE LIMIT 1`)[0] : null)
    || (b?.phone ? await findPatientByPhone(b.phone) : null)
    || (b?.patientName ? await findPatientByName(b.patientName) : null);
  if (!patient) {
    const pname = typeof b?.patientName === "string" ? b.patientName.trim() : "";
    const pphone = typeof b?.phone === "string" ? b.phone.trim() : "";
    if (!pname || !pphone) throw new ApiErr("اسم المريض ورقم الهاتف مطلوبان");
    const pRows = await raw`INSERT INTO patients (name, phone, age, gender, notes) VALUES (${pname}, ${pphone}, 0, 'male', 'تم الإنشاء تلقائياً أثناء حجز موعد.') RETURNING *`;
    patient = pRows[0];
    await pushNotif("info", "patient", "👤 تم إنشاء ملف مريض", `تم إنشاء ملف ${patient.name} أثناء الحجز.`, patient.id);
  }

  if (!b?.date || !b?.time) throw new ApiErr("التاريخ والوقت مطلوبان");
  const avail = await checkAvail(doctor.id, service.id, b.date, b.time);
  if (!avail.available) throw new ApiErr(avail.message);

  const endTime = addMin(b.time, service.duration);
  // INSERT then RETURNING * — real read-back verification from Neon.
  const rows = await raw`INSERT INTO appointments (patient_id, doctor_id, service_id, date, time, end_time, status, notes)
    VALUES (${patient.id}, ${doctor.id}, ${service.id}, ${b.date}, ${b.time}, ${endTime}, 'confirmed', ${typeof b.notes === "string" ? b.notes.trim() : ""}) RETURNING *`;
  const created = rows[0];
  await pushNotif("success", "appointment", "📅 تم حجز موعد جديد", `موعد مع ${doctor.name} الساعة ${b.time}.`, created.id);
  await logReq("/api/appointments", "POST", 201);
  return ok({
    success: true,
    message: "تم حجز الموعد بنجاح",
    appointment: { ...mapAppointment(created), patientName: patient.name, doctorName: doctor.name, serviceName: service.name },
  }, 201);
}
export async function opUpdateAppointment(id: string, b: any): Promise<R> {
  const cur = (await raw`SELECT * FROM appointments WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`)[0];
  if (!cur) throw new ApiErr("الموعد غير موجود", 404);
  const doctorId = b.doctorId || cur.doctor_id;
  const serviceId = b.serviceId || cur.service_id;
  const date = b.date || cur.date;
  const time = b.time || cur.time;
  if (b.doctorId || b.serviceId || b.date || b.time) {
    const avail = await checkAvail(doctorId, serviceId, date, time, id);
    if (!avail.available) throw new ApiErr(avail.message);
  }
  const service = await getServiceById(serviceId);
  const endTime = addMin(time, service?.duration ?? 30);
  const rows = await raw`UPDATE appointments SET
    doctor_id = ${doctorId}, service_id = ${serviceId}, date = ${date}, time = ${time}, end_time = ${endTime},
    status = COALESCE(${b.status ?? null}, status), notes = COALESCE(${typeof b.notes === "string" ? b.notes.trim() : null}, notes),
    updated_at = now() WHERE id = ${id} RETURNING *`;
  return ok({ success: true, message: "تم تعديل الموعد بنجاح", appointment: mapAppointment(rows[0]) });
}
export async function opCancelAppointment(id: string): Promise<R> {
  const rows = await raw`UPDATE appointments SET status = 'cancelled', updated_at = now() WHERE id = ${id} AND is_deleted = FALSE RETURNING *`;
  if (!rows.length) throw new ApiErr("الموعد غير موجود", 404);
  return ok({ success: true, message: "تم إلغاء الموعد", appointment: mapAppointment(rows[0]) });
}
export async function opCompleteAppointment(id: string): Promise<R> {
  const appt = (await raw`SELECT * FROM appointments WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`)[0];
  if (!appt) throw new ApiErr("الموعد غير موجود", 404);
  const service = await getServiceById(appt.service_id);
  await raw`UPDATE appointments SET status = 'completed', updated_at = now() WHERE id = ${id}`;
  let visit = (await raw`SELECT * FROM visits WHERE appointment_id = ${id} AND is_deleted = FALSE LIMIT 1`)[0];
  if (!visit) {
    const vRows = await raw`INSERT INTO visits (patient_id, doctor_id, service_id, appointment_id, visit_date, service_price, paid_amount, remaining_amount, notes)
      VALUES (${appt.patient_id}, ${appt.doctor_id}, ${appt.service_id}, ${id}, ${appt.date}, ${num(service?.price ?? 0)}, ${num(service?.price ?? 0)}, 0, ${appt.notes || ""}) RETURNING *`;
    visit = vRows[0];
    await pushNotif("success", "visit", "🦷 تم تسجيل زيارة جديدة", "تم إكمال الموعد وتسجيل الزيارة.", visit.id);
  }
  return ok({ success: true, message: "تم إكمال الموعد وتسجيل الزيارة", appointment: mapAppointment(appt), visit: mapVisit(visit) });
}

// ---- Visits ----
export async function opListVisits(q: URLSearchParams): Promise<R> {
  let sqlStr = `SELECT v.*, p.name AS patient_name, d.name AS doctor_name, s.name AS service_name FROM visits v LEFT JOIN patients p ON p.id = v.patient_id LEFT JOIN doctors d ON d.id = v.doctor_id LEFT JOIN services s ON s.id = v.service_id WHERE v.is_deleted = FALSE`;
  const params: any[] = []; let i = 0;
  if (q.get("doctor")) { params.push(q.get("doctor")); sqlStr += ` AND v.doctor_id = $${++i}`; }
  if (q.get("service")) { params.push(q.get("service")); sqlStr += ` AND v.service_id = $${++i}`; }
  sqlStr += ` ORDER BY v.visit_date DESC`;
  const rows = await sql()(sqlStr, params);
  return ok({ success: true, visits: rows.map(mapVisit) });
}
export async function opCreateVisit(b: any): Promise<R> {
  let doctor = (b?.doctorId ? await getDoctorById(b.doctorId) : null) || (b?.doctorName ? await findDoctorByName(b.doctorName) : null);
  if (!doctor) throw new ApiErr("الطبيب غير موجود");
  let service = (b?.serviceId ? await getServiceById(b.serviceId) : null) || (b?.serviceName ? await findServiceByName(b.serviceName) : null);
  if (!service) throw new ApiErr("الخدمة غير متاحة حالياً");
  let patient = (b?.patientId ? (await raw`SELECT * FROM patients WHERE id = ${b.patientId} AND is_deleted = FALSE LIMIT 1`)[0] : null)
    || (b?.phone ? await findPatientByPhone(b.phone) : null)
    || (b?.patientName ? await findPatientByName(b.patientName) : null);
  if (!patient) {
    const pname = typeof b?.patientName === "string" ? b.patientName.trim() : "";
    const pphone = typeof b?.phone === "string" ? b.phone.trim() : "";
    if (!pname) throw new ApiErr("اسم المريض مطلوب");
    const pRows = await raw`INSERT INTO patients (name, phone, age, gender, notes) VALUES (${pname}, ${pphone}, 0, 'male', 'تم الإنشاء تلقائياً عند تسجيل زيارة.') RETURNING *`;
    patient = pRows[0];
  }
  if (!b?.visitDate) throw new ApiErr("تاريخ الزيارة مطلوب");
  const price = b.price != null ? num(b.price) : num(service.price);
  const paid = Math.min(b.paid != null ? num(b.paid) : 0, price);
  const rows = await raw`INSERT INTO visits (patient_id, doctor_id, service_id, visit_date, service_price, paid_amount, remaining_amount, diagnosis, treatment_plan, notes)
    VALUES (${patient.id}, ${doctor.id}, ${service.id}, ${b.visitDate}, ${price}, ${paid}, ${price - paid}, ${typeof b.diagnosis === "string" ? b.diagnosis.trim() : ""}, ${typeof b.treatmentPlan === "string" ? b.treatmentPlan.trim() : ""}, ${typeof b.notes === "string" ? b.notes.trim() : ""}) RETURNING *`;
  const created = rows[0];
  await pushNotif("success", "visit", "🦷 تم تسجيل زيارة جديدة", `زيارة ${service.name} للمريض ${patient.name}.`, created.id);
  await logReq("/api/visits", "POST", 201);
  return ok({ success: true, message: "تم تسجيل الزيارة بنجاح", visit: { ...mapVisit(created), patientName: patient.name, doctorName: doctor.name, serviceName: service.name } }, 201);
}
export async function opUpdateVisit(id: string, b: any): Promise<R> {
  const cur = (await raw`SELECT * FROM visits WHERE id = ${id} AND is_deleted = FALSE LIMIT 1`)[0];
  if (!cur) throw new ApiErr("الزيارة غير موجودة", 404);
  const price = b.servicePrice != null ? num(b.servicePrice) : num(cur.service_price);
  const paid = b.paidAmount != null ? Math.min(num(b.paidAmount), price) : num(cur.paid_amount);
  const rows = await raw`UPDATE visits SET
    service_price = ${price}, paid_amount = ${paid}, remaining_amount = ${price - paid},
    diagnosis = COALESCE(${typeof b.diagnosis === "string" ? b.diagnosis.trim() : null}, diagnosis),
    treatment_plan = COALESCE(${typeof b.treatmentPlan === "string" ? b.treatmentPlan.trim() : null}, treatment_plan),
    notes = COALESCE(${typeof b.notes === "string" ? b.notes.trim() : null}, notes),
    updated_at = now() WHERE id = ${id} RETURNING *`;
  return ok({ success: true, message: "تم تحديث الزيارة", visit: mapVisit(rows[0]) });
}
export async function opDeleteVisit(id: string): Promise<R> {
  const rows = await raw`UPDATE visits SET is_deleted = TRUE, deleted_at = now(), updated_at = now() WHERE id = ${id} AND is_deleted = FALSE RETURNING id`;
  if (!rows.length) throw new ApiErr("الزيارة غير موجودة", 404);
  return ok({ success: true, message: "تم حذف الزيارة" });
}

// ---- Reports (computed directly from Neon rows) ----
export async function opRevenue(period: string): Promise<R> {
  const bk = buckets(period);
  const visits = await raw`SELECT * FROM visits WHERE is_deleted = FALSE`;
  const chart = bk.map((b) => ({ label: b.label, amount: visits.filter((v: any) => { const t = parseDateKey(v.visit_date).getTime(); return t >= b.startMs && t < b.endMs; }).reduce((s: number, v: any) => s + num(v.paid_amount), 0) }));
  const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const inRange = visits.filter((v: any) => { const t = parseDateKey(v.visit_date).getTime(); return t >= start && t < end; });
  const total = inRange.reduce((s: number, v: any) => s + num(v.paid_amount), 0);
  return ok({ success: true, period, totalRevenue: total, completedVisits: inRange.length, averageVisitValue: inRange.length ? total / inRange.length : 0, chart });
}
export async function opAppointmentsReport(period: string): Promise<R> {
  const bk = buckets(period);
  const apps = await raw`SELECT * FROM appointments WHERE is_deleted = FALSE`;
  const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const inRange = apps.filter((a: any) => { const t = parseDateKey(a.date).getTime(); return t >= start && t < end; });
  const cnt = (s: string) => inRange.filter((a: any) => a.status === s).length;
  const chart = bk.map((b) => ({ label: b.label, count: apps.filter((a: any) => { const t = parseDateKey(a.date).getTime(); return t >= b.startMs && t < b.endMs; }).length }));
  return ok({ success: true, appointmentsCount: inRange.length, pending: cnt("pending"), confirmed: cnt("confirmed"), completed: cnt("completed"), cancelled: cnt("cancelled"), no_show: cnt("no_show"), chart });
}
export async function opPatientsReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const active = await raw`SELECT * FROM patients WHERE is_deleted = FALSE`;
  const visits = await raw`SELECT patient_id, COUNT(*)::int AS c FROM visits WHERE is_deleted = FALSE GROUP BY patient_id`;
  const newPatients = active.filter((p: any) => { const t = new Date(p.created_at).getTime(); return t >= start && t < end; }).length;
  const returning = visits.filter((v: any) => v.c >= 2).length;
  const chart = bk.map((b) => ({ label: b.label, count: active.filter((p: any) => { const t = new Date(p.created_at).getTime(); return t >= b.startMs && t < b.endMs; }).length }));
  return ok({ success: true, totalPatients: active.length, newPatients, returningPatients: returning, chart });
}
export async function opDoctorsReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const doctors = await raw`SELECT * FROM doctors WHERE is_deleted = FALSE AND is_active = TRUE`;
  const out = [];
  for (const d of doctors) {
    const dv = (await raw`SELECT * FROM visits WHERE is_deleted = FALSE AND doctor_id = ${d.id}`);
    const inRange = dv.filter((v: any) => { const t = parseDateKey(v.visit_date).getTime(); return t >= start && t < end; });
    const topRows = await raw`SELECT s.name, COUNT(*)::int AS c FROM visits v JOIN services s ON s.id = v.service_id WHERE v.is_deleted = FALSE AND v.doctor_id = ${d.id} GROUP BY s.name ORDER BY c DESC LIMIT 1`;
    out.push({
      id: d.id, name: d.name, specialty: d.specialty, visits: inRange.length,
      revenue: inRange.reduce((s: number, v: any) => s + num(v.paid_amount), 0),
      patients: new Set(inRange.map((v: any) => v.patient_id)).size,
      topService: topRows[0]?.name ?? "—",
    });
  }
  return ok({ success: true, doctors: out.filter((x) => x.visits > 0).sort((a, b) => b.visits - a.visits) });
}
export async function opServicesReport(period: string): Promise<R> {
  const bk = buckets(period); const start = bk[0].startMs, end = bk[bk.length - 1].endMs;
  const services = await raw`SELECT * FROM services WHERE is_deleted = FALSE AND is_active = TRUE`;
  const out = [];
  for (const s of services) {
    const sv = (await raw`SELECT * FROM visits WHERE is_deleted = FALSE AND service_id = ${s.id}`);
    const inRange = sv.filter((v: any) => { const t = parseDateKey(v.visit_date).getTime(); return t >= start && t < end; });
    if (inRange.length) out.push({ name: s.name, count: inRange.length, revenue: inRange.reduce((sum: number, v: any) => sum + num(v.paid_amount), 0) });
  }
  return ok({ success: true, services: out.sort((a, b) => b.count - a.count) });
}

// ---- Notifications ----
export async function opListNotifications(): Promise<R> {
  const rows = await raw`SELECT * FROM notifications ORDER BY created_at DESC LIMIT 80`;
  return ok({ success: true, notifications: rows.map(mapNotification) });
}
export async function opMarkRead(id: string): Promise<R> {
  await raw`UPDATE notifications SET is_read = TRUE WHERE id = ${id}`;
  return ok({ success: true, message: "تم التحديث" });
}
export async function opMarkAllRead(): Promise<R> {
  await raw`UPDATE notifications SET is_read = TRUE WHERE is_read = FALSE`;
  return ok({ success: true, message: "تم تعليم الكل كمقروء" });
}
export async function opClearNotifications(): Promise<R> {
  await raw`DELETE FROM notifications`;
  return ok({ success: true, message: "تم مسح الإشعارات" });
}
export async function opDeleteNotification(id: string): Promise<R> {
  await raw`DELETE FROM notifications WHERE id = ${id}`;
  return ok({ success: true, message: "تم الحذف" });
}

// ---- Dashboard / logs ----
export async function opDashboardStats(): Promise<R> {
  const today = todayKey();
  const p = (await raw`SELECT COUNT(*)::int AS c FROM patients WHERE is_deleted = FALSE`)[0]?.c ?? 0;
  const d = (await raw`SELECT COUNT(*)::int AS c FROM doctors WHERE is_deleted = FALSE AND is_active = TRUE`)[0]?.c ?? 0;
  const a = (await raw`SELECT COUNT(*)::int AS c FROM appointments WHERE is_deleted = FALSE AND date = ${today} AND status <> 'cancelled'`)[0]?.c ?? 0;
  const rev = (await raw`SELECT COALESCE(SUM(paid_amount),0)::numeric AS r FROM visits WHERE is_deleted = FALSE AND visit_date = ${today}`)[0]?.r ?? 0;
  return ok({ success: true, stats: { patientsCount: Number(p), doctorsCount: Number(d), todayAppointments: Number(a), todayRevenue: num(rev) } });
}
export async function opGetLogs(): Promise<R> {
  const logs = await raw`SELECT * FROM api_logs ORDER BY created_at DESC LIMIT 8`;
  const today = (await raw`SELECT COUNT(*)::int AS c FROM api_logs WHERE created_at >= now() - interval '1 day'`)[0]?.c ?? 0;
  return ok({ success: true, today: Number(today), lastUsed: logs[0]?.created_at ?? null, recent: logs });
}

// ================================ ROUTER ====================================
// Architecture: ONE serverless function per resource file. Nested paths
// (/api/appointments/:id/cancel, /api/reports/:type, ...) are collapsed into
// the resource function via vercel.json rewrites that preserve the segment as
// query params (_id, _action, _type). Each route below decides the operation
// from (method, _id, _action, _type) — the path itself is irrelevant.

type Q = Record<string, string>;
const fail = (msg: string): R => { throw new ApiErr(msg); };

async function parseBody(req: any): Promise<any> {
  if (req.body && typeof req.body === "object") return req.body;
  try {
    const txt = await new Promise<string>((resolve) => {
      let d = "";
      req.on?.("data", (c: any) => (d += c));
      req.on?.("end", () => resolve(d));
      if (!req.on) resolve("");
    });
    return txt ? JSON.parse(txt) : {};
  } catch { return {}; }
}

// Merge Vercel `req.query` with whatever is encoded in `req.url` so it works
// whether Vercel exposes the rewritten URL or the original one.
function getQuery(req: any): Q {
  const q: Q = {};
  if (req.query && typeof req.query === "object") {
    for (const k of Object.keys(req.query)) {
      const v = req.query[k];
      q[k] = Array.isArray(v) ? v[0] : v;
    }
  }
  try {
    const u = new URL(req.url || "/", "http://localhost");
    for (const [k, v] of u.searchParams) if (!(k in q)) q[k] = v;
  } catch { /* ignore */ }
  return q;
}

// Shared request lifecycle: CORS + schema bootstrap + routing + error surfacing.
export async function serve(req: any, res: any, route: (q: Q, method: string, body: any) => Promise<R>): Promise<void> {
  try {
    try {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    } catch { /* ignore header error */ }

    if ((req.method || "").toUpperCase() === "OPTIONS") {
      try { res.status(204).end(); } catch {}
      return;
    }

    const cs = getConnectionString();
    if (!cs) {
      res.status(500).json({
        success: false,
        message: "قاعدة البيانات غير مُهيأة. أضف متغير البيئة DATABASE_URL في إعدادات Vercel."
      });
      return;
    }

    await ensureSchema();
    const q = getQuery(req);
    const method = (req.method || "GET").toUpperCase();
    const body = await parseBody(req);
    const { status, data } = await route(q, method, body);

    const validStatus =
      typeof status === "number" && Number.isInteger(status) && status >= 100 && status <= 599
        ? status
        : 200;
    res.status(validStatus).json(data);
  } catch (e: any) {
    console.error("[API CRITICAL ERROR]:", e?.stack || e);
    let validStatus = 500;
    if (typeof e?.status === "number" && Number.isInteger(e.status) && e.status >= 100 && e.status <= 599) {
      validStatus = e.status;
    }
    const message = e?.message || (typeof e === "string" ? e : "Internal Server Error");
    try {
      res.status(validStatus).json({
        success: false,
        message,
        errorDetails: String(e?.stack || e)
      });
    } catch (fallbackErr) {
      console.error("[API FALLBACK ERROR]:", fallbackErr);
      try {
        res.status(500).end('{"success":false,"message":"Internal Server Error"}');
      } catch { /* ignore */ }
    }
  }
}

export async function routeHealth(): Promise<R> { return opHealth(); }

export async function routeSettings(_q: Q, method: string, body: any): Promise<R> {
  return method === "GET" ? opGetSettings() : opUpdateSettings(body);
}

export async function routePatients(q: Q, method: string, body: any): Promise<R> {
  const id = q._id; const action = q._action;
  if (action === "search") return opSearchPatients(new URLSearchParams(q));
  if (!id) return method === "GET" ? opListPatients() : method === "POST" ? opCreatePatient(body) : fail("طريقة غير مدعومة");
  if (action === "visits") return opGetPatientVisits(id);
  if (method === "GET") return opGetPatient(id);
  if (method === "PUT" || method === "POST") return opUpdatePatient(id, body);
  if (method === "DELETE") return opDeletePatient(id);
  return fail("طريقة غير مدعومة");
}

export async function routeDoctors(q: Q, method: string, body: any): Promise<R> {
  const id = q._id;
  if (!id) return method === "GET" ? opListDoctors() : method === "POST" ? opCreateDoctor(body) : fail("طريقة غير مدعومة");
  if (method === "GET") return opGetDoctor(id);
  if (method === "PUT" || method === "POST") return opUpdateDoctor(id, body);
  if (method === "DELETE") return opDeleteDoctor(id);
  return fail("طريقة غير مدعومة");
}

export async function routeServices(q: Q, method: string, body: any): Promise<R> {
  const id = q._id;
  if (!id) return method === "GET" ? opListServices() : method === "POST" ? opCreateService(body) : fail("طريقة غير مدعومة");
  if (method === "GET") return opGetService(id);
  if (method === "PUT" || method === "POST") return opUpdateService(id, body);
  if (method === "DELETE") return opDeleteService(id);
  return fail("طريقة غير مدعومة");
}

export async function routeAppointments(q: Q, method: string, body: any): Promise<R> {
  const id = q._id; const action = q._action;
  if (action === "check") return opCheckAppointment(body);
  if (action === "slots") return opGetSlots(new URLSearchParams(q));
  if (!id) return method === "GET" ? opListAppointments(new URLSearchParams(q)) : method === "POST" ? opCreateAppointment(body) : fail("طريقة غير مدعومة");
  if (action === "cancel") return opCancelAppointment(id);
  if (action === "complete") return opCompleteAppointment(id);
  if (method === "GET") return opGetAppointment(id);
  if (method === "PUT" || method === "POST") return opUpdateAppointment(id, body);
  if (method === "PATCH" || method === "DELETE") return opCancelAppointment(id);
  return fail("طريقة غير مدعومة");
}

export async function routeVisits(q: Q, method: string, body: any): Promise<R> {
  const id = q._id;
  if (!id) return method === "GET" ? opListVisits(new URLSearchParams(q)) : method === "POST" ? opCreateVisit(body) : fail("طريقة غير مدعومة");
  if (method === "PUT" || method === "POST") return opUpdateVisit(id, body);
  if (method === "DELETE") return opDeleteVisit(id);
  return fail("طريقة غير مدعومة");
}

export async function routeReports(q: Q): Promise<R> {
  const type = q._type; const period = q.period || "month";
  if (type === "revenue") return opRevenue(period);
  if (type === "appointments") return opAppointmentsReport(period);
  if (type === "patients") return opPatientsReport(period);
  if (type === "doctors") return opDoctorsReport(period);
  if (type === "services") return opServicesReport(period);
  return fail("نوع تقرير غير معروف: " + (type || "—"));
}

export async function routeDashboard(q: Q): Promise<R> {
  const type = q._type;
  if (type === "stats") return opDashboardStats();
  if (type === "logs") return opGetLogs();
  return fail("نوع لوحة غير معروف: " + (type || "—"));
}

export async function routeNotifications(q: Q, method: string, _body: any): Promise<R> {
  const id = q._id; const action = q._action;
  if (action === "read-all") return opMarkAllRead();
  if (!id) return method === "GET" ? opListNotifications() : method === "DELETE" ? opClearNotifications() : fail("طريقة غير مدعومة");
  if (action === "read") return opMarkRead(id);
  if (method === "PATCH" || method === "PUT") return opMarkRead(id);
  if (method === "DELETE") return opDeleteNotification(id);
  return fail("طريقة غير مدعومة");
}
