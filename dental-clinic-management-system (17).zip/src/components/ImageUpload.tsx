import { useRef, useState } from "react";
import { ImagePlus, Trash2, Loader2 } from "lucide-react";
import { cn } from "@/utils/cn";

const MAX_BYTES = 1_200_000; // ~1.2MB data URL budget for localStorage safety

/**
 * Uploads an image from the device, downscales it via canvas to keep it small,
 * and returns a persistent data URL (stored in the database alongside the entity).
 */
export function ImageUpload({
  value,
  onChange,
  label = "صورة",
  fallbackName,
}: {
  value?: string;
  onChange: (dataUrl: string) => void;
  label?: string;
  fallbackName: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = (file: File) => {
    setError(null);
    if (!file.type.startsWith("image/")) {
      setError("الملف يجب أن يكون صورة.");
      return;
    }
    setLoading(true);
    const reader = new FileReader();
    reader.onload = () => {
      const src = reader.result as string;
      const img = new Image();
      img.onload = () => {
        // Downscale to a max dimension and re-encode as JPEG to save space.
        const MAX = 256;
        const scale = Math.min(1, MAX / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          onChange(src.slice(0, MAX_BYTES));
          setLoading(false);
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
        onChange(dataUrl);
        setLoading(false);
      };
      img.onerror = () => {
        setError("تعذر قراءة الصورة.");
        setLoading(false);
      };
      img.src = src;
    };
    reader.onerror = () => {
      setError("تعذر تحميل الصورة.");
      setLoading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <div className="flex items-center gap-4">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 dark:border-slate-700 dark:bg-slate-800">
          {value ? (
            <img src={value} alt={label} className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-2xl">
              {fallbackName.trim().charAt(0) || "👤"}
            </div>
          )}
        </div>
        <div className="flex flex-col gap-2">
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
              e.target.value = "";
            }}
          />
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={loading}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-600 transition-colors hover:border-brand-400 hover:text-brand-600 disabled:opacity-60 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              )}
            >
              {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ImagePlus className="h-3.5 w-3.5" />}
              {loading ? "جاري الرفع..." : value ? "تغيير الصورة" : "رفع صورة"}
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange("")}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-rose-500 transition-colors hover:bg-rose-50 dark:border-slate-700 dark:hover:bg-rose-500/10"
              >
                <Trash2 className="h-3.5 w-3.5" /> حذف
              </button>
            )}
          </div>
          {error && <p className="text-xs font-medium text-rose-500">{error}</p>}
          <p className="text-[11px] text-slate-400">JPG أو PNG — يتم تخزينها فعلياً في بيانات الطبيب.</p>
        </div>
      </div>
    </div>
  );
}
