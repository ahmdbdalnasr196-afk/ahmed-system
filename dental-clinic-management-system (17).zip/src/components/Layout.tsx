import { useEffect, useMemo, useRef, useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Bell, Check, Menu, Monitor, Moon, Search, Sun, Trash2, X } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import type { AppNotification, ThemeMode } from "@/types";
import { cn } from "@/utils/cn";
import { notificationEmoji, serviceEmoji } from "@/utils/domain";
import { relativeTime } from "@/utils/format";
import { Avatar } from "@/components/ui";

const NAV = [
  { to: "/", label: "لوحة التحكم", icon: "📊", end: true },
  { to: "/patients", label: "المرضى", icon: "👥" },
  { to: "/doctors", label: "الأطباء", icon: "👨‍⚕️" },
  { to: "/services", label: "الخدمات", icon: "🦷" },
  { to: "/appointments", label: "المواعيد", icon: "📅" },
  { to: "/visits", label: "الزيارات", icon: "🩺" },
  { to: "/reports", label: "التقارير", icon: "📈" },
  { to: "/settings", label: "الإعدادات", icon: "⚙️" },
];

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { settings } = useApp();
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 px-5 py-5">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-xl shadow-lg shadow-brand-600/30">
          🦷
        </div>
        <div className="min-w-0">
          <p className="truncate font-extrabold text-slate-800 dark:text-white">
            {settings.clinicName}
          </p>
          <p className="text-xs text-slate-400">نظام إدارة العيادة</p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all",
                isActive
                  ? "bg-gradient-to-l from-brand-600 to-brand-500 text-white shadow-md shadow-brand-600/25"
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
              )
            }
          >
            <span className="text-lg">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-slate-100 px-5 py-4 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <Avatar name={settings.doctorName || settings.clinicName} size="md" src={settings.doctorImage} />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-slate-700 dark:text-slate-200">
              {settings.doctorName || "المدير"}
            </p>
            <p className="truncate text-xs text-slate-400">{settings.doctorSpecialty}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function GlobalSearch({ onNavigate }: { onNavigate?: () => void }) {
  const { globalSearch } = useApp();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const results = useMemo(() => globalSearch(q), [q, globalSearch]);
  const total = results.patients.length + results.doctors.length + results.services.length + results.appointments.length;

  const go = (path: string) => {
    navigate(path);
    setQ("");
    setOpen(false);
    onNavigate?.();
  };

  return (
    <div ref={ref} className="relative w-full max-w-md">
      <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        value={q}
        onChange={(e) => {
          setQ(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder="بحث شامل: مريض، طبيب، خدمة، موعد..."
        className="w-full rounded-xl border border-slate-200 bg-slate-50/80 py-2.5 pr-10 pl-3 text-sm text-slate-800 transition-colors placeholder:text-slate-400 focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500/20 dark:border-slate-700 dark:bg-slate-800/60 dark:text-slate-100"
      />
      {open && q.trim() && (
        <div className="absolute top-full z-50 mt-2 max-h-96 w-full overflow-y-auto rounded-2xl border border-slate-200 bg-white p-2 shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
          {total === 0 ? (
            <p className="px-3 py-6 text-center text-sm text-slate-400">لا توجد نتائج مطابقة</p>
          ) : (
            <>
              {results.patients.length > 0 && (
                <SearchGroup title="المرضى">
                  {results.patients.map((p) => (
                    <ResultRow key={p.id} emoji="👤" title={p.name} subtitle={p.phone} onClick={() => go(`/patients/${p.id}`)} />
                  ))}
                </SearchGroup>
              )}
              {results.doctors.length > 0 && (
                <SearchGroup title="الأطباء">
                  {results.doctors.map((d) => (
                    <ResultRow key={d.id} emoji="👨‍⚕️" title={d.name} subtitle={d.specialty} onClick={() => go(`/doctors/${d.id}`)} />
                  ))}
                </SearchGroup>
              )}
              {results.services.length > 0 && (
                <SearchGroup title="الخدمات">
                  {results.services.map((s) => (
                    <ResultRow key={s.id} emoji={serviceEmoji(s.name)} title={s.name} subtitle={`${s.price} ج.م`} onClick={() => go(`/services`)} />
                  ))}
                </SearchGroup>
              )}
              {results.appointments.length > 0 && (
                <SearchGroup title="المواعيد">
                  {results.appointments.map((a) => (
                    <ResultRow key={a.id} emoji="📅" title={`موعد ${a.date}`} subtitle={`الساعة ${a.time}`} onClick={() => go(`/appointments`)} />
                  ))}
                </SearchGroup>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

function SearchGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-1">
      <p className="px-3 py-1 text-[11px] font-bold uppercase text-slate-400">{title}</p>
      {children}
    </div>
  );
}

function ResultRow({
  emoji,
  title,
  subtitle,
  onClick,
}: {
  emoji: string;
  title: string;
  subtitle: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-right transition-colors hover:bg-slate-100 dark:hover:bg-slate-800"
    >
      <span className="text-lg">{emoji}</span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">{title}</p>
        <p className="truncate text-xs text-slate-400">{subtitle}</p>
      </div>
    </button>
  );
}

const THEME_OPTIONS: { value: ThemeMode; label: string; icon: typeof Sun }[] = [
  { value: "light", label: "فاتح", icon: Sun },
  { value: "dark", label: "داكن", icon: Moon },
  { value: "system", label: "النظام", icon: Monitor },
];

function ThemeMenu() {
  const { theme, setTheme } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  const Active = theme === "light" ? Sun : theme === "dark" ? Moon : Monitor;
  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:text-brand-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
      >
        <Active className="h-5 w-5" />
      </button>
      {open && (
        <div className="absolute top-full left-0 z-50 mt-2 w-40 rounded-xl border border-slate-200 bg-white p-1 shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
          {THEME_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => {
                setTheme(opt.value);
                setOpen(false);
              }}
              className={cn(
                "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-colors",
                theme === opt.value
                  ? "bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                  : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              )}
            >
              <opt.icon className="h-4 w-4" />
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function NotificationBell() {
  const { data, markNotificationRead, markAllRead, clearNotifications } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const all = useMemo(
    () =>
      [...data.notifications].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1)),
    [data.notifications]
  );
  const unread = all.filter((n) => !n.isRead).length;

  const routeFor = (n: AppNotification): string => {
    if (n.relatedType === "patient") return n.relatedId ? `/patients/${n.relatedId}` : "/patients";
    if (n.relatedType === "doctor") return n.relatedId ? `/doctors/${n.relatedId}` : "/doctors";
    if (n.relatedType === "appointment") return "/appointments";
    if (n.relatedType === "visit") return "/visits";
    if (n.relatedType === "service") return "/services";
    return "/";
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition-colors hover:text-brand-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white shadow animate-scale-in">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute top-full left-0 z-50 mt-2 w-80 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl animate-slide-down dark:border-slate-700 dark:bg-slate-900 sm:w-96">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3 dark:border-slate-800">
            <h3 className="font-bold text-slate-800 dark:text-white">🔔 الإشعارات</h3>
            <div className="flex items-center gap-1">
              <button
                onClick={markAllRead}
                title="تعليم الكل كمقروء"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-emerald-600 dark:hover:bg-slate-800"
              >
                <Check className="h-4 w-4" />
              </button>
              <button
                onClick={clearNotifications}
                title="مسح الإشعارات"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-rose-600 dark:hover:bg-slate-800"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {all.length === 0 ? (
              <p className="px-4 py-10 text-center text-sm text-slate-400">لا توجد إشعارات</p>
            ) : (
              all.map((n) => (
                <button
                  key={n.id}
                  onClick={() => {
                    if (!n.isRead) markNotificationRead(n.id);
                    navigate(routeFor(n));
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full gap-3 border-b border-slate-50 px-4 py-3 text-right transition-colors hover:bg-slate-50 dark:border-slate-800/60 dark:hover:bg-slate-800/50",
                    !n.isRead && "bg-brand-50/40 dark:bg-brand-500/5"
                  )}
                >
                  <span className="mt-0.5 text-base">{notificationEmoji(n)}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{n.title}</p>
                    <p className="truncate text-xs text-slate-400">{n.message}</p>
                    <p className="mt-0.5 text-[11px] text-slate-300">{relativeTime(n.createdAt)}</p>
                  </div>
                  {!n.isRead && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-brand-500" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ToastHost() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="fixed bottom-4 left-4 z-[70] flex w-full max-w-sm flex-col gap-2">
      {toasts.map((t) => (
        <ToastItem key={t.id} id={t.id} type={t.type} message={t.message} onDismiss={dismissToast} />
      ))}
    </div>
  );
}

function ToastItem({
  id,
  type,
  message,
  onDismiss,
}: {
  id: string;
  type: "success" | "warning" | "error" | "info";
  message: string;
  onDismiss: (id: string) => void;
}) {
  const timer = useRef<number | null>(null);
  const remaining = useRef(4000);
  const start = useRef(Date.now());

  useEffect(() => {
    start.current = Date.now();
    timer.current = window.setTimeout(() => onDismiss(id), remaining.current);
    return () => {
      if (timer.current) {
        remaining.current -= Date.now() - start.current;
        clearTimeout(timer.current);
      }
    };
  }, [id, onDismiss]);

  const styles = {
    success: "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300",
    warning: "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300",
    error: "border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300",
    info: "border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-500/30 dark:bg-blue-500/10 dark:text-blue-300",
  };
  const icon = { success: "🟢", warning: "🟡", error: "🔴", info: "🔵" }[type];

  return (
    <div
      onMouseEnter={() => timer.current && clearTimeout(timer.current)}
      onMouseLeave={() => {
        start.current = Date.now();
        timer.current = window.setTimeout(() => onDismiss(id), remaining.current);
      }}
      className={cn(
        "flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold shadow-lg backdrop-blur animate-slide-in-left",
        styles[type]
      )}
    >
      <span>{icon}</span>
      <span className="flex-1">{message}</span>
      <button onClick={() => onDismiss(id)} className="opacity-60 hover:opacity-100">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

function NotificationPopup() {
  const { popupNotification, dismissPopup } = useApp();
  const navigate = useNavigate();
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (!popupNotification) return;
    timer.current = window.setTimeout(dismissPopup, 7000);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [popupNotification, dismissPopup]);

  if (!popupNotification) return null;
  const n = popupNotification;

  const routeFor = (n: AppNotification): string => {
    if (n.relatedType === "patient") return n.relatedId ? `/patients/${n.relatedId}` : "/patients";
    if (n.relatedType === "doctor") return n.relatedId ? `/doctors/${n.relatedId}` : "/doctors";
    if (n.relatedType === "appointment") return "/appointments";
    if (n.relatedType === "visit") return "/visits";
    return "/";
  };

  const bar = {
    success: "bg-emerald-500",
    warning: "bg-amber-500",
    error: "bg-rose-500",
    info: "bg-blue-500",
  }[n.type];

  return (
    <div className="fixed left-1/2 top-5 z-[75] w-[min(92vw,26rem)] -translate-x-1/2">
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl animate-slide-down dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-start gap-3 p-4">
          <span className="text-xl">{notificationEmoji(n)}</span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-slate-800 dark:text-white">{n.title}</p>
            <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">{n.message}</p>
            <button
              onClick={() => {
                navigate(routeFor(n));
                dismissPopup();
              }}
              className="mt-2 text-xs font-bold text-brand-600 hover:text-brand-700 dark:text-brand-400"
            >
              عرض التفاصيل ←
            </button>
          </div>
          <button onClick={dismissPopup} className="text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="h-1 w-full bg-slate-100 dark:bg-slate-800">
          <div className={cn("h-full w-full origin-right animate-[shrink_7s_linear]", bar)} style={{ animation: "shrink 7s linear forwards" }} />
        </div>
      </div>
    </div>
  );
}

export default function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <div className="flex min-h-screen bg-slate-100 dark:bg-slate-950">
      {/* Sidebar - desktop */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-l border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 lg:block">
        <SidebarContent />
      </aside>

      {/* Sidebar - mobile */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in" onClick={() => setMobileOpen(false)} />
          <aside className="absolute right-0 top-0 h-full w-72 border-l border-slate-200 bg-white shadow-2xl animate-slide-in-left dark:border-slate-800 dark:bg-slate-900">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute left-3 top-4 rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>
            <SidebarContent onNavigate={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/80 sm:px-6">
          <button
            onClick={() => setMobileOpen(true)}
            className="rounded-xl border border-slate-200 p-2 text-slate-500 lg:hidden dark:border-slate-700"
          >
            <Menu className="h-5 w-5" />
          </button>
          <GlobalSearch onNavigate={() => setMobileOpen(false)} />
          <div className="mr-auto flex items-center gap-2">
            <ThemeMenu />
            <NotificationBell />
          </div>
        </header>

        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-7xl">
            <Outlet />
          </div>
        </main>
      </div>

      <ToastHost />
      <NotificationPopup />
    </div>
  );
}
