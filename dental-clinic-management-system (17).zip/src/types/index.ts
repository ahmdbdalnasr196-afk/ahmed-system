// Domain entity types for the Dental Clinic Management System.
// These mirror the database tables described in the architecture spec.

export type ID = string;

export type Gender = "male" | "female";

export type WeekDay =
  | "saturday"
  | "sunday"
  | "monday"
  | "tuesday"
  | "wednesday"
  | "thursday"
  | "friday";

export interface Patient {
  id: ID;
  name: string;
  phone: string;
  age: number;
  gender: Gender;
  address?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted: boolean;
  deletedAt: string | null;
}

export interface Doctor {
  id: ID;
  name: string;
  image?: string;
  specialty: string;
  phone?: string;
  description?: string;
  workingDays: WeekDay[];
  workingFrom: string; // HH:mm (24h internal)
  workingTo: string; // HH:mm (24h internal)
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
  isDeleted: boolean;
  deletedAt: string | null;
}

export interface Service {
  id: ID;
  name: string;
  avatar?: string;
  price: number;
  duration: number; // minutes
  description?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  isDeleted: boolean;
  deletedAt: string | null;
}

export type AppointmentStatus =
  | "pending"
  | "confirmed"
  | "completed"
  | "cancelled"
  | "no_show";

export interface Appointment {
  id: ID;
  patientId: ID;
  doctorId: ID;
  serviceId: ID;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm start
  endTime: string; // HH:mm end (computed from service duration)
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted: boolean;
  deletedAt: string | null;
}

export interface Visit {
  id: ID;
  patientId: ID;
  doctorId: ID;
  serviceId: ID;
  appointmentId?: ID;
  visitDate: string; // YYYY-MM-DD
  servicePrice: number;
  paidAmount: number;
  remainingAmount: number;
  diagnosis?: string;
  treatmentPlan?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted: boolean;
  deletedAt: string | null;
}

export type NotificationType = "success" | "warning" | "error" | "info";

export type RelatedType =
  | "appointment"
  | "patient"
  | "visit"
  | "doctor"
  | "service"
  | "system";

// Rich categorization used for notification icons & filtering.
export type NotificationCategory =
  | "appointment"
  | "visit"
  | "patient"
  | "doctor"
  | "service"
  | "settings"
  | "reminder"
  | "warning"
  | "success"
  | "error";

export interface AppNotification {
  id: ID;
  title: string;
  message: string;
  type: NotificationType;
  relatedType: RelatedType;
  relatedId?: ID;
  isRead: boolean;
  createdAt: string;
  category?: NotificationCategory;
  key?: string; // stable idempotency key for system-generated notifications
}

export interface PatientSearchResult {
  id: ID;
  name: string;
  phone: string;
  age: number;
  gender: Gender;
  visitsCount: number;
  lastVisit: string | null;
}

export type ThemeMode = "light" | "dark" | "system";

export interface Settings {
  id: ID;
  clinicName: string;
  clinicLogo?: string;
  clinicPhone?: string;
  clinicAddress?: string;
  clinicEmail?: string;
  doctorName?: string;
  doctorImage?: string;
  doctorSpecialty?: string;
  workingDays: WeekDay[];
  workingFrom: string; // HH:mm
  workingTo: string; // HH:mm
  currency: "EGP";
  theme: ThemeMode;
  notificationsEnabled: boolean;
  notificationTypes: {
    newAppointment: boolean;
    newPatient: boolean;
    visitAdded: boolean;
    appointmentReminder: boolean;
  };
  updatedAt: string;
}

export interface ApiLog {
  id: ID;
  endpoint: string;
  method: string;
  statusCode: number;
  responseTime: number;
  createdAt: string;
}

export interface Database {
  patients: Patient[];
  doctors: Doctor[];
  services: Service[];
  appointments: Appointment[];
  visits: Visit[];
  notifications: AppNotification[];
  settings: Settings;
  apiLogs: ApiLog[];
}

export type ReportPeriod = "week" | "month" | "3months" | "6months" | "year";

export interface ChartPoint {
  label: string;
  amount: number;
  count?: number;
}
