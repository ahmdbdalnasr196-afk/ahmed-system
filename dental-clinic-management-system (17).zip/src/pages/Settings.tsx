import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, CheckCircle2, Globe, Save } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/contexts/AppContext";
import { useAsync } from "@/hooks";
import type { ThemeMode, WeekDay } from "@/types";
import { Button, Card, CardHeader, Field, Input } from "@/components/ui";
import { TimePicker } from "@/components/TimePicker";
import { ImageUpload } from "@/components/ImageUpload";
import { DAY_OPTIONS } from "@/utils/domain";
import { relativeTime } from "@/utils/format";
import { cn } from "@/utils/cn";

const BASE_URL =
  typeof window !== "undefined" ? `${window.location.origin}/api` : "/api";

interface FormState {
  clinicName: string;
  clinicLogo: string;
  clinicAddress: string;
  clinicPhone: string;
  clinicEmail: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorImage: string;
  workingFrom: string;
  workingTo: string;
  workingDays: WeekDay[];
  notificationsEnabled: boolean;
  notificationTypes: { newAppointment: boolean; newPatient: boolean; visitAdded: boolean; appointmentReminder: boolean };
}

export default function Settings() {
  const { settings, updateSettings, theme, setTheme, toast } = useApp();
  const [form, setForm] = useState<FormState>(() => ({
    clinicName: settings.clinicName,
    clinicLogo: settings.clinicLogo ?? "",
    clinicAddress: settings.clinicAddress ?? "",
    clinicPhone: settings.clinicPhone ?? "",
    clinicEmail: settings.clinicEmail ?? "",
    doctorName: settings.doctorName ?? "",
    doctorSpecialty: settings.doctorSpecialty ?? "",
    doctorImage: settings.doctorImage ?? "",
    workingFrom: settings.workingFrom,
    workingTo: settings.workingTo,
    workingDays: settings.workingDays,
    notificationsEnabled: settings.notificationsEnabled,
    notificationTypes: { ...settings.notificationTypes },
  }));
  const lastSaved = useRef(JSON.stringify(form));
  const [saving, setSaving] = useState(false);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  // Auto-save (debounced)
  useEffect(() => {
    const cur = JSON.stringify(form);
    if (cur === lastSaved.current) return;
    setSaving(true);
    const t = setTimeout(() => {
      updateSettings({
        clinicName: form.clinicName,
        clinicLogo: form.clinicLogo,
        clinicAddress: form.clinicAddress,
        clinicPhone: form.clinicPhone,
        clinicEmail: form.clinicEmail,
        doctorName: form.doctorName,
        doctorSpecialty: form.doctorSpecialty,
        doctorImage: form.doctorImage,
        workingFrom: form.workingFrom,
        workingTo: form.workingTo,
        workingDays: form.workingDays,
        notificationsEnabled: form.notificationsEnabled,
        notificationTypes: form.notificationTypes,
      }).finally(() => {
        lastSaved.current = cur;
        setSaving(false);
      });
    }, 600);
    return () => clearTimeout(t);
  }, [form, updateSettings]);

  // API monitoring
  const health = useAsync(() => api.health(), []);
  const { data, refresh } = useApp();
  const logs = useAsync(() => api.getApiLogs(), [data.apiLogs]);
  const [testing, setTesting] = useState(false);

  const [apiLive, setApiLive] = useState<boolean | null>(null);

  const testApi = async () => {
    setTesting(true);
    try {
      const res = await fetch(`${BASE_URL}/health`, { method: "GET" });
      const json = await res.json().catch(() => ({} as any));
      if (res.ok && json?.success) {
        setApiLive(true);
        toast("success", `🟢 الاتصال بالـ API يعمل بنجاح (${json.storage === "vercel-kv" ? "Vercel KV" : "ذاكرة"})`);
      } else {
        setApiLive(false);
        toast("error", "🔴 فشل الاتصال بالـ API");
      }
      refresh();
    } catch {
      setApiLive(false);
      toast("error", "🔴 فشل الاتصال بالـ API");
    } finally {
      setTesting(false);
    }
  };

  const toggleDay = (d: WeekDay) =>
    set("workingDays", form.workingDays.includes(d) ? form.workingDays.filter((x) => x !== d) : [...form.workingDays, d]);

  const notifTypes = useMemo(
    () =>
      [
        { key: "newAppointment" as const, label: "موعد جديد" },
        { key: "newPatient" as const, label: "مريض جديد" },
        { key: "visitAdded" as const, label: "زيارة جديدة" },
        { key: "appointmentReminder" as const, label: "تذكير المواعيد" },
      ],
    []
  );

  const themeOptions: { value: ThemeMode; label: string }[] = [
    { value: "light", label: "☀️ فاتح" },
    { value: "dark", label: "🌙 داكن" },
    { value: "system", label: "💻 النظام" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">⚙️ الإعدادات</h1>
          <p className="text-sm text-slate-400">إدارة بيانات العيادة وسلوك النظام</p>
        </div>
        {saving && (
          <span className="flex items-center gap-1.5 text-xs font-semibold text-brand-600">
            <Save className="h-3.5 w-3.5 animate-soft-pulse" /> جاري الحفظ...
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Clinic info */}
        <Card>
          <CardHeader title="🏥 بيانات العيادة" icon="🏥" />
          <div className="space-y-4 p-5">
            <Field label="اسم العيادة" required>
              <Input value={form.clinicName} onChange={(e) => set("clinicName", e.target.value)} />
            </Field>
            <Field label="رابط الشعار / الصورة">
              <Input value={form.clinicLogo} onChange={(e) => set("clinicLogo", e.target.value)} placeholder="https://..." dir="ltr" />
            </Field>
            <Field label="العنوان">
              <Input value={form.clinicAddress} onChange={(e) => set("clinicAddress", e.target.value)} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="رقم الهاتف">
                <Input value={form.clinicPhone} onChange={(e) => set("clinicPhone", e.target.value)} dir="ltr" />
              </Field>
              <Field label="البريد الإلكتروني">
                <Input value={form.clinicEmail} onChange={(e) => set("clinicEmail", e.target.value)} dir="ltr" />
              </Field>
            </div>
          </div>
        </Card>

        {/* Doctor info */}
        <Card>
          <CardHeader title="👨‍⚕️ بيانات الطبيب" icon="👨‍⚕️" />
          <div className="space-y-4 p-5">
            <Field label="اسم الطبيب">
              <Input value={form.doctorName} onChange={(e) => set("doctorName", e.target.value)} />
            </Field>
            <Field label="التخصص">
              <Input value={form.doctorSpecialty} onChange={(e) => set("doctorSpecialty", e.target.value)} />
            </Field>
            <Field label="صورة الطبيب">
              <ImageUpload
                value={form.doctorImage}
                onChange={(url) => set("doctorImage", url)}
                fallbackName={form.doctorName}
              />
            </Field>
          </div>
        </Card>

        {/* Working hours */}
        <Card>
          <CardHeader title="⏰ مواعيد عمل العيادة" icon="⏰" />
          <div className="space-y-4 p-5">
            <div className="grid grid-cols-2 gap-3">
              <Field label="بداية العمل">
                <TimePicker value={form.workingFrom} onChange={(v) => set("workingFrom", v)} />
              </Field>
              <Field label="نهاية العمل">
                <TimePicker value={form.workingTo} onChange={(v) => set("workingTo", v)} />
              </Field>
            </div>
            <Field label="أيام العمل" required>
              <div className="flex flex-wrap gap-2">
                {DAY_OPTIONS.map((d) => (
                  <button
                    key={d.value}
                    type="button"
                    onClick={() => toggleDay(d.value)}
                    className={cn(
                      "rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
                      form.workingDays.includes(d.value)
                        ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                        : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-slate-700"
                    )}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
            </Field>
            <div className="rounded-xl bg-brand-50 px-4 py-3 text-sm text-brand-700 dark:bg-brand-500/10 dark:text-brand-300">
              💵 العملة المستخدمة في النظام: <b>الجنيه المصري (ج.م)</b>
            </div>
          </div>
        </Card>

        {/* Appearance + Notifications */}
        <Card>
          <CardHeader title="🎨 المظهر والإشعارات" icon="🎨" />
          <div className="space-y-4 p-5">
            <Field label="المظهر">
              <div className="grid grid-cols-3 gap-2">
                {themeOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setTheme(opt.value)}
                    className={cn(
                      "rounded-xl border px-3 py-3 text-sm font-semibold transition-all",
                      theme === opt.value
                        ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                        : "border-slate-200 text-slate-500 hover:border-slate-300 dark:border-slate-700"
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </Field>
            <div className="flex items-center justify-between rounded-xl border border-slate-100 px-4 py-3 dark:border-slate-800">
              <div>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">🔔 تفعيل الإشعارات الذكية</p>
                <p className="text-xs text-slate-400">إظهار لوحة الإشعارات المنبثقة</p>
              </div>
              <Switch checked={form.notificationsEnabled} onChange={(v) => set("notificationsEnabled", v)} />
            </div>
            <div className={cn("space-y-2 transition-opacity", !form.notificationsEnabled && "pointer-events-none opacity-40")}>
              <p className="text-xs font-bold text-slate-400">أنواع الإشعارات</p>
              {notifTypes.map((t) => (
                <div key={t.key} className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-2 dark:bg-slate-800/50">
                  <span className="text-sm text-slate-600 dark:text-slate-300">{t.label}</span>
                  <Switch
                    checked={form.notificationTypes[t.key]}
                    onChange={(v) => set("notificationTypes", { ...form.notificationTypes, [t.key]: v })}
                  />
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* API & integrations */}
      <Card>
        <CardHeader title="🔗 API والتكاملات" icon="🔗" subtitle="حالة الاتصال ومراقبة الطلبات" />
        <div className="grid grid-cols-1 gap-4 p-5 lg:grid-cols-3">
          <div className="space-y-3 lg:col-span-1">
            <Field label="Base API URL">
              <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-semibold text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                <Globe className="h-4 w-4 text-brand-500" />
                <span dir="ltr">{BASE_URL}</span>
              </div>
            </Field>
            <div className="flex items-center gap-2 rounded-xl border border-slate-100 px-4 py-3 dark:border-slate-800">
              {apiLive === null ? (
                <span className="text-sm font-semibold text-slate-400">اضغط «اختبار الاتصال» للتحقق</span>
              ) : apiLive ? (
                <>
                  <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-soft-pulse" />
                  <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">🟢 متصل (REST API يعمل)</span>
                </>
              ) : (
                <>
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-500" />
                  <span className="text-sm font-bold text-rose-600">🔴 غير متصل</span>
                </>
              )}
            </div>
            <p className="rounded-lg bg-slate-50 px-3 py-2 text-[11px] leading-relaxed text-slate-400 dark:bg-slate-800/50">
              الـ REST API متاح على نفس الرابط فوق (مثل <span dir="ltr" className="text-brand-600">/api/patients</span>، <span dir="ltr" className="text-brand-600">/api/appointments</span>). لمزامنة البيانات بين كل الأجهزة فعّل Vercel KV وأضف متغيرات البيئة <span dir="ltr" className="font-mono">KV_REST_API_URL</span> و <span dir="ltr" className="font-mono">KV_REST_API_TOKEN</span>.
            </p>
            <Button className="w-full" variant="secondary" loading={testing} onClick={testApi}>
              <Activity className="h-4 w-4" /> اختبار الاتصال
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:col-span-2">
            <MetricCard
              icon={<CheckCircle2 className="h-5 w-5" />}
              tint="bg-emerald-500"
              label="حالة قاعدة البيانات"
              value={health.data?.database === "connected" ? "متصل" : "..."}
            />
            <MetricCard icon={<Activity className="h-5 w-5" />} tint="bg-brand-500" label="عدد الطلبات اليوم" value={logs.data ? `${logs.data.today} طلب` : "..."} />
            <MetricCard icon={<Globe className="h-5 w-5" />} tint="bg-violet-500" label="آخر استخدام للـ API" value={logs.data?.lastUsed ? relativeTime(logs.data.lastUsed) : "..."} />
            <MetricCard icon={<Activity className="h-5 w-5" />} tint="bg-amber-500" label="حالة الـ API" value={health.data?.api === "connected" ? "يعمل" : "..."} />
          </div>
        </div>
      </Card>
    </div>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", checked ? "bg-brand-600" : "bg-slate-300 dark:bg-slate-600")}
    >
      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "left-0.5" : "right-0.5")} />
    </button>
  );
}

function MetricCard({ icon, tint, label, value }: { icon: React.ReactNode; tint: string; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-slate-100 p-4 dark:border-slate-800">
      <div className={cn("flex h-10 w-10 items-center justify-center rounded-lg text-white", tint)}>{icon}</div>
      <div>
        <p className="text-xs text-slate-400">{label}</p>
        <p className="font-bold text-slate-700 dark:text-slate-200">{value}</p>
      </div>
    </div>
  );
}
