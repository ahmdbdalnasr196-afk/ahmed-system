import { useEffect, useMemo, useState } from "react";
import { Eye, Pencil, Plus, RefreshCw, Trash2, Clock, DollarSign } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import type { Service } from "@/types";
import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Pagination,
  SearchInput,
  Select,
  Skeleton,
  Textarea,
} from "@/components/ui";
import { serviceEmoji } from "@/utils/domain";
import { avatarGradient } from "@/utils/domain";
import { formatCurrency, formatNumber } from "@/utils/format";

export default function Services() {
  const { data, createService, updateService, deleteService } = useApp();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [priceRange, setPriceRange] = useState("all");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(12);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [viewing, setViewing] = useState<Service | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const usage = useMemo(() => {
    const m = new Map<string, number>();
    data.visits.filter((v) => !v.isDeleted).forEach((v) => m.set(v.serviceId, (m.get(v.serviceId) ?? 0) + 1));
    return m;
  }, [data.visits]);

  const revenue = useMemo(() => {
    const m = new Map<string, number>();
    data.visits.filter((v) => !v.isDeleted).forEach((v) => m.set(v.serviceId, (m.get(v.serviceId) ?? 0) + v.paidAmount));
    return m;
  }, [data.visits]);

  const doctorsFor = useMemo(() => {
    const m = new Map<string, Set<string>>();
    data.visits.filter((v) => !v.isDeleted).forEach((v) => {
      const s = m.get(v.serviceId) ?? new Set<string>();
      s.add(v.doctorId);
      m.set(v.serviceId, s);
    });
    return m;
  }, [data.visits]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return data.services.filter((s) => {
      if (s.isDeleted || !s.isActive) return false;
      if (q && !s.name.toLowerCase().includes(q)) return false;
      if (priceRange === "lt500" && s.price >= 500) return false;
      if (priceRange === "500-1500" && (s.price < 500 || s.price > 1500)) return false;
      if (priceRange === "gt1500" && s.price <= 1500) return false;
      return true;
    });
  }, [data.services, query, priceRange]);

  useEffect(() => setPage(1), [query, priceRange, pageSize]);
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader
        title="🦷 الخدمات"
        subtitle={`${data.services.filter((s) => !s.isDeleted && s.isActive).length} خدمة متاحة`}
        actions={
          <>
            <Button variant="secondary" loading={refreshing} onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 600); }}>
              <RefreshCw className="h-4 w-4" /> تحديث
            </Button>
            <Button onClick={() => { setEditing(null); setModalOpen(true); }}>
              <Plus className="h-4 w-4" /> إضافة خدمة
            </Button>
          </>
        }
      />

      <Card className="mb-4 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <SearchInput value={query} onChange={setQuery} placeholder="بحث باسم الخدمة..." className="flex-1" />
          <Select value={priceRange} onChange={(e) => setPriceRange(e.target.value)} className="w-auto">
            <option value="all">كل الأسعار</option>
            <option value="lt500">أقل من 500</option>
            <option value="500-1500">500 - 1500</option>
            <option value="gt1500">أكثر من 1500</option>
          </Select>
        </div>
      </Card>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44 w-full" />)}
        </div>
      ) : rows.length === 0 ? (
        <Card>
          <EmptyState emoji="🦷" title="لا توجد خدمات حتى الآن" description="ابدأ بإضافة أول خدمة." action={<Button onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> إضافة خدمة</Button>} />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {pageRows.map((s) => (
            <Card key={s.id} className="group p-5 transition-all hover:-translate-y-1 hover:shadow-lg">
              <div className="flex items-start gap-3">
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br text-2xl ${avatarGradient(s.name)}`}>
                  {serviceEmoji(s.name)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold text-slate-800 dark:text-white">{s.name}</p>
                  <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-400">
                    <Clock className="h-3 w-3" /> {s.duration} دقيقة
                  </p>
                </div>
                <span className="rounded-lg bg-emerald-50 px-2 py-1 text-xs font-bold text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-300">
                  نشطة
                </span>
              </div>
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <p className="text-2xl font-extrabold text-brand-600 dark:text-brand-400">{formatNumber(s.price)}</p>
                  <p className="text-xs text-slate-400">ج.م</p>
                </div>
                <div className="text-left text-xs text-slate-400">
                  <p><b className="text-slate-600 dark:text-slate-300">{usage.get(s.id) ?? 0}</b> مرة استخدام</p>
                  <p><b className="text-slate-600 dark:text-slate-300">{doctorsFor.get(s.id)?.size ?? 0}</b> أطباء</p>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-1 border-t border-slate-100 pt-3 dark:border-slate-800">
                <IconBtn title="عرض" onClick={() => setViewing(s)}><Eye className="h-4 w-4" /></IconBtn>
                <IconBtn title="تعديل" onClick={() => { setEditing(s); setModalOpen(true); }}><Pencil className="h-4 w-4" /></IconBtn>
                <IconBtn title="حذف" danger onClick={() => setDeleteId(s.id)}><Trash2 className="h-4 w-4" /></IconBtn>
              </div>
            </Card>
          ))}
        </div>
      )}

      {!loading && rows.length > 0 && (
        <Card className="mt-4">
          <Pagination page={page} pageCount={pageCount} total={rows.length} pageSize={pageSize} onPage={setPage} onPageSize={setPageSize} />
        </Card>
      )}

      <ServiceModal
        open={modalOpen}
        service={editing}
        onClose={() => setModalOpen(false)}
        onSubmit={async (values) => {
          if (editing) await updateService(editing.id, values);
          else await createService(values);
        }}
      />

      <ServiceDetail
        open={!!viewing}
        service={viewing}
        usage={viewing ? usage.get(viewing.id) ?? 0 : 0}
        revenue={viewing ? revenue.get(viewing.id) ?? 0 : 0}
        doctorCount={viewing ? doctorsFor.get(viewing.id)?.size ?? 0 : 0}
        doctorNames={viewing ? [...(doctorsFor.get(viewing.id) ?? [])].map((id) => data.doctors.find((d) => d.id === id)?.name).filter(Boolean) as string[] : []}
        onClose={() => setViewing(null)}
      />

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        danger
        message="هل أنت متأكد من حذف هذه الخدمة؟ سيتم إخفاؤها مع الاحتفاظ بالزيارات السابقة."
        onConfirm={async () => { if (deleteId) await deleteService(deleteId); setDeleteId(null); }}
      />
    </div>
  );
}

function IconBtn({ children, onClick, title, danger }: { children: React.ReactNode; onClick: () => void; title: string; danger?: boolean }) {
  return (
    <button title={title} onClick={onClick} className={`rounded-lg p-2 transition-colors ${danger ? "text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/15" : "text-slate-400 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-brand-500/15"}`}>
      {children}
    </button>
  );
}

function ServiceModal({ open, service, onClose, onSubmit }: { open: boolean; service: Service | null; onClose: () => void; onSubmit: (values: any) => Promise<void> }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [duration, setDuration] = useState("");
  const [description, setDescription] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(service?.name ?? "");
      setPrice(service ? String(service.price) : "");
      setDuration(service ? String(service.duration) : "");
      setDescription(service?.description ?? "");
      setErrors({});
      setFormError(null);
    }
  }, [open, service]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (name.trim().length < 2) e.name = "اسم الخدمة يجب أن يكون حرفين على الأقل";
    else if (name.trim().length > 100) e.name = "الاسم طويل جداً";
    const p = Number(price);
    if (!price || isNaN(p)) e.price = "السعر مطلوب";
    else if (p < 0) e.price = "السعر لا يمكن أن يكون سالباً";
    const d = Number(duration);
    if (!duration || isNaN(d)) e.duration = "المدة مطلوبة";
    else if (d < 5) e.duration = "المدة غير صحيحة";
    if (description.length > 500) e.description = "الوصف طويل جداً";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    setSubmitting(true);
    setFormError(null);
    try {
      await onSubmit({ name: name.trim(), price: Number(price), duration: Number(duration), description: description.trim() });
      onClose();
    } catch {
      setFormError("تعذر حفظ الخدمة. حاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={service ? "تعديل الخدمة" : "إضافة خدمة جديدة"}>
      <div className="space-y-4">
        <Field label="اسم الخدمة" required error={errors.name}>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="تنظيف الأسنان" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="السعر (ج.م)" required error={errors.price}>
            <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="500" />
          </Field>
          <Field label="المدة (دقيقة)" required error={errors.duration}>
            <Input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="45" />
          </Field>
        </div>
        <Field label="وصف الخدمة" error={errors.description}>
          <Textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="وصف مختصر للخدمة..." />
        </Field>
      </div>
      {formError && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 dark:bg-rose-500/10">{formError}</p>}
      <div className="mt-5 flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose} disabled={submitting}>إلغاء</Button>
        <Button className="flex-1" loading={submitting} onClick={submit}>{submitting ? "جاري الحفظ..." : "حفظ الخدمة"}</Button>
      </div>
    </Modal>
  );
}

function ServiceDetail({
  open,
  service,
  usage,
  revenue,
  doctorCount,
  doctorNames,
  onClose,
}: {
  open: boolean;
  service: Service | null;
  usage: number;
  revenue: number;
  doctorCount: number;
  doctorNames: string[];
  onClose: () => void;
}) {
  if (!service) return null;
  return (
    <Modal open={open} onClose={onClose} title="تفاصيل الخدمة" size="md">
      <div className="flex items-center gap-4">
        <div className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br text-3xl ${avatarGradient(service.name)}`}>
          {serviceEmoji(service.name)}
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-slate-800 dark:text-white">{service.name}</h3>
          <p className="mt-1 flex items-center gap-3 text-sm text-slate-400">
            <span className="flex items-center gap-1"><DollarSign className="h-3.5 w-3.5" /> {formatCurrency(service.price)}</span>
            <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {service.duration} دقيقة</span>
          </p>
        </div>
      </div>
      {service.description && <p className="mt-4 rounded-xl bg-slate-50 p-3 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300">{service.description}</p>}
      <div className="mt-4 grid grid-cols-3 gap-3 text-center">
        <div className="rounded-xl border border-slate-100 p-3 dark:border-slate-800">
          <p className="text-xl font-extrabold text-brand-600 dark:text-brand-400">{usage}</p>
          <p className="text-xs text-slate-400">زيارة</p>
        </div>
        <div className="rounded-xl border border-slate-100 p-3 dark:border-slate-800">
          <p className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">{formatNumber(revenue)}</p>
          <p className="text-xs text-slate-400">ج.م إيرادات</p>
        </div>
        <div className="rounded-xl border border-slate-100 p-3 dark:border-slate-800">
          <p className="text-xl font-extrabold text-violet-600 dark:text-violet-400">{doctorCount}</p>
          <p className="text-xs text-slate-400">أطباء</p>
        </div>
      </div>
      <div className="mt-4">
        <p className="mb-2 text-xs font-bold text-slate-400">الأطباء الذين يقدمونها</p>
        {doctorNames.length ? (
          <div className="flex flex-wrap gap-2">
            {doctorNames.map((n) => <span key={n} className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-300">{n}</span>)}
          </div>
        ) : (
          <p className="text-sm text-slate-400">لا يوجد أطباء بعد</p>
        )}
      </div>
      <Button className="mt-5 w-full" onClick={onClose}>إغلاق</Button>
    </Modal>
  );
}
