import { useState } from "react";
import { Download, Printer } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/contexts/AppContext";
import { useAsync } from "@/hooks";
import type { ReportPeriod } from "@/types";
import { CountChart, HorizontalBars, RevenueChart } from "@/components/Charts";
import { Avatar, Button, Card, CardHeader, EmptyState, Segmented, Skeleton } from "@/components/ui";
import { formatCurrency, formatNumber } from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";

const PERIODS: { value: ReportPeriod; label: string }[] = [
  { value: "week", label: "أسبوع" },
  { value: "month", label: "شهر" },
  { value: "3months", label: "3 شهور" },
  { value: "6months", label: "6 شهور" },
  { value: "year", label: "سنة" },
];

export default function Reports() {
  const { data, settings } = useApp();
  const [period, setPeriod] = useState<ReportPeriod>("month");
  const report = useAsync(
    async () => {
      const [revenue, appointments, patients, doctors, services] = await Promise.all([
        api.revenueReport(period),
        api.appointmentsReport(period),
        api.patientsReport(period),
        api.doctorsReport(period),
        api.servicesReport(period),
      ]);
      return { revenue, appointments, patients, doctors, services };
    },
    [period, data]
  );

  const r = report.data;
  const loading = report.loading;

  const exportCSV = () => {
    if (!r) return;
    const rows: string[][] = [];
    rows.push([settings.clinicName, "تقرير تحليلات العيادة"]);
    rows.push(["الفترة", PERIODS.find((p) => p.value === period)?.label ?? period]);
    rows.push(["تاريخ الإصدار", new Date().toLocaleString("ar-EG")]);
    rows.push([]);
    rows.push(["الإيرادات", formatNumber(r.revenue.totalRevenue), "ج.م", "متوسط الزيارة", formatNumber(r.revenue.averageVisitValue)]);
    rows.push(["المواعيد", String(r.appointments.appointmentsCount), "مكتمل", String(r.appointments.completed), "ملغي", String(r.appointments.cancelled)]);
    rows.push(["المرضى", String(r.patients.totalPatients), "جدد", String(r.patients.newPatients), "عائدون", String(r.patients.returningPatients)]);
    rows.push([]);
    rows.push(["أداء الأطباء"]);
    rows.push(["الطبيب", "الزيارات", "الإيرادات", "المرضى", "أكثر خدمة"]);
    r.doctors.forEach((d) => rows.push([d.name, String(d.visits), formatNumber(d.revenue), String(d.patients), d.topService]));
    rows.push([]);
    rows.push(["أداء الخدمات"]);
    rows.push(["الخدمة", "عدد الاستخدام", "الإيرادات"]);
    r.services.forEach((s) => rows.push([s.name, String(s.count), formatNumber(s.revenue)]));
    const csv = rows.map((row) => row.map((c) => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `clinic-report-${period}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">📊 التقارير</h1>
          <p className="text-sm text-slate-400">تحليلات شاملة محسوبة من قاعدة البيانات</p>
        </div>
        <div className="flex items-center gap-2">
          <Segmented options={PERIODS} value={period} onChange={setPeriod} size="sm" />
          <Button variant="secondary" size="md" onClick={exportCSV} disabled={loading}>
            <Download className="h-4 w-4" /> Excel
          </Button>
          <Button variant="secondary" size="md" onClick={() => window.print()} disabled={loading}>
            <Printer className="h-4 w-4" /> PDF
          </Button>
        </div>
      </div>

      {loading || !r ? (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-64 w-full" />)}
        </div>
      ) : (
        <>
          {/* Revenue */}
          <Card>
            <CardHeader title="💰 تقرير الإيرادات" icon="📈" />
            <div className="grid grid-cols-1 gap-4 p-5 lg:grid-cols-4">
              <div className="lg:col-span-1 space-y-3">
                <ReportStat label="إجمالي الإيرادات" value={formatCurrency(r.revenue.totalRevenue)} tint="text-emerald-600" />
                <ReportStat label="متوسط قيمة الزيارة" value={formatCurrency(r.revenue.averageVisitValue)} tint="text-brand-600" />
                <ReportStat label="عدد الزيارات" value={`${formatNumber(r.revenue.completedVisits)} زيارة`} tint="text-violet-600" />
              </div>
              <div className="lg:col-span-3">
                <RevenueChart data={r.revenue.chart} />
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {/* Appointments */}
            <Card>
              <CardHeader title="📅 تقرير المواعيد" icon="📅" />
              <div className="space-y-3 p-5">
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  <ReportStat label="إجمالي الحجوزات" value={formatNumber(r.appointments.appointmentsCount)} tint="text-brand-600" />
                  <ReportStat label="مكتملة" value={formatNumber(r.appointments.completed)} tint="text-emerald-600" />
                  <ReportStat label="قيد الانتظار" value={formatNumber(r.appointments.pending)} tint="text-amber-600" />
                  <ReportStat label="مؤكدة" value={formatNumber(r.appointments.confirmed)} tint="text-blue-600" />
                  <ReportStat label="ملغاة" value={formatNumber(r.appointments.cancelled)} tint="text-rose-600" />
                  <ReportStat label="لم تحضر" value={formatNumber(r.appointments.no_show)} tint="text-slate-500" />
                </div>
                <CountChart data={r.appointments.chart.map((c) => ({ label: c.label, amount: 0, count: c.count ?? 0 }))} color="#3b82f6" height={180} />
              </div>
            </Card>

            {/* Patients */}
            <Card>
              <CardHeader title="👥 تقرير المرضى" icon="👥" />
              <div className="space-y-3 p-5">
                <div className="grid grid-cols-3 gap-3">
                  <ReportStat label="إجمالي المرضى" value={formatNumber(r.patients.totalPatients)} tint="text-brand-600" />
                  <ReportStat label="مرضى جدد" value={formatNumber(r.patients.newPatients)} tint="text-emerald-600" />
                  <ReportStat label="العودون" value={formatNumber(r.patients.returningPatients)} tint="text-violet-600" />
                </div>
                <CountChart data={r.patients.chart.map((c) => ({ label: c.label, amount: 0, count: c.count ?? 0 }))} color="#10b981" height={180} />
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {/* Doctor performance */}
            <Card>
              <CardHeader title="👨‍⚕️ أداء الأطباء" icon="🏆" />
              <div className="p-5">
                {r.doctors.length === 0 ? (
                  <EmptyState emoji="👨‍⚕️" title="لا توجد بيانات" />
                ) : (
                  <div className="space-y-3">
                    {r.doctors.slice(0, 6).map((d, i) => (
                      <div key={d.id} className="flex items-center gap-3 rounded-xl border border-slate-100 p-3 dark:border-slate-800">
                        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-50 text-xs font-extrabold text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">{i + 1}</span>
                        <Avatar name={d.name} size="sm" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold text-slate-700 dark:text-slate-200">{d.name}</p>
                          <p className="truncate text-xs text-slate-400">{d.specialty} • ⭐ {d.topService}</p>
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-bold text-brand-600 dark:text-brand-400">{d.visits} زيارة</p>
                          <p className="text-xs text-emerald-600 dark:text-emerald-400">{formatNumber(d.revenue)} ج.م</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>

            {/* Service performance */}
            <Card>
              <CardHeader title="🦷 أداء الخدمات" icon="🦷" />
              <div className="p-5">
                {r.services.length === 0 ? (
                  <EmptyState emoji="🦷" title="لا توجد بيانات" />
                ) : (
                  <HorizontalBars
                    data={r.services.slice(0, 6).map((s) => ({ label: s.name, value: s.count, emoji: serviceEmoji(s.name) }))}
                    formatter={(n) => formatNumber(n)}
                  />
                )}
              </div>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function ReportStat({ label, value, tint }: { label: string; value: string; tint: string }) {
  return (
    <div className="rounded-xl border border-slate-100 p-3 dark:border-slate-800">
      <p className="text-xs text-slate-400">{label}</p>
      <p className={`mt-1 text-lg font-extrabold ${tint}`}>{value}</p>
    </div>
  );
}
