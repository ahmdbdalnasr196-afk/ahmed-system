import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { CalendarClock, DollarSign, Stethoscope, TrendingUp, Users, Wallet, ArrowRight } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/contexts/AppContext";
import { useAsync } from "@/hooks";
import { CountChart } from "@/components/Charts";
import { Avatar, Card, CardHeader, EmptyState, Skeleton } from "@/components/ui";
import { DAY_LABELS } from "@/utils/domain";
import { daysAgoKey, formatCurrency, formatNumber, pad, to12h, todayKey } from "@/utils/format";

export default function DoctorProfile() {
  const { id = "" } = useParams();
  const { data } = useApp();
  const { data: doctor, loading } = useAsync(() => api.getDoctor(id), [id, data]);

  const schedule = useMemo(() => {
    const appts = data.appointments.filter((a) => !a.isDeleted && a.doctorId === id);
    const today = todayKey();
    const now = new Date();
    const weekAgo = daysAgoKey(7);
    const monthKey = `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;
    return {
      today: appts.filter((a) => a.date === today).length,
      week: appts.filter((a) => a.date >= weekAgo && a.date <= today).length,
      month: appts.filter((a) => a.date.startsWith(monthKey)).length,
    };
  }, [data.appointments, id]);

  if (loading || !doctor) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  const stats = [
    { label: "المرضى الفريدون", value: formatNumber(doctor.patientsCount), icon: Users, tint: "bg-blue-500" },
    { label: "عدد الحجوزات", value: formatNumber(doctor.appointmentsCount), icon: CalendarClock, tint: "bg-amber-500" },
    { label: "الزيارات المكتملة", value: formatNumber(doctor.completedVisits), icon: Stethoscope, tint: "bg-violet-500" },
    { label: "إجمالي الإيرادات", value: formatCurrency(doctor.totalRevenue), icon: DollarSign, tint: "bg-emerald-500" },
    { label: "متوسط قيمة الزيارة", value: formatCurrency(doctor.averageVisitValue), icon: TrendingUp, tint: "bg-cyan-500" },
    { label: "أكثر خدمة", value: doctor.topService, icon: Wallet, tint: "bg-rose-500" },
  ];

  return (
    <div className="space-y-6">
      <Link to="/doctors" className="inline-flex items-center gap-1 text-sm font-semibold text-slate-500 hover:text-brand-600">
        <ArrowRight className="h-4 w-4" /> العودة للأطباء
      </Link>

      <Card className="overflow-hidden">
        <div className="bg-gradient-to-l from-violet-600 to-brand-500 p-6">
          <div className="flex flex-col items-center gap-4 text-center sm:flex-row sm:text-right">
            <Avatar name={doctor.name} size="xl" className="ring-4 ring-white/30" />
            <div>
              <h1 className="text-2xl font-extrabold text-white">{doctor.name}</h1>
              <p className="mt-1 text-white/90">{doctor.specialty}</p>
              <p className="mt-1 text-sm text-white/80" dir="ltr">{doctor.phone || "—"}</p>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-px bg-slate-100 dark:bg-slate-800 sm:grid-cols-3">
          <div className="bg-white p-4 dark:bg-slate-900">
            <p className="text-xs text-slate-400">أيام العمل</p>
            <div className="mt-1 flex flex-wrap gap-1">
              {doctor.workingDays.map((d) => (
                <span key={d} className="rounded-md bg-brand-50 px-1.5 py-0.5 text-[11px] font-semibold text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
                  {DAY_LABELS[d]}
                </span>
              ))}
            </div>
          </div>
          <div className="bg-white p-4 dark:bg-slate-900">
            <p className="text-xs text-slate-400">ساعات العمل</p>
            <p className="mt-1 font-bold text-slate-700 dark:text-slate-200">
              {to12h(doctor.workingFrom)} - {to12h(doctor.workingTo)}
            </p>
          </div>
          <div className="col-span-2 bg-white p-4 dark:bg-slate-900 sm:col-span-1">
            <p className="text-xs text-slate-400">نبذة</p>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{doctor.description || "—"}</p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="p-4">
            <div className={`mb-2 inline-flex h-9 w-9 items-center justify-center rounded-lg text-white ${s.tint}`}>
              <s.icon className="h-4 w-4" />
            </div>
            <p className="truncate text-lg font-extrabold text-slate-800 dark:text-white">{s.value}</p>
            <p className="text-xs text-slate-400">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="عدد الزيارات شهرياً" icon="📈" subtitle="آخر 12 شهر" />
          <div className="p-5">
            {doctor.monthlyVisits.every((m) => m.count === 0) ? (
              <EmptyState emoji="📈" title="لا توجد بيانات كافية" />
            ) : (
              <CountChart data={doctor.monthlyVisits} color="#8b5cf6" />
            )}
          </div>
        </Card>
        <Card>
          <CardHeader title="مواعيد الطبيب" icon="📅" />
          <div className="space-y-3 p-5">
            {[
              { label: "مواعيد اليوم", value: schedule.today, tint: "text-brand-600" },
              { label: "هذا الأسبوع", value: schedule.week, tint: "text-amber-600" },
              { label: "هذا الشهر", value: schedule.month, tint: "text-emerald-600" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between rounded-xl border border-slate-100 px-4 py-3 dark:border-slate-800">
                <span className="text-sm text-slate-500">{row.label}</span>
                <span className={`text-xl font-extrabold ${row.tint}`}>{row.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
