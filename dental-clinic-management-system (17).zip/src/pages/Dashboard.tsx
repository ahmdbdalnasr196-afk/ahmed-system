import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowUpRight,
  CalendarClock,
  DollarSign,
  Stethoscope,
  Users,
} from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/contexts/AppContext";
import { useAsync } from "@/hooks";
import type { ReportPeriod } from "@/types";
import { HorizontalBars, RevenueChart } from "@/components/Charts";
import {
  Avatar,
  Card,
  CardHeader,
  EmptyState,
  Segmented,
  Skeleton,
  StatusBadge,
} from "@/components/ui";
import { formatCurrency, formatNumber, to12h, formatDate } from "@/utils/format";
import { serviceEmoji } from "@/utils/domain";

const PERIODS: { value: ReportPeriod; label: string }[] = [
  { value: "week", label: "أسبوع" },
  { value: "month", label: "شهر" },
  { value: "3months", label: "3 شهور" },
  { value: "6months", label: "6 شهور" },
  { value: "year", label: "سنة" },
];

function StatCard({
  label,
  value,
  icon: Icon,
  tint,
}: {
  label: string;
  value: string;
  icon: typeof Users;
  tint: string;
}) {
  return (
    <Card className="relative overflow-hidden p-5 transition-transform hover:-translate-y-0.5">
      <div className={`absolute -left-6 -top-6 h-24 w-24 rounded-full opacity-10 ${tint}`} />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-sm font-semibold text-slate-400">{label}</p>
          <p className="mt-2 text-3xl font-extrabold text-slate-800 dark:text-white">{value}</p>
        </div>
        <div className={`flex h-12 w-12 items-center justify-center rounded-xl text-white ${tint}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <p className="relative mt-3 text-xs text-slate-400">تحديث فوري من قاعدة البيانات</p>
    </Card>
  );
}

export default function Dashboard() {
  const { data } = useApp();
  const navigate = useNavigate();
  const [p, setP] = useState<ReportPeriod>(
    () => (sessionStorage.getItem("dash_period") as ReportPeriod) || "month"
  );

  const dash = useAsync(
    async () => {
      const [stats, revenue, services, doctors] = await Promise.all([
        api.getDashboardStats(),
        api.revenueReport(p),
        api.servicesReport(p),
        api.doctorsReport(p),
      ]);
      return { stats, revenue, services, doctors };
    },
    [p, data]
  );

  const doctorName = (id: string) => data.doctors.find((d) => d.id === id)?.name ?? "—";
  const serviceName = (id: string) => data.services.find((s) => s.id === id)?.name ?? "—";
  const patientName = (id: string) => data.patients.find((x) => x.id === id)?.name ?? "—";

  const latestAppointments = useMemo(
    () =>
      [...data.appointments]
        .filter((a) => !a.isDeleted)
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
        .slice(0, 5),
    [data.appointments]
  );
  const latestPatients = useMemo(
    () => data.patients.filter((x) => !x.isDeleted).slice(0, 5),
    [data.patients]
  );

  const s = dash.data;
  const loading = dash.loading;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-800 dark:text-white">📊 لوحة التحكم</h1>
        <p className="text-sm text-slate-400">نظرة عامة على أداء العيادة في الوقت الفعلي</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {loading || !s ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="p-5">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="mt-3 h-9 w-32" />
              <Skeleton className="mt-3 h-3 w-40" />
            </Card>
          ))
        ) : (
          <>
            <StatCard label="👥 إجمالي المرضى" value={formatNumber(s.stats.patientsCount)} icon={Users} tint="bg-blue-500" />
            <StatCard label="👨‍⚕️ إجمالي الأطباء" value={formatNumber(s.stats.doctorsCount)} icon={Stethoscope} tint="bg-violet-500" />
            <StatCard label="📅 مواعيد اليوم" value={formatNumber(s.stats.todayAppointments)} icon={CalendarClock} tint="bg-amber-500" />
            <StatCard label="💰 إيرادات اليوم" value={formatCurrency(s.stats.todayRevenue)} icon={DollarSign} tint="bg-emerald-500" />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="تحليلات الإيرادات"
            icon="📈"
            action={<Segmented options={PERIODS} value={p} onChange={setP} size="sm" />}
          />
          <div className="p-5">
            {loading || !s ? (
              <Skeleton className="h-[260px] w-full" />
            ) : (
              <>
                <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
                  <div>
                    <p className="text-xs font-semibold text-slate-400">💰 إجمالي الإيرادات للفترة المحددة</p>
                    <p className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(s.revenue.totalRevenue)}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-slate-400">متوسط قيمة الزيارة</p>
                    <p className="font-bold text-slate-700 dark:text-slate-200">
                      {formatCurrency(s.revenue.averageVisitValue)}
                    </p>
                  </div>
                </div>
                <RevenueChart data={s.revenue.chart} />
              </>
            )}
          </div>
        </Card>

        <Card>
          <CardHeader title="الخدمات الأكثر أداءً" icon="🦷" subtitle="لنفس الفترة المحددة" />
          <div className="p-5">
            {loading || !s ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-7 w-full" />
                ))}
              </div>
            ) : s.services.length === 0 ? (
              <EmptyState emoji="🦷" title="لا توجد خدمات" description="لا توجد زيارات مسجلة في هذه الفترة." />
            ) : (
              <HorizontalBars
                data={s.services.slice(0, 6).map((sv) => ({
                  label: sv.name,
                  value: sv.count,
                  emoji: serviceEmoji(sv.name),
                }))}
                formatter={(n) => `${formatNumber(n)} زيارة`}
              />
            )}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title="أحدث المواعيد"
            icon="📅"
            action={
              <button onClick={() => navigate("/appointments")} className="flex items-center gap-1 text-xs font-bold text-brand-600 hover:text-brand-700">
                الكل <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            }
          />
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {latestAppointments.length === 0 ? (
              <EmptyState emoji="📅" title="لا توجد مواعيد اليوم" />
            ) : (
              latestAppointments.map((a) => (
                <button
                  key={a.id}
                  onClick={() => navigate("/appointments")}
                  className="flex w-full items-center gap-3 px-5 py-3 text-right transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
                >
                  <Avatar name={patientName(a.patientId)} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">
                      {patientName(a.patientId)}
                    </p>
                    <p className="truncate text-xs text-slate-400">
                      {doctorName(a.doctorId)} • {serviceName(a.serviceId)}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{to12h(a.time)}</p>
                    <div className="mt-1">
                      <StatusBadge status={a.status} />
                    </div>
                  </div>
                </button>
              ))
            )}
          </div>
        </Card>

        <Card>
          <CardHeader
            title="أحدث المرضى"
            icon="👥"
            action={
              <button onClick={() => navigate("/patients")} className="flex items-center gap-1 text-xs font-bold text-brand-600 hover:text-brand-700">
                الكل <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            }
          />
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {latestPatients.length === 0 ? (
              <EmptyState emoji="👥" title="لا يوجد مرضى حتى الآن" />
            ) : (
              latestPatients.map((pat) => (
                <button
                  key={pat.id}
                  onClick={() => navigate(`/patients/${pat.id}`)}
                  className="flex w-full items-center gap-3 px-5 py-3 text-right transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
                >
                  <Avatar name={pat.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">{pat.name}</p>
                    <p className="truncate text-xs text-slate-400">{pat.phone}</p>
                  </div>
                  <p className="text-xs text-slate-400">{formatDate(pat.createdAt)}</p>
                </button>
              ))
            )}
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader title="🏆 أفضل الأطباء" subtitle="مرتبين حسب عدد الزيارات المكتملة" icon="👨‍⚕️" />
        <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2 xl:grid-cols-4">
          {loading || !s ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-slate-100 p-4 dark:border-slate-800">
                <Skeleton className="mx-auto h-14 w-14 rounded-full" />
                <Skeleton className="mx-auto mt-3 h-4 w-24" />
                <Skeleton className="mx-auto mt-2 h-3 w-32" />
              </div>
            ))
          ) : s.doctors.length === 0 ? (
            <EmptyState emoji="👨‍⚕️" title="لا يوجد أطباء" />
          ) : (
            s.doctors.slice(0, 4).map((d) => (
              <button
                key={d.id}
                onClick={() => navigate(`/doctors/${d.id}`)}
                className="group rounded-2xl border border-slate-100 bg-gradient-to-b from-white to-slate-50 p-4 text-center transition-all hover:-translate-y-1 hover:border-brand-200 hover:shadow-lg dark:border-slate-800 dark:from-slate-900 dark:to-slate-800/50"
              >
                <Avatar name={d.name} size="lg" className="mx-auto" />
                <p className="mt-3 truncate text-sm font-bold text-slate-800 dark:text-white">{d.name}</p>
                <p className="truncate text-xs text-slate-400">{d.specialty}</p>
                <div className="mt-3 grid grid-cols-2 gap-2 text-center">
                  <div className="rounded-lg bg-slate-100 py-1.5 dark:bg-slate-800">
                    <p className="text-sm font-extrabold text-brand-600 dark:text-brand-400">{d.visits}</p>
                    <p className="text-[10px] text-slate-400">زيارة</p>
                  </div>
                  <div className="rounded-lg bg-slate-100 py-1.5 dark:bg-slate-800">
                    <p className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                      {formatNumber(d.revenue)}
                    </p>
                    <p className="text-[10px] text-slate-400">ج.م</p>
                  </div>
                </div>
                <p className="mt-2 truncate text-[11px] text-slate-400">⭐ {d.topService}</p>
              </button>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
