import { useEffect, useMemo, useState } from "react";
import { CalendarDays, Check, CheckCircle2, Eye, List, Pencil, Plus, RefreshCw, X, XCircle } from "lucide-react";
import { api } from "@/api";
import { useApp } from "@/contexts/AppContext";
import type { Appointment, AppointmentStatus, PatientSearchResult } from "@/types";
import {
  Avatar,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Pagination,
  SearchInput,
  Select,
  Skeleton,
  StatusBadge,
  Textarea,
} from "@/components/ui";
import { TimePicker } from "@/components/TimePicker";
import { PatientSelector, type PatientSelectorValue } from "@/components/PatientPicker";
import { formatDate, to12h, todayKey } from "@/utils/format";

export default function Appointments() {
  const { data, bookAppointment, updateAppointment, cancelAppointment, completeAppointment } = useApp();
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("all");
  const [serviceFilter, setServiceFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | AppointmentStatus>("all");
  const [view, setView] = useState<"list" | "day">("list");
  const [dayDate, setDayDate] = useState(todayKey());
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Appointment | null>(null);
  const [viewing, setViewing] = useState<Appointment | null>(null);
  const [cancelId, setCancelId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  const patientName = (id: string) => data.patients.find((p) => p.id === id)?.name ?? "—";
  const doctorName = (id: string) => data.doctors.find((d) => d.id === id)?.name ?? "—";
  const serviceName = (id: string) => data.services.find((s) => s.id === id)?.name ?? "—";

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...data.appointments]
      .filter((a) => !a.isDeleted)
      .filter((a) => {
        if (q && !(patientName(a.patientId).toLowerCase().includes(q) || doctorName(a.doctorId).toLowerCase().includes(q) || (data.patients.find((p) => p.id === a.patientId)?.phone ?? "").includes(q)))
          return false;
        if (dateFilter && a.date !== dateFilter) return false;
        if (doctorFilter !== "all" && a.doctorId !== doctorFilter) return false;
        if (serviceFilter !== "all" && a.serviceId !== serviceFilter) return false;
        if (statusFilter !== "all" && a.status !== statusFilter) return false;
        return true;
      })
      .sort((a, b) => (a.date === b.date ? (a.time < b.time ? -1 : 1) : a.date < b.date ? 1 : -1));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.appointments, data.patients, query, dateFilter, doctorFilter, serviceFilter, statusFilter]);

  useEffect(() => setPage(1), [query, dateFilter, doctorFilter, serviceFilter, statusFilter, pageSize]);
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  const dayAppointments = useMemo(
    () => rows.filter((a) => a.date === dayDate).sort((a, b) => (a.time < b.time ? -1 : 1)),
    [rows, dayDate]
  );

  return (
    <div>
      <PageHeader
        title="📅 المواعيد"
        subtitle={`${rows.length} موعد`}
        actions={
          <>
            <div className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white p-1 dark:border-slate-700 dark:bg-slate-900">
              <button onClick={() => setView("list")} className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold ${view === "list" ? "bg-brand-600 text-white" : "text-slate-500"}`}>
                <List className="h-3.5 w-3.5" /> قائمة
              </button>
              <button onClick={() => setView("day")} className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold ${view === "day" ? "bg-brand-600 text-white" : "text-slate-500"}`}>
                <CalendarDays className="h-3.5 w-3.5" /> يومي
              </button>
            </div>
            <Button variant="secondary" loading={refreshing} onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 600); }}>
              <RefreshCw className="h-4 w-4" /> تحديث
            </Button>
            <Button onClick={() => { setEditing(null); setModalOpen(true); }}>
              <Plus className="h-4 w-4" /> حجز موعد
            </Button>
          </>
        }
      />

      <Card className="mb-4 p-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-5">
          <SearchInput value={query} onChange={setQuery} placeholder="بحث..." />
          <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} />
          <Select value={doctorFilter} onChange={(e) => setDoctorFilter(e.target.value)}>
            <option value="all">كل الأطباء</option>
            {data.doctors.filter((d) => !d.isDeleted && d.isActive).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
          <Select value={serviceFilter} onChange={(e) => setServiceFilter(e.target.value)}>
            <option value="all">كل الخدمات</option>
            {data.services.filter((s) => !s.isDeleted && s.isActive).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as any)}>
            <option value="all">كل الحالات</option>
            <option value="pending">قيد الانتظار</option>
            <option value="confirmed">مؤكد</option>
            <option value="completed">مكتمل</option>
            <option value="cancelled">ملغي</option>
            <option value="no_show">لم يحضر</option>
          </Select>
        </div>
      </Card>

      {view === "day" && (
        <Card className="mb-4 p-4">
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">عرض مواعيد يوم:</span>
            <Input type="date" value={dayDate} onChange={(e) => setDayDate(e.target.value)} className="w-auto" />
          </div>
          <div className="mt-4 space-y-2">
            {dayAppointments.length === 0 ? (
              <EmptyState emoji="📅" title="لا توجد مواعيد في هذا اليوم" />
            ) : (
              dayAppointments.map((a) => (
                <button key={a.id} onClick={() => setViewing(a)} className="flex w-full items-center gap-4 rounded-xl border border-slate-100 p-3 text-right transition-colors hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50">
                  <div className="w-20 shrink-0 text-center">
                    <p className={`text-sm font-bold ${a.status === "cancelled" ? "text-slate-400 line-through" : "text-brand-600 dark:text-brand-400"}`}>{to12h(a.time)}</p>
                    <p className="text-[11px] text-slate-400">{to12h(a.endTime)}</p>
                  </div>
                  <Avatar name={patientName(a.patientId)} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-700 dark:text-slate-200">{patientName(a.patientId)}</p>
                    <p className="truncate text-xs text-slate-400">{doctorName(a.doctorId)} • {serviceName(a.serviceId)}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </button>
              ))
            )}
          </div>
        </Card>
      )}

      <Card className="overflow-hidden">
        {loading ? (
          <div className="space-y-3 p-5">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
        ) : rows.length === 0 ? (
          <EmptyState emoji="📅" title="لا توجد مواعيد" description="ابدأ بحجز موعد جديد." action={<Button onClick={() => { setEditing(null); setModalOpen(true); }}><Plus className="h-4 w-4" /> حجز موعد</Button>} />
        ) : view === "list" ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-right text-xs font-bold text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
                  <th className="px-5 py-3">المريض</th>
                  <th className="px-5 py-3">الطبيب</th>
                  <th className="px-5 py-3">الخدمة</th>
                  <th className="px-5 py-3">التاريخ</th>
                  <th className="px-5 py-3">الوقت</th>
                  <th className="px-5 py-3">الحالة</th>
                  <th className="px-5 py-3 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
                {pageRows.map((a) => (
                  <tr key={a.id} className="transition-colors hover:bg-slate-50/60 dark:hover:bg-slate-800/30">
                    <td className="px-5 py-3">
                      <button onClick={() => setViewing(a)} className="flex items-center gap-3 text-right">
                        <Avatar name={patientName(a.patientId)} size="sm" />
                        <span className="font-semibold text-slate-700 dark:text-slate-200">{patientName(a.patientId)}</span>
                      </button>
                    </td>
                    <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{doctorName(a.doctorId)}</td>
                    <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{serviceName(a.serviceId)}</td>
                    <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{formatDate(a.date)}</td>
                    <td className="px-5 py-3">
                      <span className={`font-semibold ${a.status === "cancelled" ? "text-slate-400 line-through" : "text-slate-600 dark:text-slate-300"}`}>
                        {to12h(a.time)}
                      </span>
                    </td>
                    <td className="px-5 py-3"><StatusBadge status={a.status} /></td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <IconBtn title="عرض" onClick={() => setViewing(a)}><Eye className="h-4 w-4" /></IconBtn>
                        <IconBtn title="تعديل" onClick={() => { setEditing(a); setModalOpen(true); }}><Pencil className="h-4 w-4" /></IconBtn>
                        {a.status !== "cancelled" && a.status !== "completed" && (
                          <IconBtn title="إلغاء" danger onClick={() => setCancelId(a.id)}><X className="h-4 w-4" /></IconBtn>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        {!loading && view === "list" && rows.length > 0 && (
          <Pagination page={page} pageCount={pageCount} total={rows.length} pageSize={pageSize} onPage={setPage} onPageSize={setPageSize} />
        )}
      </Card>

      <BookingModal
        open={modalOpen}
        editing={editing}
        doctors={data.doctors.filter((d) => !d.isDeleted && d.isActive)}
        services={data.services.filter((s) => !s.isDeleted && s.isActive)}
        existingPatient={null}
        onClose={() => setModalOpen(false)}
        onCreate={async (v) => { await bookAppointment(v); }}
        onUpdate={async (id, v) => { await updateAppointment(id, v); }}
      />

      <AppointmentDetail
        open={!!viewing}
        appointment={viewing}
        patientName={viewing ? patientName(viewing.patientId) : ""}
        doctorName={viewing ? doctorName(viewing.doctorId) : ""}
        serviceName={viewing ? serviceName(viewing.serviceId) : ""}
        onClose={() => setViewing(null)}
        onEdit={(a) => { setViewing(null); setEditing(a); setModalOpen(true); }}
        onCancel={async (id) => { await cancelAppointment(id); setViewing(null); }}
        onComplete={async (id) => { await completeAppointment(id); setViewing(null); }}
        onConfirm={async (id) => { await updateAppointment(id, { status: "confirmed" }); setViewing(null); }}
      />

      <ConfirmDialog
        open={!!cancelId}
        onClose={() => setCancelId(null)}
        danger
        title="إلغاء الموعد"
        message="هل أنت متأكد من إلغاء هذا الموعد؟ سيظهر كملغي ولن يتم حذفه."
        onConfirm={async () => { if (cancelId) await cancelAppointment(cancelId); setCancelId(null); }}
      />
    </div>
  );
}

function IconBtn({ children, onClick, title, danger }: { children: React.ReactNode; onClick: () => void; title: string; danger?: boolean }) {
  return (
    <button title={title} onClick={onClick} className={`rounded-lg p-2 transition-colors ${danger ? "text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/15" : "text-slate-400 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-brand-500/15"}`}>
      {children}
    </button>
  );
}

function BookingModal({
  open,
  editing,
  doctors,
  services,
  existingPatient,
  onClose,
  onCreate,
  onUpdate,
}: {
  open: boolean;
  editing: Appointment | null;
  doctors: { id: string; name: string }[];
  services: { id: string; name: string; duration: number }[];
  existingPatient: PatientSearchResult | null;
  onClose: () => void;
  onCreate: (v: any) => Promise<void>;
  onUpdate: (id: string, v: any) => Promise<void>;
}) {
  const isEdit = !!editing;
  const [patient, setPatient] = useState<PatientSelectorValue>({ name: "", phone: "", manual: false });
  const [doctorId, setDoctorId] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [date, setDate] = useState(todayKey());
  const [time, setTime] = useState("10:00");
  const [notes, setNotes] = useState("");
  const [slots, setSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setPatient(
        existingPatient
          ? { patientId: existingPatient.id, name: existingPatient.name, phone: existingPatient.phone, manual: false }
          : { name: "", phone: "", manual: false }
      );
      setDoctorId(editing?.doctorId ?? doctors[0]?.id ?? "");
      setServiceId(editing?.serviceId ?? services[0]?.id ?? "");
      setDate(editing?.date ?? todayKey());
      setTime(editing?.time ?? "10:00");
      setNotes(editing?.notes ?? "");
      setFormError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  useEffect(() => {
    if (!doctorId || !serviceId || !date) return setSlots([]);
    setSlotsLoading(true);
    api
      .getSlots({ doctorId, serviceId, date, excludeId: editing?.id })
      .then(setSlots)
      .catch(() => setSlots([]))
      .finally(() => setSlotsLoading(false));
  }, [doctorId, serviceId, date, editing?.id]);

  const submit = async () => {
    if (!patient.name.trim()) return setFormError("اسم المريض مطلوب");
    if (!patient.manual && !patient.patientId && !/^01[0-9]{9}$/.test(patient.phone.trim()))
      return setFormError("رقم هاتف غير صحيح");
    if (!doctorId || !serviceId) return setFormError("اختر الطبيب والخدمة");
    setSubmitting(true);
    setFormError(null);
    try {
      if (isEdit && editing) {
        await onUpdate(editing.id, { doctorId, serviceId, date, time, notes });
      } else {
        const doctor = doctors.find((d) => d.id === doctorId)!;
        const service = services.find((s) => s.id === serviceId)!;
        await onCreate({
          patientId: patient.patientId,
          patientName: patient.name.trim(),
          phone: patient.phone.trim(),
          doctorName: doctor.name,
          serviceName: service.name,
          date,
          time,
          notes,
        });
      }
      onClose();
    } catch (e: any) {
      setFormError(e?.message || "تعذر حجز الموعد");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? "تعديل الموعد" : "حجز موعد جديد"} size="lg">
      <div className="space-y-4">
        {!isEdit && (
          <PatientSelector value={patient} onChange={setPatient} initialPatient={null} error={formError && !patient.name ? formError : undefined} />
        )}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="👨‍⚕️ الطبيب" required>
            <Select value={doctorId} onChange={(e) => setDoctorId(e.target.value)}>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </Field>
          <Field label="🦷 الخدمة" required>
            <Select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
              {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label="📅 التاريخ" required>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="⏰ الوقت" required hint="نظام 12 ساعة">
            <TimePicker value={time} onChange={setTime} />
          </Field>
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-2 text-xs font-bold text-slate-400">⏰ المواعيد المتاحة لهذا اليوم</p>
        {slotsLoading ? (
          <p className="text-xs text-slate-400">جاري البحث عن المواعيد المتاحة...</p>
        ) : slots.length === 0 ? (
          <p className="text-xs text-rose-500">لا توجد مواعيد متاحة لهذا الطبيب في هذا اليوم/الوقت.</p>
        ) : (
          <div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">
            {slots.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setTime(s)}
                className={`rounded-lg border px-2.5 py-1 text-xs font-semibold transition-colors ${time === s ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300" : "border-slate-200 text-slate-500 hover:border-brand-300 dark:border-slate-700"}`}
              >
                {to12h(s)}
              </button>
            ))}
          </div>
        )}
      </div>

      <Field label="ملاحظات">
        <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات إضافية (اختياري)" />
      </Field>

      {formError && <p className="mt-3 rounded-lg bg-rose-50 px-3 py-2 text-sm font-medium text-rose-600 dark:bg-rose-500/10">{formError}</p>}
      <div className="mt-5 flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose} disabled={submitting}>إلغاء</Button>
        <Button className="flex-1" loading={submitting} onClick={submit}>{submitting ? "جاري الحجز..." : isEdit ? "حفظ التعديلات" : "حجز الموعد"}</Button>
      </div>
    </Modal>
  );
}

function AppointmentDetail({
  open,
  appointment,
  patientName,
  doctorName,
  serviceName,
  onClose,
  onEdit,
  onCancel,
  onComplete,
  onConfirm,
}: {
  open: boolean;
  appointment: Appointment | null;
  patientName: string;
  doctorName: string;
  serviceName: string;
  onClose: () => void;
  onEdit: (a: Appointment) => void;
  onCancel: (id: string) => Promise<void>;
  onComplete: (id: string) => Promise<void>;
  onConfirm: (id: string) => Promise<void>;
}) {
  if (!appointment) return null;
  const a = appointment;
  const canAct = a.status !== "cancelled" && a.status !== "completed";
  return (
    <Modal open={open} onClose={onClose} title="تفاصيل الموعد">
      <div className="flex items-center gap-3">
        <Avatar name={patientName} size="lg" />
        <div>
          <h3 className="text-lg font-extrabold text-slate-800 dark:text-white">{patientName}</h3>
          <StatusBadge status={a.status} />
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
        <DetailRow label="الطبيب" value={doctorName} />
        <DetailRow label="الخدمة" value={serviceName} />
        <DetailRow label="التاريخ" value={formatDate(a.date)} />
        <DetailRow label="الوقت" value={`${to12h(a.time)} - ${to12h(a.endTime)}`} />
      </div>
      {a.notes && <p className="mt-3 rounded-xl bg-slate-50 p-3 text-sm text-slate-600 dark:bg-slate-800/50 dark:text-slate-300"><b>ملاحظات:</b> {a.notes}</p>}

      <div className="mt-5 grid grid-cols-2 gap-2">
        <Button variant="secondary" onClick={() => onEdit(a)}><Pencil className="h-4 w-4" /> تعديل</Button>
        {a.status === "pending" && (
          <Button variant="secondary" onClick={() => onConfirm(a.id)}><Check className="h-4 w-4" /> تأكيد</Button>
        )}
        {canAct && (
          <Button onClick={() => onComplete(a.id)}><CheckCircle2 className="h-4 w-4" /> إكمال وتسجيل زيارة</Button>
        )}
        {canAct && (
          <Button variant="danger" onClick={() => onCancel(a.id)}><XCircle className="h-4 w-4" /> إلغاء الموعد</Button>
        )}
        {!canAct && (
          <Button variant="secondary" onClick={onClose}>إغلاق</Button>
        )}
      </div>
    </Modal>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-100 px-3 py-2 dark:border-slate-800">
      <p className="text-xs text-slate-400">{label}</p>
      <p className="font-semibold text-slate-700 dark:text-slate-200">{value}</p>
    </div>
  );
}


