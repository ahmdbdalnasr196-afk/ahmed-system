import type {
  ApiLog,
  AppNotification,
  Appointment,
  Database,
  Doctor,
  Patient,
  Service,
  Settings,
  Visit,
} from "@/types";
import { nowIso, pad, uid } from "@/utils/format";

const STORAGE_KEY = "dental_clinic_db_v1";

// ---------------------------------------------------------------------------
// Seed helpers
// ---------------------------------------------------------------------------
function rand(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
function isoOn(dayKey: string): string {
  const [y, m, d] = dayKey.split("-").map(Number);
  return new Date(y, m - 1, d, rand(9, 20), rand(0, 59), rand(0, 59)).toISOString();
}

// ---------------------------------------------------------------------------
// Seed data
// ---------------------------------------------------------------------------
function seed(): Database {
  const services: Service[] = [
    mkService("كشف عام", 200, 30, "فحص شامل للأسنان واللثة وتشخيص الحالة."),
    mkService("تنظيف الأسنان", 500, 45, "إزالة الجير والتصبغات وتنظيف الأسنان احترافياً."),
    mkService("حشو الأسنان", 600, 60, "علاج تسوس الأسنان وحشوها بمواد عالية الجودة."),
    mkService("تبييض الأسنان", 1500, 90, "تبييض احترافي لإضفاء لون أكثر إشراقاً."),
    mkService("خلع الأسنان", 800, 45, "خلع آمن للأسنان التالفة أو الضرس العقل."),
    mkService("علاج الجذور", 1200, 90, "علاج عصب السن وحفظه من الاستخراج."),
    mkService("تركيبات وزراعة", 3500, 120, "تركيبات وزراعة أسنان لتعويض الأسنان المفقودة."),
    mkService("تقويم الأسنان", 20000, 90, "تقويم أسنان معدني وشفاف لتصحيح اصطفاف الأسنان."),
  ];

  const doctors: Doctor[] = [
    mkDoctor("د. كريم عبد الله", "تقويم الأسنان", ["sunday", "monday", "tuesday", "wednesday", "thursday"], "10:00", "18:00", "01001112223", "استشاري تقويم الأسنان بخبرة تزيد عن 12 عاماً في حالات التقويم المعدني والشفاف."),
    mkDoctor("د. سارة محمود", "علاج الجذور وتجميل الأسنان", ["saturday", "sunday", "monday", "tuesday", "wednesday"], "11:00", "19:00", "01002223334", "متخصصة في علاج الجذور والتجميل والابتسامة الهوليودية."),
    mkDoctor("د. أحمد فؤاد", "جراحة الفم والأسنان", ["sunday", "tuesday", "wednesday", "thursday", "friday"], "09:00", "17:00", "01003334445", "جراح فم وأسنان متخصص في الخلع المعقد وزراعة الأسنان."),
    mkDoctor("د. منى حسن", "طب أسنان الأطفال", ["saturday", "monday", "wednesday", "thursday", "friday"], "12:00", "20:00", "01004445556", "طبيبة أسنان أطفال تهتم برعاية صغار المرضى بأسلوب لطيف."),
    mkDoctor("د. يوسف خالد", "تركيبات وزراعة الأسنان", ["sunday", "monday", "wednesday", "thursday", "saturday"], "10:00", "18:00", "01005556667", "خبير التركيبات الثابتة والزرعات والوجه الرقمي للابتسامة."),
  ];

  // Patients, appointments and visits start empty (created by the user / API).
  const patients: Patient[] = [];
  const appointments: Appointment[] = [];
  const visits: Visit[] = [];

  const notifications: AppNotification[] = [];

  const settings: Settings = {
    id: uid("set"),
    clinicName: "عيادة الابتسامة لطب الأسنان",
    clinicPhone: "0223456789",
    clinicAddress: "القاهرة - مدينة نصر، شارع مكرم عبيد",
    clinicEmail: "info@smile-clinic.com",
    doctorName: "د. كريم عبد الله",
    doctorSpecialty: "استشاري تقويم الأسنان",
    workingDays: ["saturday", "sunday", "monday", "tuesday", "wednesday"],
    workingFrom: "09:00",
    workingTo: "22:00",
    currency: "EGP",
    theme: "system",
    notificationsEnabled: true,
    notificationTypes: {
      newAppointment: true,
      newPatient: true,
      visitAdded: true,
      appointmentReminder: true,
    },
    updatedAt: nowIso(),
  };

  const apiLogs: ApiLog[] = Array.from({ length: 6 }).map((_, i) => ({
    id: uid("log"),
    endpoint: pick(["/api/patients", "/api/appointments", "/api/reports/revenue", "/api/visits"]),
    method: pick(["GET", "POST", "PUT"]),
    statusCode: 200,
    responseTime: rand(24, 280),
    createdAt: new Date(Date.now() - i * rand(60000, 900000)).toISOString(),
  }));

  return { patients, doctors, services, appointments, visits, notifications, settings, apiLogs };
}

// ---------------------------------------------------------------------------
// Factory helpers
// ---------------------------------------------------------------------------
function mkDoctor(
  name: string,
  specialty: string,
  workingDays: Doctor["workingDays"],
  workingFrom: string,
  workingTo: string,
  phone: string,
  description: string
): Doctor {
  const created = isoOn(dayKeyFromDays(rand(120, 400)));
  return {
    id: uid("doc"),
    name,
    specialty,
    workingDays,
    workingFrom,
    workingTo,
    phone,
    description,
    createdAt: created,
    updatedAt: created,
    isActive: true,
    isDeleted: false,
    deletedAt: null,
  };
}

function mkService(name: string, price: number, duration: number, description: string): Service {
  const created = isoOn(dayKeyFromDays(rand(120, 400)));
  return {
    id: uid("srv"),
    name,
    price,
    duration,
    description,
    isActive: true,
    createdAt: created,
    updatedAt: created,
    isDeleted: false,
    deletedAt: null,
  };
}

function dayKeyFromDays(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// ---------------------------------------------------------------------------
// Store (the single source of truth, persisted locally)
// ---------------------------------------------------------------------------
function load(): Database {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Database;
      if (parsed && parsed.patients && parsed.settings) return parsed;
    }
  } catch {
    /* ignore corrupt storage */
  }
  const fresh = seed();
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
  } catch {
    /* storage unavailable */
  }
  return fresh;
}

let db: Database = load();

function persist(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch {
    /* ignore */
  }
}

export const store = {
  read(): Database {
    return db;
  },
  write(mutator: (d: Database) => void): void {
    mutator(db);
    persist();
  },
  reset(): Database {
    db = seed();
    persist();
    return db;
  },
};
