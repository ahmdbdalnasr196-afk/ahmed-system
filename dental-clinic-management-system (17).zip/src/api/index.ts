import { store } from "@/lib/store";
import type {
  ApiLog,
  Appointment,
  AppointmentStatus,
  ChartPoint,
  Doctor,
  NotificationCategory,
  NotificationType,
  Patient,
  PatientSearchResult,
  ReportPeriod,
  RelatedType,
  Service,
  Settings,
  Visit,
  AppNotification,
} from "@/types";
import {
  addMinutes,
  ARABIC_MONTHS,
  ARABIC_MONTHS_SHORT,
  minutesToTime,
  normalizeArabic,
  nowIso,
  pad,
  parseDateKey,
  rangesOverlap,
  timeToMinutes,
  todayKey,
  uid,
  weekdayShort,
  weekdayOf,
} from "@/utils/format";

// ---------------------------------------------------------------------------
// Infrastructure: simulated network + API logging
// ---------------------------------------------------------------------------
export class ApiError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ApiError";
  }
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function delay(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, randInt(160, 460)));
}

function logRequest(endpoint: string, method: string, statusCode: number): void {
  store.write((d) => {
    d.apiLogs.push({
      id: uid("log"),
      endpoint,
      method,
      statusCode,
      responseTime: randInt(18, 320),
      createdAt: nowIso(),
    });
    if (d.apiLogs.length > 400) d.apiLogs.splice(0, d.apiLogs.length - 400);
  });
}

async function run<T>(
  endpoint: string,
  method: string,
  fn: () => T
): Promise<T> {
  await delay();
  try {
    const result = fn();
    logRequest(endpoint, method, 200);
    return result;
  } catch (e) {
    logRequest(endpoint, method, e instanceof ApiError ? 400 : 500);
    throw e;
  }
}

function pushNotification(
  type: NotificationType,
  relatedType: RelatedType,
  title: string,
  message: string,
  relatedId?: string,
  check?: (s: Settings) => boolean,
  meta?: { key?: string; category?: NotificationCategory }
): void {
  store.write((d) => {
    if (check && !check(d.settings)) return;
    if (meta?.key && d.notifications.some((n) => n.key === meta.key)) return;
    d.notifications.unshift({
      id: uid("not"),
      key: meta?.key,
      category: meta?.category,
      title,
      message,
      type,
      relatedType,
      relatedId,
      isRead: false,
      createdAt: nowIso(),
    });
    if (d.notifications.length > 80) d.notifications.length = 80;
  });
}

// ---------------------------------------------------------------------------
// Name/phone resolution (AI compatible - never requires internal IDs)
// ---------------------------------------------------------------------------
function findDoctorByName(name: string): Doctor | undefined {
  const { doctors } = store.read();
  const norm = name.trim().toLowerCase();
  return (
    doctors.find((d) => !d.isDeleted && d.isActive && d.name.toLowerCase() === norm) ||
    doctors.find((d) => !d.isDeleted && d.isActive && d.name.toLowerCase().includes(norm)) ||
    doctors.find((d) => !d.isDeleted && d.isActive && norm.includes(d.name.toLowerCase()))
  );
}

function findServiceByName(name: string): Service | undefined {
  const { services } = store.read();
  const norm = name.trim().toLowerCase();
  return (
    services.find((s) => !s.isDeleted && s.isActive && s.name.toLowerCase() === norm) ||
    services.find((s) => !s.isDeleted && s.isActive && s.name.toLowerCase().includes(norm))
  );
}

function findPatientByPhone(phone: string): Patient | undefined {
  const { patients } = store.read();
  const norm = phone.trim();
  return patients.find((p) => !p.isDeleted && p.phone === norm);
}

function findPatientByName(name: string): Patient | undefined {
  const { patients } = store.read();
  const norm = name.trim().toLowerCase();
  return (
    patients.find((p) => !p.isDeleted && p.name.toLowerCase() === norm) ||
    patients.find((p) => !p.isDeleted && p.name.toLowerCase().includes(norm))
  );
}

// ---------------------------------------------------------------------------
// Computed statistics (always calculated, never stored)
// ---------------------------------------------------------------------------
interface PatientStats {
  visitsCount: number;
  lastVisit: string | null;
  totalPaid: number;
  remainingBalance: number;
  upcomingAppointments: number;
}

function patientStats(patientId: string): PatientStats {
  const { visits, appointments } = store.read();
  const pv = visits.filter((v) => !v.isDeleted && v.patientId === patientId);
  const lastVisit = pv.length
    ? pv.reduce((a, b) => (b.visitDate > a.visitDate ? b : a)).visitDate
    : null;
  return {
    visitsCount: pv.length,
    lastVisit,
    totalPaid: pv.reduce((s, v) => s + v.paidAmount, 0),
    remainingBalance: pv.reduce((s, v) => s + v.remainingAmount, 0),
    upcomingAppointments: appointments.filter(
      (a) =>
        !a.isDeleted &&
        a.patientId === patientId &&
        a.date >= todayKey() &&
        (a.status === "pending" || a.status === "confirmed")
    ).length,
  };
}

interface DoctorStats {
  patientsCount: number;
  appointmentsCount: number;
  completedVisits: number;
  totalRevenue: number;
  averageVisitValue: number;
  topService: string;
  monthlyVisits: ChartPoint[];
}

function doctorStats(doctorId: string): DoctorStats {
  const { visits, appointments } = store.read();
  const dv = visits.filter((v) => !v.isDeleted && v.doctorId === doctorId);
  const totalRevenue = dv.reduce((s, v) => s + v.paidAmount, 0);
  const monthlyVisits: ChartPoint[] = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date();
    d.setDate(1);
    d.setMonth(d.getMonth() - i);
    const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    const count = dv.filter((v) => v.visitDate.startsWith(key)).length;
    monthlyVisits.push({ label: ARABIC_MONTHS_SHORT[d.getMonth()], count, amount: 0 });
  }
  const serviceCounts = new Map<string, number>();
  let topService = "—";
  let topCount = 0;
  dv.forEach((v) => {
    const name = store.read().services.find((s) => s.id === v.serviceId)?.name ?? "غير معروف";
    const c = (serviceCounts.get(name) ?? 0) + 1;
    serviceCounts.set(name, c);
    if (c > topCount) {
      topCount = c;
      topService = name;
    }
  });
  return {
    patientsCount: new Set(dv.map((v) => v.patientId)).size,
    appointmentsCount: appointments.filter(
      (a) => !a.isDeleted && a.doctorId === doctorId
    ).length,
    completedVisits: dv.length,
    totalRevenue,
    averageVisitValue: dv.length ? totalRevenue / dv.length : 0,
    topService,
    monthlyVisits,
  };
}

interface ServiceStats {
  visitsCount: number;
  totalRevenue: number;
  doctorIds: string[];
}

function serviceStats(serviceId: string): ServiceStats {
  const { visits } = store.read();
  const sv = visits.filter((v) => !v.isDeleted && v.serviceId === serviceId);
  return {
    visitsCount: sv.length,
    totalRevenue: sv.reduce((s, v) => s + v.paidAmount, 0),
    doctorIds: [...new Set(sv.map((v) => v.doctorId))],
  };
}

// ---------------------------------------------------------------------------
// Period bucketing for reports
// ---------------------------------------------------------------------------
interface Bucket {
  key: string;
  label: string;
  startMs: number;
  endMs: number;
}

function periodRange(period: ReportPeriod): { start: Date; buckets: Bucket[] } {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const buckets: Bucket[] = [];

  const daily = (count: number) => {
    for (let i = count - 1; i >= 0; i--) {
      const s = new Date(today);
      s.setDate(s.getDate() - i);
      const e = new Date(s);
      e.setDate(e.getDate() + 1);
      buckets.push({
        key: `${s.getFullYear()}-${pad(s.getMonth() + 1)}-${pad(s.getDate())}`,
        label: `${s.getDate()} ${ARABIC_MONTHS_SHORT[s.getMonth()]}`,
        startMs: s.getTime(),
        endMs: e.getTime(),
      });
    }
  };
  const monthly = (count: number) => {
    for (let i = count - 1; i >= 0; i--) {
      const s = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const e = new Date(s.getFullYear(), s.getMonth() + 1, 1);
      buckets.push({
        key: `${s.getFullYear()}-${pad(s.getMonth() + 1)}`,
        label: ARABIC_MONTHS[s.getMonth()],
        startMs: s.getTime(),
        endMs: e.getTime(),
      });
    }
  };

  switch (period) {
    case "week":
      daily(7);
      break;
    case "month":
      daily(30);
      break;
    case "3months":
      monthly(3);
      break;
    case "6months":
      monthly(6);
      break;
    case "year":
      monthly(12);
      break;
  }
  return { start: new Date(buckets[0].startMs), buckets };
}

function visitMs(v: Visit): number {
  return parseDateKey(v.visitDate).getTime();
}

function patientCreatedMs(p: Patient): number {
  return new Date(p.createdAt).getTime();
}

// ---------------------------------------------------------------------------
// Availability
// ---------------------------------------------------------------------------
interface AvailabilityInput {
  doctorId: string;
  serviceId: string;
  date: string;
  time: string;
  excludeId?: string;
}

interface AvailabilityResult {
  available: boolean;
  message: string;
  nextAvailable?: string;
}

function checkAvailabilityInternal(input: AvailabilityInput): AvailabilityResult {
  const { settings, doctors, services, appointments } = store.read();
  const doctor = doctors.find((d) => d.id === input.doctorId && !d.isDeleted);
  const service = services.find((s) => s.id === input.serviceId && !s.isDeleted);
  if (!doctor || !service) {
    return { available: false, message: "الطبيب أو الخدمة غير موجودة" };
  }

  const clinicFrom = timeToMinutes(settings.workingFrom);
  const clinicTo = timeToMinutes(settings.workingTo);
  const start = timeToMinutes(input.time);
  const end = start + service.duration;

  if (!doctor.workingDays.includes(weekdayOf(input.date))) {
    return { available: false, message: "الطبيب غير متاح في هذا اليوم" };
  }
  if (start < clinicFrom || end > clinicTo) {
    return {
      available: false,
      message: "هذا الموعد خارج ساعات عمل العيادة",
      nextAvailable: suggestSlot(input),
    };
  }
  if (start < timeToMinutes(doctor.workingFrom) || end > timeToMinutes(doctor.workingTo)) {
    return {
      available: false,
      message: "الوقت خارج ساعات عمل الطبيب",
      nextAvailable: suggestSlot(input),
    };
  }

  const conflicts = appointments.filter(
    (a) =>
      !a.isDeleted &&
      a.doctorId === input.doctorId &&
      a.date === input.date &&
      a.status !== "cancelled" &&
      a.id !== input.excludeId &&
      rangesOverlap(start, end, timeToMinutes(a.time), timeToMinutes(a.endTime))
  );
  if (conflicts.length) {
    return {
      available: false,
      message: "الموعد غير متاح - يوجد تعارض في جدول الطبيب",
      nextAvailable: suggestSlot(input),
    };
  }
  return { available: true, message: "الموعد متاح" };
}

function suggestSlot(input: AvailabilityInput): string | undefined {
  const slots = getSlotsInternal(input);
  return slots[0];
}

function getSlotsInternal(input: Omit<AvailabilityInput, "time">): string[] {
  const { settings, doctors, services, appointments } = store.read();
  const doctor = doctors.find((d) => d.id === input.doctorId && !d.isDeleted);
  const service = services.find((s) => s.id === input.serviceId && !s.isDeleted);
  if (!doctor || !service) return [];

  if (!doctor.workingDays.includes(weekdayOf(input.date))) return [];

  const from = Math.max(
    timeToMinutes(settings.workingFrom),
    timeToMinutes(doctor.workingFrom)
  );
  const to = Math.min(timeToMinutes(settings.workingTo), timeToMinutes(doctor.workingTo));
  const dur = service.duration;
  const dayApps = appointments.filter(
    (a) =>
      !a.isDeleted &&
      a.doctorId === input.doctorId &&
      a.date === input.date &&
      a.status !== "cancelled" &&
      a.id !== input.excludeId
  );
  const slots: string[] = [];
  for (let t = from; t + dur <= to; t += 15) {
    const end = t + dur;
    const conflict = dayApps.some((a) =>
      rangesOverlap(t, end, timeToMinutes(a.time), timeToMinutes(a.endTime))
    );
    if (!conflict) slots.push(minutesToTime(t));
  }
  return slots;
}

// ---------------------------------------------------------------------------
// Public API surface
// ---------------------------------------------------------------------------
export const api = {
  // ---- Health / Settings ----
  health(): Promise<{ status: string; database: string; api: string }> {
    return run("/api/health", "GET", () => ({
      status: "connected",
      database: "connected",
      api: "connected",
    }));
  },

  getSettings(): Promise<Settings> {
    return run("/api/settings", "GET", () => ({ ...store.read().settings }));
  },

  updateSettings(patch: Partial<Settings>): Promise<Settings> {
    return run("/api/settings", "PUT", () => {
      let updated!: Settings;
      store.write((d) => {
        d.settings = { ...d.settings, ...patch, updatedAt: nowIso() };
        updated = d.settings;
      });
      return updated;
    });
  },

  // ---- Patients ----
  getPatients(): Promise<Patient[]> {
    return run("/api/patients", "GET", () =>
      store.read().patients.filter((p) => !p.isDeleted)
    );
  },

  searchPatients(query: { phone?: string; name?: string }): Promise<Patient | null> {
    return run("/api/patients/search", "GET", () => {
      const list = store.read().patients.filter((p) => !p.isDeleted);
      const phone = query.phone?.trim();
      const name = query.name?.trim().toLowerCase();
      if (phone) return list.find((p) => p.phone === phone) ?? null;
      if (name)
        return (
          list.find((p) => normalizeArabic(p.name) === normalizeArabic(name)) ??
          list.find((p) => normalizeArabic(p.name).includes(normalizeArabic(name))) ??
          null
        );
      return null;
    });
  },

  // Advanced multi-result search used by the patient picker (debounced client-side).
  searchPatientsAdvanced(query: string, limit = 8): Promise<PatientSearchResult[]> {
    return run("/api/patients/search", "GET", () => {
      const q = normalizeArabic(query);
      if (!q) return [];
      const { patients, visits } = store.read();
      return patients
        .filter((p) => !p.isDeleted)
        .filter(
          (p) =>
            normalizeArabic(p.name).includes(q) ||
            normalizeArabic(p.phone).includes(q)
        )
        .slice(0, 40)
        .map((p) => {
          const pv = visits.filter((v) => !v.isDeleted && v.patientId === p.id);
          const lastVisit = pv.length
            ? pv.reduce((a, b) => (b.visitDate > a.visitDate ? b : a)).visitDate
            : null;
          return {
            id: p.id,
            name: p.name,
            phone: p.phone,
            age: p.age,
            gender: p.gender,
            visitsCount: pv.length,
            lastVisit,
          };
        })
        .slice(0, limit);
    });
  },

  getPatient(id: string): Promise<Patient & PatientStats & { visits: Visit[] }> {
    return run(`/api/patients/${id}`, "GET", () => {
      const { patients, visits } = store.read();
      const patient = patients.find((p) => p.id === id);
      if (!patient) throw new ApiError("المريض غير موجود");
      const patientVisits = visits
        .filter((v) => !v.isDeleted && v.patientId === id)
        .sort((a, b) => (a.visitDate < b.visitDate ? 1 : -1));
      return { ...patient, ...patientStats(id), visits: patientVisits };
    });
  },

  createPatient(input: {
    name: string;
    phone: string;
    age: number;
    gender: Patient["gender"];
    address?: string;
    notes?: string;
  }): Promise<Patient> {
    return run("/api/patients", "POST", () => {
      const { patients } = store.read();
      if (input.name.trim().length < 3) throw new ApiError("الاسم يجب أن يكون 3 أحرف على الأقل");
      if (patients.some((p) => !p.isDeleted && p.phone === input.phone.trim()))
        throw new ApiError("رقم الهاتف مستخدم بالفعل");
      const created: Patient = {
        id: uid("pat"),
        name: input.name.trim(),
        phone: input.phone.trim(),
        age: input.age,
        gender: input.gender,
        address: input.address?.trim() || "",
        notes: input.notes?.trim() || "",
        createdAt: nowIso(),
        updatedAt: nowIso(),
        isDeleted: false,
        deletedAt: null,
      };
      store.write((d) => {
        d.patients.unshift(created);
      });
      pushNotification(
        "info",
        "patient",
        "👤 تم إنشاء ملف مريض",
        `تمت إضافة المريض ${created.name} إلى قاعدة البيانات.`,
        created.id,
        (s) => s.notificationTypes.newPatient,
        { category: "patient" }
      );
      return created;
    });
  },

  updatePatient(id: string, patch: Partial<Patient>): Promise<Patient> {
    return run(`/api/patients/${id}`, "PUT", () => {
      const { patients } = store.read();
      if (
        patch.phone &&
        patients.some((p) => !p.isDeleted && p.id !== id && p.phone === patch.phone!.trim())
      )
        throw new ApiError("رقم الهاتف مستخدم بالفعل");
      let updated!: Patient;
      store.write((d) => {
        const idx = d.patients.findIndex((p) => p.id === id);
        if (idx === -1) throw new ApiError("المريض غير موجود");
        d.patients[idx] = { ...d.patients[idx], ...patch, updatedAt: nowIso() };
        updated = d.patients[idx];
      });
      pushNotification("info", "patient", "👤 تم تحديث بيانات مريض", `تم تحديث بيانات ${updated.name}.`, id, (s) => s.notificationsEnabled, { category: "patient" });
      return updated;
    });
  },

  deletePatient(id: string): Promise<{ id: string }> {
    let name = "المريض";
    return run(`/api/patients/${id}`, "DELETE", () => {
      store.write((d) => {
        const p = d.patients.find((x) => x.id === id);
        if (!p) throw new ApiError("المريض غير موجود");
        name = p.name;
        p.isDeleted = true;
        p.deletedAt = nowIso();
        p.updatedAt = nowIso();
      });
      pushNotification("warning", "patient", "👤 تم حذف مريض", `تم حذف المريض ${name} (إخفاء فقط).`, id, (s) => s.notificationsEnabled, { category: "patient" });
      return { id };
    });
  },

  getPatientVisits(patientId: string): Promise<Visit[]> {
    return run(`/api/patients/${patientId}/visits`, "GET", () =>
      store.read().visits
        .filter((v) => !v.isDeleted && v.patientId === patientId)
        .sort((a, b) => (a.visitDate < b.visitDate ? 1 : -1))
    );
  },

  // ---- Doctors ----
  getDoctors(): Promise<Doctor[]> {
    return run("/api/doctors", "GET", () =>
      store.read().doctors.filter((d) => !d.isDeleted && d.isActive)
    );
  },

  getDoctor(id: string): Promise<Doctor & DoctorStats> {
    return run(`/api/doctors/${id}`, "GET", () => {
      const doctor = store.read().doctors.find((d) => d.id === id && !d.isDeleted);
      if (!doctor) throw new ApiError("الطبيب غير موجود");
      return { ...doctor, ...doctorStats(id) };
    });
  },

  createDoctor(input: {
    name: string;
    specialty: string;
    phone?: string;
    description?: string;
    workingDays: Doctor["workingDays"];
    workingFrom: string;
    workingTo: string;
    image?: string;
  }): Promise<Doctor> {
    return run("/api/doctors", "POST", () => {
      if (input.name.trim().length < 3) throw new ApiError("اسم الطبيب يجب أن يكون 3 أحرف على الأقل");
      if (!input.specialty.trim()) throw new ApiError("التخصص مطلوب");
      if (!input.workingDays.length) throw new ApiError("يجب اختيار يوم عمل واحد على الأقل");
      if (timeToMinutes(input.workingTo) <= timeToMinutes(input.workingFrom))
        throw new ApiError("نهاية العمل يجب أن تكون بعد بداية العمل");
      const created: Doctor = {
        id: uid("doc"),
        name: input.name.trim(),
        specialty: input.specialty.trim(),
        phone: input.phone?.trim() || "",
        description: input.description?.trim() || "",
        workingDays: input.workingDays,
        workingFrom: input.workingFrom,
        workingTo: input.workingTo,
        image: input.image,
        createdAt: nowIso(),
        updatedAt: nowIso(),
        isActive: true,
        isDeleted: false,
        deletedAt: null,
      };
      store.write((d) => {
        d.doctors.unshift(created);
      });
      pushNotification(
        "info",
        "doctor",
        "👨‍⚕️ تم إضافة طبيب جديد",
        `تمت إضافة الطبيب ${created.name} (${created.specialty}).`,
        created.id,
        (s) => s.notificationsEnabled,
        { category: "doctor" }
      );
      return created;
    });
  },

  updateDoctor(id: string, patch: Partial<Doctor>): Promise<Doctor> {
    return run(`/api/doctors/${id}`, "PUT", () => {
      let updated!: Doctor;
      store.write((d) => {
        const idx = d.doctors.findIndex((x) => x.id === id);
        if (idx === -1) throw new ApiError("الطبيب غير موجود");
        if (patch.workingTo && patch.workingFrom && timeToMinutes(patch.workingTo) <= timeToMinutes(patch.workingFrom))
          throw new ApiError("نهاية العمل يجب أن تكون بعد بداية العمل");
        d.doctors[idx] = { ...d.doctors[idx], ...patch, updatedAt: nowIso() };
        updated = d.doctors[idx];
      });
      pushNotification("info", "doctor", "👨‍⚕️ تم تعديل بيانات طبيب", `تم تحديث بيانات ${updated.name}.`, id, (s) => s.notificationsEnabled, { category: "doctor" });
      return updated;
    });
  },

  deleteDoctor(id: string): Promise<{ id: string }> {
    let name = "الطبيب";
    return run(`/api/doctors/${id}`, "DELETE", () => {
      store.write((d) => {
        const doc = d.doctors.find((x) => x.id === id);
        if (!doc) throw new ApiError("الطبيب غير موجود");
        name = doc.name;
        doc.isDeleted = true;
        doc.isActive = false;
        doc.deletedAt = nowIso();
      });
      pushNotification("warning", "doctor", "👨‍⚕️ تم حذف طبيب", `تم حذف الطبيب ${name} (أصبح غير نشط).`, id, (s) => s.notificationsEnabled, { category: "doctor" });
      return { id };
    });
  },

  // ---- Services ----
  getServices(): Promise<Service[]> {
    return run("/api/services", "GET", () =>
      store.read().services.filter((s) => !s.isDeleted && s.isActive)
    );
  },

  getService(id: string): Promise<Service & ServiceStats> {
    return run(`/api/services/${id}`, "GET", () => {
      const service = store.read().services.find((s) => s.id === id && !s.isDeleted);
      if (!service) throw new ApiError("الخدمة غير موجودة");
      return { ...service, ...serviceStats(id) };
    });
  },

  createService(input: {
    name: string;
    price: number;
    duration: number;
    description?: string;
  }): Promise<Service> {
    return run("/api/services", "POST", () => {
      if (input.name.trim().length < 2) throw new ApiError("اسم الخدمة يجب أن يكون حرفين على الأقل");
      if (input.price < 0) throw new ApiError("السعر لا يمكن أن يكون سالباً");
      if (!input.duration || input.duration < 5) throw new ApiError("مدة الخدمة غير صحيحة");
      const created: Service = {
        id: uid("srv"),
        name: input.name.trim(),
        price: input.price,
        duration: input.duration,
        description: input.description?.trim() || "",
        isActive: true,
        createdAt: nowIso(),
        updatedAt: nowIso(),
        isDeleted: false,
        deletedAt: null,
      };
      store.write((d) => {
        d.services.unshift(created);
      });
      pushNotification("success", "service", "🦷 تم إضافة خدمة جديدة", `تمت إضافة خدمة ${created.name} بسعر ${created.price} ج.م.`, created.id, (s) => s.notificationsEnabled, { category: "service" });
      return created;
    });
  },

  updateService(id: string, patch: Partial<Service>): Promise<Service> {
    return run(`/api/services/${id}`, "PUT", () => {
      let updated!: Service;
      store.write((d) => {
        const idx = d.services.findIndex((x) => x.id === id);
        if (idx === -1) throw new ApiError("الخدمة غير موجودة");
        if (patch.price !== undefined && patch.price < 0) throw new ApiError("السعر لا يمكن أن يكون سالباً");
        d.services[idx] = { ...d.services[idx], ...patch, updatedAt: nowIso() };
        updated = d.services[idx];
      });
      pushNotification("info", "service", "🦷 تم تحديث خدمة", `تم تحديث خدمة ${updated.name}.`, id, (s) => s.notificationsEnabled, { category: "service" });
      return updated;
    });
  },

  deleteService(id: string): Promise<{ id: string }> {
    let name = "الخدمة";
    return run(`/api/services/${id}`, "DELETE", () => {
      store.write((d) => {
        const s = d.services.find((x) => x.id === id);
        if (!s) throw new ApiError("الخدمة غير موجودة");
        name = s.name;
        s.isDeleted = true;
        s.isActive = false;
        s.deletedAt = nowIso();
      });
      pushNotification("warning", "service", "🦷 تم حذف خدمة", `تم حذف خدمة ${name} (إخفاء فقط).`, id, (s) => s.notificationsEnabled, { category: "service" });
      return { id };
    });
  },

  // ---- Appointments ----
  getAppointments(): Promise<Appointment[]> {
    return run("/api/appointments", "GET", () =>
      store
        .read()
        .appointments.filter((a) => !a.isDeleted)
        .sort((a, b) => (a.date === b.date ? (a.time < b.time ? -1 : 1) : a.date < b.date ? 1 : -1))
    );
  },

  getSlots(input: Omit<AvailabilityInput, "time">): Promise<string[]> {
    return run("/api/appointments/slots", "GET", () => getSlotsInternal(input));
  },

  checkAvailability(input: AvailabilityInput): Promise<AvailabilityResult> {
    return run("/api/appointments/check", "POST", () => checkAvailabilityInternal(input));
  },

  createAppointment(input: {
    patientName: string;
    phone: string;
    doctorName: string;
    serviceName: string;
    date: string;
    time: string;
    notes?: string;
    patientId?: string;
  }): Promise<Appointment> {
    return run("/api/appointments", "POST", () => {
      const doctor = findDoctorByName(input.doctorName);
      if (!doctor) throw new ApiError("الطبيب غير موجود");
      const service = findServiceByName(input.serviceName);
      if (!service) throw new ApiError("الخدمة غير متاحة حالياً");

      // Resolve patient: explicit selection → phone → name → create (AI compatible).
      let patient: Patient | undefined;
      if (input.patientId)
        patient = store.read().patients.find((p) => p.id === input.patientId && !p.isDeleted);
      if (!patient) patient = findPatientByPhone(input.phone) ?? findPatientByName(input.patientName);
      if (!patient) {
        patient = {
          id: uid("pat"),
          name: input.patientName.trim(),
          phone: input.phone.trim(),
          age: 0,
          gender: "male",
          address: "",
          notes: "تم الإنشاء تلقائياً أثناء حجز موعد.",
          createdAt: nowIso(),
          updatedAt: nowIso(),
          isDeleted: false,
          deletedAt: null,
        };
        store.write((d) => d.patients.unshift(patient!));
        pushNotification(
          "info",
          "patient",
          "👤 تم إنشاء ملف مريض",
          `تم إنشاء ملف ${patient.name} أثناء الحجز.`,
          patient.id,
          (s) => s.notificationTypes.newPatient,
          { category: "patient" }
        );
      }

      const avail = checkAvailabilityInternal({
        doctorId: doctor.id,
        serviceId: service.id,
        date: input.date,
        time: input.time,
      });
      if (!avail.available) throw new ApiError(avail.message);

      const created: Appointment = {
        id: uid("apt"),
        patientId: patient.id,
        doctorId: doctor.id,
        serviceId: service.id,
        date: input.date,
        time: input.time,
        endTime: addMinutes(input.time, service.duration),
        status: "confirmed",
        notes: input.notes?.trim() || "",
        createdAt: nowIso(),
        updatedAt: nowIso(),
        isDeleted: false,
        deletedAt: null,
      };
      store.write((d) => d.appointments.unshift(created));
      pushNotification(
        "success",
        "appointment",
        "📅 تم حجز موعد جديد",
        `موعد مع ${doctor.name} بتاريخ ${input.date} الساعة ${input.time}.`,
        created.id,
        (s) => s.notificationTypes.newAppointment,
        { category: "appointment" }
      );
      return created;
    });
  },

  updateAppointment(
    id: string,
    input: {
      doctorId?: string;
      serviceId?: string;
      date?: string;
      time?: string;
      notes?: string;
      status?: AppointmentStatus;
    }
  ): Promise<Appointment> {
    return run(`/api/appointments/${id}`, "PUT", () => {
      let updated!: Appointment;
      store.write((d) => {
        const idx = d.appointments.findIndex((a) => a.id === id);
        if (idx === -1) throw new ApiError("الموعد غير موجود");
        const current = d.appointments[idx];
        const doctorId = input.doctorId ?? current.doctorId;
        const serviceId = input.serviceId ?? current.serviceId;
        const date = input.date ?? current.date;
        const time = input.time ?? current.time;
        const service = d.services.find((s) => s.id === serviceId)!;
        if (input.doctorId || input.serviceId || input.date || input.time) {
          const avail = checkAvailabilityInternal({
            doctorId,
            serviceId,
            date,
            time,
            excludeId: id,
          });
          if (!avail.available) throw new ApiError(avail.message);
        }
        d.appointments[idx] = {
          ...current,
          doctorId,
          serviceId,
          date,
          time,
          endTime: addMinutes(time, service.duration),
          status: input.status ?? current.status,
          notes: input.notes ?? current.notes,
          updatedAt: nowIso(),
        };
        updated = d.appointments[idx];
      });
      pushNotification("info", "appointment", "📅 تم تعديل موعد", `تم تحديث الموعد بنجاح.`, id, (s) => s.notificationsEnabled, { category: "appointment" });
      return updated;
    });
  },

  cancelAppointment(id: string): Promise<Appointment> {
    return run(`/api/appointments/${id}/cancel`, "PATCH", () => {
      let updated!: Appointment;
      store.write((d) => {
        const idx = d.appointments.findIndex((a) => a.id === id);
        if (idx === -1) throw new ApiError("الموعد غير موجود");
        d.appointments[idx] = {
          ...d.appointments[idx],
          status: "cancelled",
          updatedAt: nowIso(),
        };
        updated = d.appointments[idx];
      });
      pushNotification("warning", "appointment", "🔴 تم إلغاء موعد", `تم إلغاء الموعد.`, id, (s) => s.notificationsEnabled, { category: "appointment" });
      return updated;
    });
  },

  completeAppointment(id: string): Promise<{ appointment: Appointment; visit: Visit }> {
    return run(`/api/appointments/${id}/complete`, "POST", () => {
      let appointment!: Appointment;
      let visit!: Visit;
      store.write((d) => {
        const idx = d.appointments.findIndex((a) => a.id === id);
        if (idx === -1) throw new ApiError("الموعد غير موجود");
        const appt = d.appointments[idx];
        const service = d.services.find((s) => s.id === appt.serviceId)!;
        d.appointments[idx] = { ...appt, status: "completed", updatedAt: nowIso() };
        appointment = d.appointments[idx];
        const existing = d.visits.find(
          (v) => !v.isDeleted && v.appointmentId === id
        );
        if (!existing) {
          const created: Visit = {
            id: uid("vis"),
            patientId: appt.patientId,
            doctorId: appt.doctorId,
            serviceId: appt.serviceId,
            appointmentId: id,
            visitDate: appt.date,
            servicePrice: service.price,
            paidAmount: service.price,
            remainingAmount: 0,
            diagnosis: "",
            treatmentPlan: "",
            notes: appt.notes || "",
            createdAt: nowIso(),
            updatedAt: nowIso(),
            isDeleted: false,
            deletedAt: null,
          };
          d.visits.unshift(created);
          visit = created;
        } else {
          visit = existing;
        }
      });
      pushNotification(
        "success",
        "visit",
        "🦷 تم تسجيل زيارة جديدة",
        `تم إكمال الموعد وتسجيل الزيارة.`,
        visit.id,
        (s) => s.notificationTypes.visitAdded,
        { category: "visit" }
      );
      return { appointment, visit };
    });
  },

  // ---- Visits ----
  getVisits(): Promise<Visit[]> {
    return run("/api/visits", "GET", () =>
      store
        .read()
        .visits.filter((v) => !v.isDeleted)
        .sort((a, b) => (a.visitDate < b.visitDate ? 1 : -1))
    );
  },

  createVisit(input: {
    patientName: string;
    phone?: string;
    doctorName: string;
    serviceName: string;
    visitDate: string;
    price: number;
    paid: number;
    diagnosis?: string;
    treatmentPlan?: string;
    notes?: string;
    patientId?: string;
  }): Promise<Visit> {
    return run("/api/visits", "POST", () => {
      const doctor = findDoctorByName(input.doctorName);
      if (!doctor) throw new ApiError("الطبيب غير موجود");
      const service = findServiceByName(input.serviceName);
      if (!service) throw new ApiError("الخدمة غير متاحة حالياً");
      let patient: Patient | undefined;
      if (input.patientId)
        patient = store.read().patients.find((p) => p.id === input.patientId && !p.isDeleted);
      if (!patient) patient = (input.phone && findPatientByPhone(input.phone)) || findPatientByName(input.patientName);
      if (!patient) {
        patient = {
          id: uid("pat"),
          name: input.patientName.trim(),
          phone: input.phone?.trim() || "",
          age: 0,
          gender: "male",
          address: "",
          notes: "تم الإنشاء تلقائياً عند تسجيل زيارة.",
          createdAt: nowIso(),
          updatedAt: nowIso(),
          isDeleted: false,
          deletedAt: null,
        };
        store.write((d) => d.patients.unshift(patient!));
      }
      const price = Number(input.price) || service.price;
      const paid = Math.min(Number(input.paid) || 0, price);
      const created: Visit = {
        id: uid("vis"),
        patientId: patient.id,
        doctorId: doctor.id,
        serviceId: service.id,
        visitDate: input.visitDate,
        servicePrice: price,
        paidAmount: paid,
        remainingAmount: price - paid,
        diagnosis: input.diagnosis?.trim() || "",
        treatmentPlan: input.treatmentPlan?.trim() || "",
        notes: input.notes?.trim() || "",
        createdAt: nowIso(),
        updatedAt: nowIso(),
        isDeleted: false,
        deletedAt: null,
      };
      store.write((d) => d.visits.unshift(created));
      pushNotification(
        "success",
        "visit",
        "🦷 تم تسجيل زيارة جديدة",
        `زيارة ${service.name} للمريض ${patient!.name}.`,
        created.id,
        (s) => s.notificationTypes.visitAdded,
        { category: "visit" }
      );
      return created;
    });
  },

  updateVisit(id: string, patch: Partial<Visit>): Promise<Visit> {
    return run(`/api/visits/${id}`, "PUT", () => {
      let updated!: Visit;
      store.write((d) => {
        const idx = d.visits.findIndex((v) => v.id === id);
        if (idx === -1) throw new ApiError("الزيارة غير موجودة");
        const current = d.visits[idx];
        const price = patch.servicePrice ?? current.servicePrice;
        const paid =
          patch.paidAmount !== undefined ? Math.min(patch.paidAmount, price) : current.paidAmount;
        d.visits[idx] = {
          ...current,
          ...patch,
          servicePrice: price,
          paidAmount: paid,
          remainingAmount: price - paid,
          updatedAt: nowIso(),
        };
        updated = d.visits[idx];
      });
      pushNotification("info", "visit", "🦷 تم تحديث زيارة", `تم تحديث بيانات الزيارة.`, id, (s) => s.notificationsEnabled, { category: "visit" });
      return updated;
    });
  },

  deleteVisit(id: string): Promise<{ id: string }> {
    return run(`/api/visits/${id}`, "DELETE", () => {
      store.write((d) => {
        const v = d.visits.find((x) => x.id === id);
        if (!v) throw new ApiError("الزيارة غير موجودة");
        v.isDeleted = true;
        v.deletedAt = nowIso();
      });
      return { id };
    });
  },

  // ---- Notifications ----
  getNotifications(): Promise<AppNotification[]> {
    return run("/api/notifications", "GET", () => [...store.read().notifications]);
  },

  markNotificationRead(id: string): Promise<void> {
    return run(`/api/notifications/${id}/read`, "PATCH", () => {
      store.write((d) => {
        const n = d.notifications.find((x) => x.id === id);
        if (n) n.isRead = true;
      });
    });
  },

  markAllNotificationsRead(): Promise<void> {
    return run("/api/notifications/read-all", "PATCH", () => {
      store.write((d) => d.notifications.forEach((n) => (n.isRead = true)));
    });
  },

  clearNotifications(): Promise<void> {
    return run("/api/notifications", "DELETE", () => {
      store.write((d) => {
        d.notifications = [];
      });
    });
  },

  // ---- Dashboard selectors ----
  getDashboardStats(): Promise<{
    patientsCount: number;
    doctorsCount: number;
    todayAppointments: number;
    todayRevenue: number;
  }> {
    return run("/api/dashboard/stats", "GET", () => {
      const { patients, doctors, appointments, visits } = store.read();
      const today = todayKey();
      return {
        patientsCount: patients.filter((p) => !p.isDeleted).length,
        doctorsCount: doctors.filter((d) => !d.isDeleted && d.isActive).length,
        todayAppointments: appointments.filter(
          (a) => !a.isDeleted && a.date === today && a.status !== "cancelled"
        ).length,
        todayRevenue: visits
          .filter((v) => !v.isDeleted && v.visitDate === today)
          .reduce((s, v) => s + v.paidAmount, 0),
      };
    });
  },

  // ---- Smart reminder engine (idempotent, persisted, never duplicated) ----
  // Generates daily summary, 15-minute reminders, and missed-appointment alerts.
  runReminderEngine(): AppNotification[] {
    const { appointments, settings, patients, doctors } = store.read();
    if (!settings.notificationsEnabled) return [];
    const created: AppNotification[] = [];

    const addIfNew = (
      notif: Omit<AppNotification, "id" | "isRead" | "createdAt"> & { key: string }
    ) => {
      if (store.read().notifications.some((n) => n.key === notif.key)) return;
      const record: AppNotification = {
        ...notif,
        id: uid("not"),
        isRead: false,
        createdAt: nowIso(),
      };
      store.write((d) => {
        if (d.notifications.some((n) => n.key === notif.key)) return;
        d.notifications.unshift(record);
        if (d.notifications.length > 80) d.notifications.length = 80;
      });
      created.push(record);
    };

    const patientName = (id: string) =>
      patients.find((p) => p.id === id)?.name ?? "المريض";
    const doctorName = (id: string) =>
      doctors.find((d) => d.id === id)?.name ?? "الطبيب";

    const today = todayKey();
    const now = Date.now();
    const reminderOn = settings.notificationTypes.appointmentReminder;

    // 1) Daily summary (once per working day)
    if (reminderOn) {
      const todayCount = appointments.filter(
        (a) => !a.isDeleted && a.date === today && a.status !== "cancelled"
      ).length;
      addIfNew({
        key: `daily-${today}`,
        title: "📅 مواعيد اليوم",
        message:
          todayCount > 0
            ? `لديك ${todayCount} موعدًا مجدولًا اليوم.`
            : "لا توجد مواعيد مجدولة اليوم.",
        type: "info",
        relatedType: "appointment",
        category: "reminder",
      });
    }

    // 2) 15-minute reminders + 3) missed appointments
    appointments
      .filter(
        (a) =>
          !a.isDeleted &&
          a.date === today &&
          (a.status === "pending" || a.status === "confirmed")
      )
      .forEach((a) => {
        const t = new Date(`${today}T${a.time}:00`).getTime();
        const diff = t - now;
        if (reminderOn && diff > 0 && diff <= 15 * 60000) {
          addIfNew({
            key: `reminder-15-${a.id}-${today}`,
            title: "⏰ تذكير بموعد",
            message: `متبقي 15 دقيقة على موعد ${patientName(a.patientId)} مع ${doctorName(a.doctorId)}.`,
            type: "warning",
            relatedType: "appointment",
            relatedId: a.id,
            category: "reminder",
          });
        }
        if (diff < -60000) {
          addIfNew({
            key: `missed-${a.id}-${today}`,
            title: "⚠️ موعد فائت",
            message: `موعد ${patientName(a.patientId)} انتهى ولم يتم تسجيل زيارة.`,
            type: "error",
            relatedType: "appointment",
            relatedId: a.id,
            category: "warning",
          });
        }
      });

    return created;
  },

  getDynamicNotifications(): AppNotification[] {
    return [];
  },

  // ---- Reports ----
  revenueReport(period: ReportPeriod): Promise<{
    totalRevenue: number;
    averageVisitValue: number;
    completedVisits: number;
    chart: ChartPoint[];
  }> {
    return run("/api/reports/revenue", "GET", () => {
      const { buckets } = periodRange(period);
      const visits = store.read().visits.filter((v) => !v.isDeleted);
      const chart = buckets.map((b) => ({
        label: b.label,
        amount: visits
          .filter((v) => {
            const t = visitMs(v);
            return t >= b.startMs && t < b.endMs;
          })
          .reduce((s, v) => s + v.paidAmount, 0),
      }));
      const start = buckets[0].startMs;
      const end = buckets[buckets.length - 1].endMs;
      const inRange = visits.filter((v) => {
        const t = visitMs(v);
        return t >= start && t < end;
      });
      const totalRevenue = inRange.reduce((s, v) => s + v.paidAmount, 0);
      return {
        totalRevenue,
        completedVisits: inRange.length,
        averageVisitValue: inRange.length ? totalRevenue / inRange.length : 0,
        chart,
      };
    });
  },

  appointmentsReport(period: ReportPeriod): Promise<{
    appointmentsCount: number;
    pending: number;
    confirmed: number;
    completed: number;
    cancelled: number;
    no_show: number;
    chart: ChartPoint[];
  }> {
    return run("/api/reports/appointments", "GET", () => {
      const { buckets } = periodRange(period);
      const apps = store.read().appointments.filter((a) => !a.isDeleted);
      const chart = buckets.map((b) => ({
        label: b.label,
        amount: 0,
        count: apps.filter((a) => {
          const t = parseDateKey(a.date).getTime();
          return t >= b.startMs && t < b.endMs;
        }).length,
      }));
      const start = buckets[0].startMs;
      const end = buckets[buckets.length - 1].endMs;
      const inRange = apps.filter((a) => {
        const t = parseDateKey(a.date).getTime();
        return t >= start && t < end;
      });
      const count = (s: AppointmentStatus) => inRange.filter((a) => a.status === s).length;
      return {
        appointmentsCount: inRange.length,
        pending: count("pending"),
        confirmed: count("confirmed"),
        completed: count("completed"),
        cancelled: count("cancelled"),
        no_show: count("no_show"),
        chart,
      };
    });
  },

  patientsReport(period: ReportPeriod): Promise<{
    totalPatients: number;
    newPatients: number;
    returningPatients: number;
    chart: ChartPoint[];
  }> {
    return run("/api/reports/patients", "GET", () => {
      const { buckets } = periodRange(period);
      const { patients, visits } = store.read();
      const active = patients.filter((p) => !p.isDeleted);
      const start = buckets[0].startMs;
      const end = buckets[buckets.length - 1].endMs;
      const newPatients = active.filter((p) => {
        const t = patientCreatedMs(p);
        return t >= start && t < end;
      }).length;
      const returningPatients = active.filter((p) => {
        const c = visits.filter((v) => !v.isDeleted && v.patientId === p.id).length;
        return c >= 2;
      }).length;
      const chart = buckets.map((b) => ({
        label: b.label,
        amount: 0,
        count: active.filter((p) => {
          const t = patientCreatedMs(p);
          return t >= b.startMs && t < b.endMs;
        }).length,
      }));
      return {
        totalPatients: active.length,
        newPatients,
        returningPatients,
        chart,
      };
    });
  },

  doctorsReport(period: ReportPeriod): Promise<
    { name: string; specialty: string; id: string; visits: number; revenue: number; patients: number; topService: string }[]
  > {
    return run("/api/reports/doctors", "GET", () => {
      const { buckets } = periodRange(period);
      const start = buckets[0].startMs;
      const end = buckets[buckets.length - 1].endMs;
      const { doctors, visits, services } = store.read();
      return doctors
        .filter((d) => !d.isDeleted && d.isActive)
        .map((d) => {
          const dv = visits.filter(
            (v) =>
              !v.isDeleted &&
              v.doctorId === d.id &&
              visitMs(v) >= start &&
              visitMs(v) < end
          );
          const svcCount = new Map<string, number>();
          let topService = "—";
          let top = 0;
          dv.forEach((v) => {
            const name = services.find((s) => s.id === v.serviceId)?.name ?? "—";
            const c = (svcCount.get(name) ?? 0) + 1;
            svcCount.set(name, c);
            if (c > top) {
              top = c;
              topService = name;
            }
          });
          return {
            id: d.id,
            name: d.name,
            specialty: d.specialty,
            visits: dv.length,
            revenue: dv.reduce((s, v) => s + v.paidAmount, 0),
            patients: new Set(dv.map((v) => v.patientId)).size,
            topService,
          };
        })
        .filter((d) => d.visits > 0)
        .sort((a, b) => b.visits - a.visits);
    });
  },

  servicesReport(period: ReportPeriod): Promise<{ name: string; count: number; revenue: number }[]> {
    return run("/api/reports/services", "GET", () => {
      const { buckets } = periodRange(period);
      const start = buckets[0].startMs;
      const end = buckets[buckets.length - 1].endMs;
      const { services, visits } = store.read();
      return services
        .filter((s) => !s.isDeleted && s.isActive)
        .map((s) => {
          const sv = visits.filter(
            (v) =>
              !v.isDeleted &&
              v.serviceId === s.id &&
              visitMs(v) >= start &&
              visitMs(v) < end
          );
          return {
            name: s.name,
            count: sv.length,
            revenue: sv.reduce((sum, v) => sum + v.paidAmount, 0),
          };
        })
        .filter((s) => s.count > 0)
        .sort((a, b) => b.count - a.count);
    });
  },

  getApiLogs(): Promise<{ today: number; lastUsed: string | null; recent: ApiLog[] }> {
    return run("/api/logs", "GET", () => {
      const logs = [...store.read().apiLogs].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
      const dayStart = new Date();
      dayStart.setHours(0, 0, 0, 0);
      const today = logs.filter((l) => new Date(l.createdAt).getTime() >= dayStart.getTime()).length;
      return { today, lastUsed: logs[0]?.createdAt ?? null, recent: logs.slice(0, 8) };
    });
  },
};

// keep weekdayShort import used (report-friendly helpers may expand later)
void weekdayShort;
