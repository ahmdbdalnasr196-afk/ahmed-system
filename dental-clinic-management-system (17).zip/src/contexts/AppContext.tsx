import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api, ApiError } from "@/api";
import { store } from "@/lib/store";
import type {
  AppNotification,
  Appointment,
  AppointmentStatus,
  Database,
  Doctor,
  Patient,
  ReportPeriod,
  Service,
  Settings,
  ThemeMode,
  Visit,
} from "@/types";
import { todayKey } from "@/utils/format";

type ToastType = "success" | "warning" | "error" | "info";
export interface Toast {
  id: string;
  type: ToastType;
  message: string;
}

interface SearchResult {
  patients: Patient[];
  doctors: Doctor[];
  services: Service[];
  appointments: Appointment[];
}

interface AppContextValue {
  data: Database;
  refresh: () => void;
  // toasts
  toasts: Toast[];
  toast: (type: ToastType, message: string) => void;
  dismissToast: (id: string) => void;
  // theme
  theme: ThemeMode;
  setTheme: (t: ThemeMode) => void;
  effectiveDark: boolean;
  // settings
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => Promise<void>;
  // notifications
  popupNotification: AppNotification | null;
  dismissPopup: () => void;
  markNotificationRead: (id: string) => void;
  markAllRead: () => void;
  clearNotifications: () => void;
  // global search
  globalSearch: (q: string) => SearchResult;
  // mutations
  createPatient: (input: any) => Promise<Patient>;
  updatePatient: (id: string, patch: Partial<Patient>) => Promise<Patient>;
  deletePatient: (id: string) => Promise<void>;
  createDoctor: (input: any) => Promise<Doctor>;
  updateDoctor: (id: string, patch: Partial<Doctor>) => Promise<Doctor>;
  deleteDoctor: (id: string) => Promise<void>;
  createService: (input: any) => Promise<Service>;
  updateService: (id: string, patch: Partial<Service>) => Promise<Service>;
  deleteService: (id: string) => Promise<void>;
  bookAppointment: (input: any) => Promise<Appointment>;
  updateAppointment: (
    id: string,
    patch: { doctorId?: string; serviceId?: string; date?: string; time?: string; notes?: string; status?: AppointmentStatus }
  ) => Promise<Appointment>;
  cancelAppointment: (id: string) => Promise<void>;
  completeAppointment: (id: string) => Promise<void>;
  createVisit: (input: any) => Promise<Visit>;
  updateVisit: (id: string, patch: Partial<Visit>) => Promise<Visit>;
  deleteVisit: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

function snapshot(): Database {
  const d = store.read();
  return {
    patients: [...d.patients],
    doctors: [...d.doctors],
    services: [...d.services],
    appointments: [...d.appointments],
    visits: [...d.visits],
    notifications: [...d.notifications],
    apiLogs: [...d.apiLogs],
    settings: { ...d.settings },
  };
}

function systemDark(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches;
}

function applyTheme(mode: ThemeMode): boolean {
  const dark = mode === "dark" || (mode === "system" && systemDark());
  document.documentElement.classList.toggle("dark", dark);
  return dark;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<Database>(() => snapshot());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const raw = localStorage.getItem("dental_theme");
      return raw ? (JSON.parse(raw) as ThemeMode) : "system";
    } catch {
      return "system";
    }
  });
  const [effectiveDark, setEffectiveDark] = useState(() => applyTheme(theme));
  const [popupNotification, setPopupNotification] = useState<AppNotification | null>(null);

  const refresh = useCallback(() => setData(snapshot()), []);

  // ---- Theme handling ----
  useEffect(() => {
    localStorage.setItem("dental_theme", JSON.stringify(theme));
    setEffectiveDark(applyTheme(theme));
    if (theme === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const handler = () => setEffectiveDark(applyTheme("system"));
      mq.addEventListener("change", handler);
      return () => mq.removeEventListener("change", handler);
    }
  }, [theme]);

  const setTheme = useCallback((t: ThemeMode) => {
    setThemeState(t);
    store.write((d) => {
      d.settings.theme = t;
      d.settings.updatedAt = new Date().toISOString();
    });
    setData(snapshot());
  }, []);

  // ---- Toasts ----
  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback(
    (type: ToastType, message: string) => {
      const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-2), { id, type, message }]);
    },
    []
  );

  // ---- Notifications popup detection (skip seed notifications on first load) ----
  const knownIds = useRef<Set<string>>(new Set(data.notifications.map((n) => n.id)));
  const mountedRef = useRef(false);
  useEffect(() => {
    mountedRef.current = true;
  }, []);
  useEffect(() => {
    if (!mountedRef.current) return;
    const fresh = data.notifications.filter((n) => !knownIds.current.has(n.id));
    if (!fresh.length) return;
    fresh.forEach((n) => knownIds.current.add(n.id));
    if (!data.settings.notificationsEnabled) return;
    // The smart popup is reserved for system reminders (CRUD feedback uses toasts).
    const reminder = fresh.find(
      (n) => n.category === "reminder" || n.category === "warning"
    );
    if (reminder) setPopupNotification(reminder);
  }, [data.notifications, data.settings.notificationsEnabled]);

  // ---- Smart reminder engine: persisted, idempotent, runs every minute ----
  useEffect(() => {
    let firstRun = true;
    const tick = () => {
      const created = api.runReminderEngine();
      if (!created.length) return;
      // On the very first run treat them as initial state (persist, don't pop).
      if (firstRun) created.forEach((n) => knownIds.current.add(n.id));
      firstRun = false;
      setData(snapshot());
    };
    tick();
    const id = window.setInterval(tick, 60000);
    return () => window.clearInterval(id);
  }, []);

  const dismissPopup = useCallback(() => setPopupNotification(null), []);

  // ---- Mutation wrapper: run API, refresh state, surface toasts ----
  const mutate = useCallback(
    async <T,>(label: { success: string; error: string }, fn: () => Promise<T>): Promise<T> => {
      try {
        const result = await fn();
        setData(snapshot());
        toast("success", label.success);
        return result;
      } catch (e) {
        const message = e instanceof ApiError ? e.message : label.error;
        toast("error", message);
        throw e;
      }
    },
    [toast]
  );

  // ---- Notifications ----
  const markNotificationRead = useCallback(
    async (id: string) => {
      await api.markNotificationRead(id);
      setData(snapshot());
    },
    []
  );
  const markAllRead = useCallback(async () => {
    await api.markAllNotificationsRead();
    setData(snapshot());
    toast("success", "تم تعليم كل الإشعارات كمقروءة");
  }, [toast]);
  const clearNotifications = useCallback(async () => {
    await api.clearNotifications();
    setData(snapshot());
    toast("success", "تم مسح الإشعارات");
  }, [toast]);

  // ---- Settings ----
  const updateSettings = useCallback(
    async (patch: Partial<Settings>) => {
      try {
        await api.updateSettings(patch);
        setData(snapshot());
        toast("success", "تم حفظ التعديلات");
      } catch {
        toast("error", "تعذر حفظ التعديلات");
      }
    },
    [toast]
  );

  // ---- CRUD ----
  const createPatient = useCallback(
    (input: any) =>
      mutate({ success: "تم إنشاء ملف المريض بنجاح", error: "تعذر إنشاء ملف المريض" }, () =>
        api.createPatient(input)
      ),
    [mutate]
  );
  const updatePatient = useCallback(
    (id: string, patch: Partial<Patient>) =>
      mutate({ success: "تم تحديث بيانات المريض", error: "تعذر تحديث بيانات المريض" }, () =>
        api.updatePatient(id, patch)
      ),
    [mutate]
  );
  const deletePatient = useCallback(
    (id: string) =>
      mutate({ success: "تم حذف المريض", error: "تعذر حذف المريض" }, () => api.deletePatient(id)).then(
        () => undefined
      ),
    [mutate]
  );

  const createDoctor = useCallback(
    (input: any) =>
      mutate({ success: "تم إضافة الطبيب بنجاح", error: "تعذر إضافة الطبيب" }, () =>
        api.createDoctor(input)
      ),
    [mutate]
  );
  const updateDoctor = useCallback(
    (id: string, patch: Partial<Doctor>) =>
      mutate({ success: "تم تحديث بيانات الطبيب", error: "تعذر تحديث بيانات الطبيب" }, () =>
        api.updateDoctor(id, patch)
      ),
    [mutate]
  );
  const deleteDoctor = useCallback(
    (id: string) =>
      mutate({ success: "تم حذف الطبيب", error: "تعذر حذف الطبيب" }, () => api.deleteDoctor(id)).then(
        () => undefined
      ),
    [mutate]
  );

  const createService = useCallback(
    (input: any) =>
      mutate({ success: "تم إضافة الخدمة بنجاح", error: "تعذر إضافة الخدمة" }, () =>
        api.createService(input)
      ),
    [mutate]
  );
  const updateService = useCallback(
    (id: string, patch: Partial<Service>) =>
      mutate({ success: "تم تحديث الخدمة", error: "تعذر تحديث الخدمة" }, () =>
        api.updateService(id, patch)
      ),
    [mutate]
  );
  const deleteService = useCallback(
    (id: string) =>
      mutate({ success: "تم حذف الخدمة", error: "تعذر حذف الخدمة" }, () => api.deleteService(id)).then(
        () => undefined
      ),
    [mutate]
  );

  const bookAppointment = useCallback(
    (input: any) =>
      mutate({ success: "تم حجز الموعد بنجاح", error: "تعذر حجز الموعد" }, () =>
        api.createAppointment(input)
      ),
    [mutate]
  );
  const updateAppointment = useCallback(
    (id: string, patch: any) =>
      mutate({ success: "تم تعديل الموعد بنجاح", error: "تعذر تعديل الموعد" }, () =>
        api.updateAppointment(id, patch)
      ),
    [mutate]
  );
  const cancelAppointment = useCallback(
    (id: string) =>
      mutate({ success: "تم إلغاء الموعد", error: "تعذر إلغاء الموعد" }, () =>
        api.cancelAppointment(id)
      ).then(() => undefined),
    [mutate]
  );
  const completeAppointment = useCallback(
    (id: string) =>
      mutate({ success: "تم إكمال الموعد وتسجيل الزيارة", error: "تعذر إكمال الموعد" }, () =>
        api.completeAppointment(id)
      ).then(() => undefined),
    [mutate]
  );

  const createVisit = useCallback(
    (input: any) =>
      mutate({ success: "تم تسجيل الزيارة بنجاح", error: "تعذر تسجيل الزيارة" }, () =>
        api.createVisit(input)
      ),
    [mutate]
  );
  const updateVisit = useCallback(
    (id: string, patch: Partial<Visit>) =>
      mutate({ success: "تم تحديث الزيارة", error: "تعذر تحديث الزيارة" }, () =>
        api.updateVisit(id, patch)
      ),
    [mutate]
  );
  const deleteVisit = useCallback(
    (id: string) =>
      mutate({ success: "تم حذف الزيارة", error: "تعذر حذف الزيارة" }, () => api.deleteVisit(id)).then(
        () => undefined
      ),
    [mutate]
  );

  // ---- Global search ----
  const globalSearch = useCallback(
    (q: string): SearchResult => {
      const query = q.trim().toLowerCase();
      if (!query) return { patients: [], doctors: [], services: [], appointments: [] };
      const d = store.read();
      const today = todayKey();
      return {
        patients: d.patients
          .filter((p) => !p.isDeleted && (p.name.toLowerCase().includes(query) || p.phone.includes(query)))
          .slice(0, 5),
        doctors: d.doctors
          .filter(
            (dr) =>
              !dr.isDeleted &&
              dr.isActive &&
              (dr.name.toLowerCase().includes(query) || dr.specialty.toLowerCase().includes(query))
          )
          .slice(0, 5),
        services: d.services
          .filter((s) => !s.isDeleted && s.isActive && s.name.toLowerCase().includes(query))
          .slice(0, 5),
        appointments: d.appointments
          .filter((a) => {
            if (a.isDeleted) return false;
            const p = d.patients.find((x) => x.id === a.patientId);
            const dr = d.doctors.find((x) => x.id === a.doctorId);
            return (
              (p?.name.toLowerCase().includes(query) ?? false) ||
              (p?.phone.includes(query) ?? false) ||
              (dr?.name.toLowerCase().includes(query) ?? false)
            );
          })
          .filter((a) => a.date >= today)
          .slice(0, 5),
      };
    },
    []
  );

  const value = useMemo<AppContextValue>(
    () => ({
      data,
      refresh,
      toasts,
      toast,
      dismissToast,
      theme,
      setTheme,
      effectiveDark,
      settings: data.settings,
      updateSettings,
      popupNotification,
      dismissPopup,
      markNotificationRead,
      markAllRead,
      clearNotifications,
      globalSearch,
      createPatient,
      updatePatient,
      deletePatient,
      createDoctor,
      updateDoctor,
      deleteDoctor,
      createService,
      updateService,
      deleteService,
      bookAppointment,
      updateAppointment,
      cancelAppointment,
      completeAppointment,
      createVisit,
      updateVisit,
      deleteVisit,
    }),
    [
      data,
      refresh,
      toasts,
      toast,
      dismissToast,
      theme,
      setTheme,
      effectiveDark,
      updateSettings,
      popupNotification,
      dismissPopup,
      markNotificationRead,
      markAllRead,
      clearNotifications,
      globalSearch,
      createPatient,
      updatePatient,
      deletePatient,
      createDoctor,
      updateDoctor,
      deleteDoctor,
      createService,
      updateService,
      deleteService,
      bookAppointment,
      updateAppointment,
      cancelAppointment,
      completeAppointment,
      createVisit,
      updateVisit,
      deleteVisit,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

export function usePeriod(): [ReportPeriod, (p: ReportPeriod) => void] {
  const [period, setPeriod] = useState<ReportPeriod>("month");
  return [period, setPeriod];
}
